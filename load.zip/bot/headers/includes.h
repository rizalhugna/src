#pragma once

#ifndef INCLUDES_H
#define INCLUDES_H

#include <time.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <stdint.h>
#include <stdarg.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <arpa/inet.h>
#include <sys/prctl.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/socket.h>

extern char SelfPath[256];
extern int Locker_Pid, Killer_Pid, Main_Pid, Ioctl_Pid;

#define STDIN   0
#define STDOUT  1
#define STDERR  2

#define FALSE   0
#define TRUE    1

#define INET_ADDR(o1,o2,o3,o4) (htonl((o1 << 24) | (o2 << 16) | (o3 << 8) | (o4 << 0)))
#define SINGLE_INSTANCE_PORT 3674
#define FAKE_CNC_ADDR (int)inet_addr((const char*)"NFnhiFSDfdsfFSD");
#define FAKE_CNC_PORT 62881

typedef char BOOL;
typedef uint32_t ipv4_t;
typedef uint16_t port_t;
ipv4_t LOCAL_ADDR;

void makeFukdString(char *buf, int length);
void touchMyself(char **argv);
#endif
