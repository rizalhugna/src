#pragma once

#ifndef UTIL_H
#define UTIL_H
#include "includes.h"

int _startswith(void *, void *);
int _isdigit(char );
int _fdgets(char *, int, int);
int util_strlen(char *);
int util_strcpy(char *, char *);
void util_memcpy(void *, void *, int);
void util_zero(void *, int);
int util_atoi(char *, int);
char *util_itoa(int, int, char *);
int util_stristr(char *, int, char *);
ipv4_t util_local_addr(void);
char *util_fdgets(char *, int, int);
#endif
