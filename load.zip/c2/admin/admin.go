package admin

import (
	"fmt"
	"log"
	"net"

	"BasicC2/json"
)

func Adminserve() {

	n, err := net.Listen("tcp", json.Config.Adminserve)

	if err != nil {
		log.Fatalln("<sytem> listen error: ", err.Error())
	}

	fmt.Println("<system> (socket activated)", n.Addr().String())

	for {
		session, err := n.Accept()

		if err != nil {
			fmt.Println("<system> failed to accept session error: ", err.Error())
			continue
		}

		go handleadmin(session)
	}

}
