package admin

import (
	"BasicC2/controller/sessions"
	"BasicC2/controller/ui"

	"bytes"
	"fmt"
	"net"
)

func VerifySession(session net.Conn) bool {

	TelAuthBytes := []byte{255, 251, 31, 255, 251, 32, 255, 251, 24, 255, 251, 39, 255, 253}
	TelAuth := make([]byte, len(TelAuthBytes))

	if n, err := session.Read(TelAuth); n == 0 || err != nil || !bytes.Equal(TelAuthBytes, TelAuth) {
		return false
	}

	session.Write([]byte("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22")) // Telnet Nigotiation

	return true

}

func handleadmin(session net.Conn) {

	defer session.Close()

	if !VerifySession(session) {
		//fmt.Println("<sytem> unsupported client")
		return
	} else {
		fmt.Println("<system> accepted session: ", session.RemoteAddr().String())
	}

	Term := sessions.AppendAdmin(session)

	ui.Login(Term)
	sessions.RemoveAdmin(Term)

	return
}
