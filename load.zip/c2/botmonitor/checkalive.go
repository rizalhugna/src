package botcontroller

func (bot *Device) checkbot() {

	buf := make([]byte, 1)

	for {

		if n, err := bot.conn.Read(buf); n == 0 || err != nil {
			break
		}

	}

	bot.detachBot() // 	- Move To Removing The Device

}
