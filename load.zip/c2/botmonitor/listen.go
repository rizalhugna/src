package botcontroller

import (
	"fmt"
	"log"
	"net"
)

func BotListener(botserve string) {

	n, err := net.Listen("tcp", botserve)

	if err != nil {
		log.Fatalln("<system> bot listener error: ", err)
		return
	}

	fmt.Println("<system> (machine activated)", botserve)

	for {

		session, err := n.Accept()

		if err != nil {
			fmt.Println("<system> (bot handler) Failed To Accept Connection From ", session.RemoteAddr().String())
			continue
		}

		go wrapbot(session)

	}

}
