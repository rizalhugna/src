package botcontroller

import "sync"

const (
	authstring = "7HdAFTuVf"
)

var (
	mut     sync.Mutex
	Devices = make(map[string]*Device)
)
