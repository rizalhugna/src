package registers

import (
	botcontroller "BasicC2/botmonitor"
	"BasicC2/controller/sessions"
)

func BotCount(params []string, session *sessions.Term) {

	if len(botcontroller.Devices) == 0 {
		session.TermWrite("\n There are no available machines.\r\n\n")
		return
	}

	DeviceTypes := make(map[string]int)

	// Creating Map For Displaying Device Count

	for _, Botstruct := range botcontroller.Devices {
		switch params[1] {

		case "all", "both", "full":
			Botfmt := Botstruct.Arch + ":" + Botstruct.Botname
			if _, exist := DeviceTypes[Botfmt]; !exist {
				DeviceTypes[Botfmt] = 0
			}
			DeviceTypes[Botfmt]++

		case "arch", "archs", "architype", "type":
			if _, exist := DeviceTypes[Botstruct.Arch]; !exist {
				DeviceTypes[Botstruct.Arch] = 0
			}
			DeviceTypes[Botstruct.Arch]++

		case "name", "botname", "exploit", "exploits":
			if _, exist := DeviceTypes[Botstruct.Botname]; !exist {
				DeviceTypes[Botstruct.Botname] = 0
			}
			DeviceTypes[Botstruct.Botname]++
		}
	}

	// Displaying Botcount ---
	session.TermCleaner()
	session.TermWrite("\n   Available Machines\r\n")
	session.TermWrite(" ──────────────────────\r\n")

	for Type, Bot := range DeviceTypes {
		session.TermFormat("  %s > %d\r\n", Type, Bot)
	}
	session.TermWrite("\r\n")
	session.TermFormat("  Total: %d\r\n", len(botcontroller.Devices))
	session.TermWrite(" ──────────────────────\n\r")

}
