package commands

import (
	"BasicC2/controller/sessions"
	"strings"
)

// Checks if command names match
func matchnames(param string, names []string) bool {
	for _, name := range names {
		if name == param {
			return true
		}
	}
	return false
}

// finds the command name and handles the user
func Findcommand(session *sessions.Term, text string) {

	params := strings.Fields(strings.ToLower(text))

	for _, cmd := range commands {

		if !matchnames(params[0], cmd.names) {
			continue
		}

		if cmd.strict && len(params) != cmd.paramLen {
			session.TermFormat("Please Include %d Parameters\r\n", cmd.paramLen)
			return
		}

		if len(params) < cmd.paramLen {
			session.TermFormat("Please Include Up-to %d Parameters\r\n", cmd.paramLen)
			return
		}

		if session.User.Admin {
			cmd.handle(params, session)
			return
		}

		if session.User.Admin != cmd.privilege {
			session.TermFormat("%s Requires higher privileges\r\n", params[0])
			return
		}

		cmd.handle(params, session)
		return
	}

	// Displays The Command not found message
	session.TermFormat("-bash: %s command not found\r\n", params[0])

}
