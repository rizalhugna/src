package commands

import "BasicC2/controller/sessions"

type command struct {
	handle func([]string, *sessions.Term)

	names             []string
	desc              string
	paramLen          int  // param minimum/required length
	privilege, strict bool // Priviledge Requres Admin Permissions, Strict only allow a certain amount of params
}

var commands []command
