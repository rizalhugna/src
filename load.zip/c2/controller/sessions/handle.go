package sessions

import (
	"net"
	"sync"
)

var (
	mut sync.Mutex

	// Sessions Map | Key: FileDescriptor Wrap TermWriters
	Sessions = make(map[net.Addr]*Term)
)

func RemoveAdmin(term *Term) {
	mut.Lock()
	delete(Sessions, term.conn.RemoteAddr())
	mut.Unlock()
}

func AppendAdmin(session net.Conn) *Term {
	var sessionWrapper = wrapconn(session)

	mut.Lock()
	Sessions[session.RemoteAddr()] = sessionWrapper
	mut.Unlock()

	return sessionWrapper
}
