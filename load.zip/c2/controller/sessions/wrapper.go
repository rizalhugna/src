package sessions

import (
	"errors"
	"fmt"
	"net"
)

type UserData struct {
	ID                 int
	Username, Password string
	Admin              bool
}

type Term struct {
	conn net.Conn
	User UserData
}

/*
Wrapping the net.Conn Interface
initializing the user struct pointer to null until login
*/
func wrapconn(session net.Conn) *Term {
	return &Term{conn: session}
}

// Terminal Writer
func (session *Term) TermWrite(text string) (int, error) {
	return session.conn.Write([]byte(text))
}

// Terminal Writer
func (session *Term) TermCleaner() (int, error) {
	return session.TermWrite("\x1b[2J\x1b[H")
}

// Terminal Formatter
func (session *Term) TermFormat(format string, a ...any) (int, error) {
	return session.conn.Write([]byte(fmt.Sprintf(format, a...)))
}

func (session *Term) TermTitle(format string, a ...any) (int, error) {
	return session.conn.Write([]byte(fmt.Sprintf("\033]0;"+format+"\007", a...)))
}

func (session *Term) Reader(maxlen int) (out string, err error) {

	var (
		Arrow_Pos int
	)

	buf := make([]byte, 1)

	for {

		n, err := session.conn.Read(buf)
		if err != nil || n == 0 {

			return "", errors.New("Reached EOF From Socket")

		}

		switch buf[0] {

		case 13:
			continue
		/*Arrow Key Handling*/
		case 27:

			n, err = session.conn.Read(buf)
			if err != nil || n == 0 {

				return "", errors.New("Reached EOF From Socket")

			}

			if buf[0] != '[' {

				continue

			}

			n, err = session.conn.Read(buf)
			if err != nil || n == 0 {

				return "", errors.New("Reached EOF From Socket")

			}

			if buf[0] == 'D' {
				//left

				if Arrow_Pos == 0 {

					continue

				}

				session.TermWrite("\x1b[D")
				Arrow_Pos--
				continue

			}

			if buf[0] == 'C' {
				// right

				if Arrow_Pos == len(out) {
					continue
				}

				Arrow_Pos++
				session.TermWrite("\x1b[C")
				continue

			}

		/*End of Handling Arrow Keys*/

		case '\n':
			session.TermWrite("\r\n")
			return out, nil

		case 127:

			if len(out) == 0 {
				continue
			}

			if Arrow_Pos != len(out) && Arrow_Pos != 0 {

				session.conn.Write(buf)

				out = out[:Arrow_Pos-1] + out[Arrow_Pos:]

				Arrow_Pos--

				session.conn.Write([]byte("\x1b[s" + out[Arrow_Pos:] + " \x1b[u"))

				continue

			}

			if Arrow_Pos == len(out) {

				session.conn.Write(buf)

				out = out[:len(out)-1]

				Arrow_Pos--

			}

			continue

		default:

			if len(out) == maxlen {
				continue
			}

			if buf[0] < 32 || buf[0] > 126 {

				continue

			}

			session.conn.Write(buf)

			if Arrow_Pos != len(out) {

				out = out[:Arrow_Pos] + string(buf) + out[Arrow_Pos:]

				Arrow_Pos++

				session.TermFormat("\x1b[s%v\x1b[u", out[Arrow_Pos:])
				continue

			}

			out += string(buf)

			Arrow_Pos++

		}

	}

}
