package sql

import "BasicC2/controller/sessions"

func Login(username, password string, session *sessions.Term) error {
	return db.QueryRow("SELECT * FROM users where Username = ? And Password = ?", username, password).Scan(&session.User.ID, &session.User.Username, &session.User.Password, &session.User.Admin)
}
