package sql

import (
	"fmt"

	"database/sql"
	"log"

	_ "github.com/go-sql-driver/mysql"
	// "BasicC2/source"
)

// Globalizing the sql connection for the MySQL Cnc Package
var db *sql.DB

func Sql_init(source string) {

	var err error

	// Opening A Sql Connection
	db, err = sql.Open("mysql", source)

	if err != nil || db == nil {
		log.Fatalln("<system> (database) Something went wrong Source: ", source)
	}

	if db.Ping() != nil {
		log.Fatalln("<system> (database) could not connect Source: ", source)
	}

	fmt.Println("<system> (database active)")

	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(10)

}
