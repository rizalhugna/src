package ui

import (
	"BasicC2/controller/sessions"
	"BasicC2/controller/sql"
	"time"
)

func Login(session *sessions.Term) {

	session.TermTitle("</> Login </>")

	session.TermCleaner()

	session.TermWrite("\n   [38;2;0;150;255mUsername[38;2;255;234;0m> [38;2;255;255;255m")

	name, err := session.Reader(100)

	if err != nil {
		return
	}

	session.TermWrite("   [38;2;170;255;0mPassword[38;2;220;20;60m> [38;2;255;255;255m")

	pass, err := session.Reader(100)

	if err != nil {
		return
	}

	if err = sql.Login(name, pass, session); err != nil {
		session.TermWrite(" Login Failed")
		time.Sleep(3 * time.Second)
		return
	}

	// Check If Login Exists

	cmdpage(session)

	return
}
