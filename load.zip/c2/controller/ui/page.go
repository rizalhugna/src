package ui

import (
	botcontroller "BasicC2/botmonitor"
	"BasicC2/controller/commands"
	"BasicC2/controller/sessions"

	"time"
)

func titleworker(session *sessions.Term) {

	for {
		if _, err := session.TermTitle("</> Cryengine  //  Sessions: %d  //  Machines: %d </>", len(sessions.Sessions), len(botcontroller.Devices)); err != nil {
			return
		}
		time.Sleep(time.Second)

		if _, err := session.TermTitle("<-> Cryengine  //  Sessions: %d  //  Machines: %d <->", len(sessions.Sessions), len(botcontroller.Devices)); err != nil {
			return
		}
		time.Sleep(time.Second)

		if _, err := session.TermTitle("<\\> Cryengine  //  Sessions: %d  //  Machines: %d <\\>", len(sessions.Sessions), len(botcontroller.Devices)); err != nil {
			return
		}
		time.Sleep(time.Second)

		if _, err := session.TermTitle("<-> Cryengine  //  Sessions: %d  //  Machines: %d <->", len(sessions.Sessions), len(botcontroller.Devices)); err != nil {
			return
		}
		time.Sleep(time.Second)
	}

}

func cmdpage(session *sessions.Term) {

	go titleworker(session)

	session.TermCleaner() // writes the \x1b[2J\x1b[H to the terminal
	session.TermFormat("[38;2;255;255;255m SECOND: ID: [38;2;0;150;255m%d [38;2;255;255;255mUSER: [38;2;170;255;0m%s [38;2;255;255;255mADMIN: [38;2;255;234;0m%t[38;2;220;20;60m.\r\n", session.User.ID, session.User.Username, session.User.Admin)
	session.TermFormat("\r\n")
	session.TermFormat("\r\n")
	session.TermFormat("\r\n")
	session.TermFormat("\r\n")
	session.TermFormat("\r\n")
	session.TermFormat("\r\n")
	session.TermFormat("\r\n")
	session.TermFormat("                    [38;2;220;20;60m/ \\    [38;2;255;255;255m┌─┐┬─┐┬ ┬┌─┐┌┐┌┌─┐┬┌┐┌┌─┐\r\n")
	session.TermFormat("                  [38;2;0;150;255m<     [38;2;170;255;0m>  [38;2;255;255;255m│  ├┬┘└┬┘├┤ ││││ ┬││││├┤\r\n")
	session.TermFormat("                    [38;2;255;234;0m\\ /    [38;2;255;255;255m└─┘┴└─ ┴ └─┘┘└┘└─┘┴┘└┘└─┘ [38;2;0;150;255mV[38;2;220;20;60m2\r\n")
	session.TermFormat("                                 [38;2;255;255;255mCryengine[38;2;0;150;255m.[38;2;170;255;0mr[38;2;255;234;0ma[38;2;220;20;60mw\r\n")
	session.TermFormat("\r\n")
	session.TermFormat("\r\n")
	session.TermFormat("\r\n")



	for {
		session.TermWrite(" [38;2;0;150;255m[[38;2;255;255;255mCryengine[38;2;170;255;0m] [38;2;255;234;0m<[38;2;220;20;60m/[38;2;255;234;0m>[38;2;255;255;255m ")

		text, err := session.Reader(70)

		if err != nil {
			break
		}

		if len(text) > 0 {
			commands.Findcommand(session, text)
		}

	}

}
