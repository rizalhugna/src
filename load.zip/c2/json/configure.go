package json

import (
	"encoding/json"
	"log"
	"os"
)

// Json Config Structure
type json_config struct {
	Adminserve    string `json:"AdminServe"`
	Sqlsourcename string `jsons:"Sqlsourcename"`
	Botserve      string `json:"BotServe"`
}

var Config json_config

func init() {

	// Read The Data and save as a byte array
	file, err := os.ReadFile("./json/serve.json")
	if err != nil {
		log.Fatalln("<system> serve.json error: ", err.Error())
	}

	// Parses The json from the admin_Sevre and updates adminServe
	if json.Unmarshal(file, &Config) != nil {
		log.Fatalln("<system> serve.json syntax error:", err.Error())
	}

}
