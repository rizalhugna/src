#pragma once

#include "includes.h"

void Killer();
