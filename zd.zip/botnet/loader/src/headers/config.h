#pragma once

#define HTTP_SERVER "91.188.254.224"
#define HTTP_PORT 80

#define TFTP_SERVER "91.188.254.224"
